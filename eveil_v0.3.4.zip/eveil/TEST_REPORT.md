# TEST_REPORT — ÉVEIL v0.3.4

## Preuve réelle reçue (v0.3.3, Godot 4.3 / GitHub Actions)
159/159 vérifications réussies ; étape en échec à cause de `ERROR: Parameter "m" is null` (variante C). Journaux v0.3.3 non joints à cette session.

## v0.3.4 — exécuté ici (sans Godot)
- `check_project.py` : RÉUSSI (structure uniquement).
- YAML des deux workflows : RÉUSSI ; la prévisualisation ne contient ni Pages ni Release.
- `tools/export_web.sh` avec faux Godot : strict → code 1 sur une ligne `ERROR:` ; avec `EXPORT_ALLOW_LOG_ERRORS=1` → code 0 et ZIP avec index.html/js/wasm/pck. Prouve les scripts, pas l'export Godot.

## NON EXÉCUTÉ
Import, fumée, intégration, export réel, Safari. **Je ne peux pas affirmer que l'erreur « m is null » a disparu.**

## À vérifier au prochain run
1. Plus aucune ligne `ERROR:` dans `05_integration.log` ; sinon lire les marqueurs `[DIAG]`.
2. Le transport de la caisse reste visuellement correct (position devant Aël, pas de décalage) : à voir dans la prévisualisation.
3. Les 159 vérifications restent vertes (le suivi par pas physique ne devrait pas changer les tests).
4. Prévisualisation : l'export réel se produit et se charge dans Safari.
