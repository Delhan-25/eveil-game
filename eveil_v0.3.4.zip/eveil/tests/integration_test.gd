extends SceneTree
## Test d'intégration du chapitre 1 par le VRAI chemin de jeu :
## capteur d'interaction -> Interactable -> dialogues -> quêtes, caisse portée,
## cinématique, sauvegarde/rechargement, sauvegardes corrompues, multitouch injecté.
##
## Lancer :  godot --headless --path . -s res://tests/integration_test.gd
## Code de sortie 0 = tout OK, 1 = au moins un échec.
## STATUT : écrit mais NON EXÉCUTÉ (Godot indisponible chez l'auteur).

const SAVE := "user://eveil_save.json"

var game: Node
var quests: Node
var powers: Node
var dialogue: Node
var world: Node3D
var failures: int = 0
var checks: int = 0


func state_line() -> String:
	if not is_instance_valid(world):
		return "(monde absent)"
	var p: Node3D = world.get("player")
	if p == null:
		return "(joueur absent)"
	return "étape=%s dialogue=%s invite='%s' pos=%s carry=%s verrou=%s" % [
		str(quests.get("step_index")), str(dialogue.active), str(game.current_prompt),
		str(p.global_position), str(p.get("carrying") != null), str(game.get("input_locked"))]


func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
	print(("[OK]     " if ok else "[ECHEC]  ") + label)
	if not ok:
		print("         contexte : " + state_line())


func wait(sec: float) -> void:
	await create_timer(sec).timeout


## Entrées simulées COMME LE MOTEUR : livrées au début d'une itération (signal process_frame,
## émis avant tous les _process). Appeler Input.action_press depuis une coroutine de minuterie
## horodaterait l'appui à un moment où Dialogue._process ne le voit plus (is_action_just_pressed
## n'est vrai que pour la frame de l'appui) : faux échecs constatés dans les journaux v0.3.1.
func press(action: String) -> void:
	await process_frame
	Input.action_press(action)


func release(action: String) -> void:
	await process_frame
	Input.action_release(action)


func tap(action: String) -> void:
	await press(action)
	await wait(0.12)
	await release(action)
	await wait(0.12)


## Fait avancer le dialogue en cours comme un joueur : attend, puis appuie sur Agir.
func advance_dialogue(max_taps: int = 40) -> void:
	var n := 0
	while dialogue.active and n < max_taps:
		await wait(0.3)
		await tap("interact")
		n += 1


func spawn_world() -> void:
	world = (load("res://scenes/world.tscn") as PackedScene).instantiate()
	root.add_child(world)
	await wait(0.6)


func free_world() -> void:
	print("[DIAG] libération du monde : début")
	paused = false
	world.queue_free()
	await wait(0.4)
	print("[DIAG] libération du monde : fin")


func teleport(pos: Vector3) -> void:
	var p: Node3D = world.get("player")
	p.global_position = pos
	p.set("velocity", Vector3.ZERO)
	await wait(0.4)   # laisse le capteur Area3D détecter les zones


func write_save(text: String) -> void:
	var f := FileAccess.open(SAVE, FileAccess.WRITE)
	f.store_string(text)
	f.close()


func _initialize() -> void:
	game = root.get_node("Game")
	quests = root.get_node("Quests")
	powers = root.get_node("Powers")
	dialogue = root.get_node("Dialogue")
	await process_frame   # laisse les autoloads exécuter _ready (carte d'entrées, pouvoirs)
	await process_frame
	await run()
	print("== %d vérifications, %d échec(s) ==" % [checks, failures])
	quit(1 if failures > 0 else 0)


func run() -> void:
	await test_teardown_diag()
	# ------------------------------------------------ 0. Parcours À PIED, sans téléportation
	await test_walkthrough()
	await free_world()

	# ------------------------------------------------ 1. Nouvelle partie (scénario avec téléportations)
	if FileAccess.file_exists(SAVE):
		DirAccess.remove_absolute(SAVE)
	game.call("new_game")
	await spawn_world()
	var player: Node3D = world.get("player")
	check(player != null, "monde instancié, joueur présent")
	check(quests.get("step_index") == 0, "nouvelle partie : étape 0")

	# Introduction (se lance 0,8 s après le chargement)
	await wait(1.4)
	check(dialogue.active, "introduction : dialogue actif")
	await advance_dialogue()
	check(not dialogue.active, "introduction terminée")

	# ------------------------------------------------ 2. Maya
	await teleport(Vector3(16.5, 0.2, -5.5))
	check(game.current_prompt == "Parler à Maya", "invite « Parler à Maya » affichée")
	await tap("interact")
	check(dialogue.active, "dialogue de Maya lancé par l'interaction")
	await advance_dialogue()
	check(quests.get("step_index") == 1, "étape 1 validée par le dialogue (pas par appel direct)")

	# ------------------------------------------------ 3. Caisse
	var crate: Node3D = world.get("crate")
	await teleport(crate.global_position + Vector3(0, 0.2, 1.2))
	check(game.current_prompt == "Ramasser la caisse", "invite « Ramasser la caisse »")
	await tap("interact")
	check(player.get("carrying") == crate, "caisse portée par Aël")

	# Sauvegarde pendant le transport puis rechargement
	check(game.call("save_game"), "sauvegarde pendant le transport")
	check(not FileAccess.file_exists(String(game.get("save_path")) + ".tmp"), "aucun fichier temporaire résiduel après sauvegarde")
	await free_world()
	check(game.call("load_game"), "rechargement après sauvegarde en transport")
	await spawn_world()
	player = world.get("player")
	crate = world.get("crate")
	check(quests.get("step_index") == 1, "étape 1 restaurée")
	check(player.get("carrying") == crate, "caisse TOUJOURS portée après rechargement")

	# Pose libre puis sauvegarde/rechargement (état « posée »)
	await tap("interact")
	check(player.get("carrying") == null, "caisse posée au sol")
	var dropped_at: Vector3 = crate.global_position
	check(game.call("save_game"), "sauvegarde caisse posée")
	await free_world()
	check(game.call("load_game"), "rechargement caisse posée")
	await spawn_world()
	player = world.get("player")
	crate = world.get("crate")
	check(crate.global_position.distance_to(dropped_at) < 0.3, "caisse retrouvée à l'endroit où elle a été posée")

	# Reprise de la caisse puis dépôt dans la grange
	await teleport(crate.global_position + Vector3(0, 0.2, 1.2))
	await tap("interact")
	check(player.get("carrying") == crate, "caisse reprise")
	var zone_pos: Vector3 = Vector3(34.0, 0.0, -12.0) + Vector3(-2.0, 0.0, 0.0)
	await teleport(zone_pos + Vector3(0, 0.2, 0))
	check(game.current_prompt == "Poser la caisse ici", "invite de dépôt dans la grange")
	await tap("interact")
	check(dialogue.active, "dialogue d'appel de Noé")
	await advance_dialogue()
	check(quests.get("step_index") == 2, "étape 2 validée par le dépôt")
	check(crate.get("delivered") == true, "caisse marquée livrée")

	# ------------------------------------------------ 4. Poutre et cinématique
	await teleport(Vector3(35.0, 0.2, -15.0))
	check(game.current_prompt == "Soulever la poutre", "invite « Soulever la poutre »")
	await tap("interact")
	var t0 := Time.get_ticks_msec()
	while not quests.get("chapter_done") and Time.get_ticks_msec() - t0 < 90000:
		if dialogue.active:
			await tap("interact")
			await wait(0.3)
		else:
			await wait(0.25)
	check(quests.get("chapter_done") == true, "cinématique terminée, chapitre achevé")
	check(powers.call("is_unlocked", "super_strength"), "super-force débloquée")
	await wait(2.0)
	var end_screen: CanvasLayer = world.get("chapter_end")
	check(end_screen.visible, "écran de fin de chapitre affiché")
	check(paused, "jeu en pause sur l'écran de fin")

	# Continuer à explorer
	end_screen.call("_on_continue")
	check(not paused, "reprise après l'écran de fin")

	# Pouvoir
	await tap("power")
	check(powers.call("is_active", "super_strength"), "pouvoir activé par la touche")

	# ------------------------------------------------ 5. Pause / reprise
	game.pause_requested.emit()
	await wait(0.2)
	check(paused, "menu pause ouvert")
	var pm: CanvasLayer = world.get("pause_menu")
	pm.call("close")
	check(not paused, "reprise depuis le menu pause")

	# ------------------------------------------------ 6. Sauvegarde après mission
	check(game.call("save_game"), "sauvegarde après la mission")
	await free_world()
	check(game.call("load_game"), "rechargement après la mission")
	await spawn_world()
	var noe: Node3D = world.get("noe")
	check(quests.get("chapter_done") == true, "chapitre achevé restauré")
	check(powers.call("is_unlocked", "super_strength"), "pouvoir restauré")
	check(absf(noe.rotation.x) < 0.05, "Noé debout après rechargement")
	check(world.get("crate").get("delivered") == true, "caisse livrée restaurée")

	# ------------------------------------------------ 7. Multitouch injecté
	await test_multitouch()

	await test_dispatch_probe()

	# ------------------------------------------------ 8. Politique de sauvegarde
	await free_world()
	await test_save_policy()
	DirAccess.remove_absolute(SAVE)

## Injection par le chemin réel du moteur (Input.parse_input_event + flush). Utilisée par la
## sonde de diagnostic seulement : les journaux CI v0.3.2 montrent qu'en headless ces événements
## n'atteignent pas TouchControls (voir test_dispatch_probe).
func send_event(ev: InputEvent) -> void:
	await process_frame
	Input.parse_input_event(ev)
	Input.flush_buffered_events()


var _tc: Control = null


## Livraison DÉTERMINISTE à TouchControls, au début d'une itération, exactement comme le moteur
## appelle _input() — y compris : pas de livraison si le nœud ne peut pas traiter (arbre en pause).
## Teste la machine à états multitouch (indices de doigts), pas le routage du moteur.
func deliver(ev: InputEvent) -> void:
	await process_frame
	if _tc != null and _tc.can_process():
		_tc._input(ev)


func touch(index: int, pos: Vector2, pressed: bool) -> void:
	var ev := InputEventScreenTouch.new()
	ev.index = index
	ev.position = pos
	ev.pressed = pressed
	await deliver(ev)
	await wait(0.1)


func drag(index: int, pos: Vector2, rel: Vector2) -> void:
	var ev := InputEventScreenDrag.new()
	ev.index = index
	ev.position = pos
	ev.relative = rel
	await deliver(ev)
	await wait(0.1)


func test_multitouch() -> void:
	var tc: Control = world.get("touch_controls")
	_tc = tc
	tc.visible = true
	# Souris visible : aucune souris émulée ne peut faire tourner la caméra à la place du doigt.
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	await wait(0.2)
	var vs: Vector2 = root.get_visible_rect().size
	check(vs.x > 300.0 and vs.y > 200.0, "viewport de taille plausible (%s)" % str(vs))
	check(tc.size.x > 100.0 and tc.size.y > 100.0, "TouchControls a une taille d'écran (%s)" % str(tc.size))
	var hud_root: Control = (world.get("hud") as CanvasLayer).get("_root")
	check(hud_root.size.x > 100.0 and hud_root.size.y > 100.0, "le HUD occupe l'écran (%s)" % str(hud_root.size))
	var joy_a := Vector2(vs.x * 0.12, vs.y * 0.72)
	var joy_b := joy_a + Vector2(90, 0)
	var look_a := Vector2(vs.x * 0.72, vs.y * 0.40)
	var look_b := look_a + Vector2(40, 0)
	var rig: Node3D = world.get("player").get("rig")
	var yaw0: float = rig.get("yaw")
	var jump_c: Vector2 = (tc.call("_btn", "jump") as Dictionary)["c"]
	# Doigt 0 : joystick à gauche. Doigt 1 : caméra à droite. Doigt 2 : bouton Saut.
	await touch(0, joy_a, true)
	await drag(0, joy_b, Vector2(90, 0))
	check((game.get("touch_move") as Vector2).x > 0.5, "multitouch : joystick actif")
	await touch(1, look_a, true)
	await drag(1, look_b, Vector2(40, 0))
	await wait(0.2)
	check(absf(float(rig.get("yaw")) - yaw0) > 0.01, "multitouch : caméra tourne pendant que le joystick est tenu")
	await touch(2, jump_c, true)
	check(Input.is_action_pressed("jump"), "multitouch : saut pressé avec 2 autres doigts posés")
	check((game.get("touch_move") as Vector2).x > 0.5, "multitouch : joystick toujours actif")
	await touch(2, jump_c, false)
	await touch(1, look_b, false)
	await touch(0, joy_b, false)
	await wait(0.2)
	check((game.get("touch_move") as Vector2) == Vector2.ZERO, "joystick relâché")

	# Bouton AGIR pendant un dialogue : doit faire avancer le texte.
	var interact_c: Vector2 = (tc.call("_btn", "interact") as Dictionary)["c"]
	dialogue.call("start", [{"speaker": "Test", "text": "Un."}, {"speaker": "Test", "text": "Deux."}])
	await wait(0.4)
	var n := 0
	while dialogue.active and n < 8:
		await touch(5, interact_c, true)
		await touch(5, interact_c, false)
		await wait(0.3)
		n += 1
	check(not dialogue.active, "bouton AGIR tactile fait avancer puis fermer le dialogue")

	# Pause tactile : doit pouvoir être rouverte après reprise, doigts relâchés proprement.
	var pause_c: Vector2 = (tc.call("_btn", "pause") as Dictionary)["c"]
	var pm: CanvasLayer = world.get("pause_menu")
	await touch(7, pause_c, true)
	check(paused, "pause tactile : ouverte")
	await touch(7, pause_c, false)   # ignoré (arbre en pause) : TouchControls doit se réinitialiser seul
	pm.call("close")
	check(not paused, "pause tactile : reprise")
	check(((tc.get("_btn_index") as Dictionary)["pause"]) == -1, "pause tactile : doigt relâché proprement")
	check((game.get("touch_move") as Vector2) == Vector2.ZERO, "joystick remis à zéro après reprise")
	await touch(8, pause_c, true)
	check(paused, "pause tactile : réouverture possible après reprise")
	await touch(8, pause_c, false)
	pm.call("close")
	tc.visible = false
	_tc = null


# ====================================================================== Parcours à pied

## Marche vers `target` en pilotant le joystick (Game.touch_move) : la physique réelle
## (collisions, clôtures, murs de la grange) s'applique. Retourne false si bloqué/timeout.
func walk_to(target: Vector3, timeout: float = 20.0) -> bool:
	var p: Node3D = world.get("player")
	var rig: Node3D = p.get("rig")
	var t0 := Time.get_ticks_msec()
	while Time.get_ticks_msec() - t0 < int(timeout * 1000.0):
		var d := target - p.global_position
		d.y = 0.0
		if d.length() < 0.6:
			game.set("touch_move", Vector2.ZERO)
			return true
		var local := d.normalized().rotated(Vector3.UP, -float(rig.get("yaw")))
		game.set("touch_move", Vector2(local.x, local.z))
		await wait(0.05)
	game.set("touch_move", Vector2.ZERO)
	return false


func walk_route(label: String, points: Array) -> void:
	for wp in points:
		var ok: bool = await walk_to(wp)
		check(ok, "à pied : %s -> %s atteint" % [label, str(wp)])
		if not ok:
			var p: Node3D = world.get("player")
			print("   bloqué à ", p.global_position)
			return


func test_walkthrough() -> void:
	if FileAccess.file_exists(SAVE):
		DirAccess.remove_absolute(SAVE)
	game.call("new_game")
	await spawn_world()
	await wait(1.4)
	await advance_dialogue()
	var player: Node3D = world.get("player")
	# Départ -> Maya (entrée par l'ouverture de la clôture, x 13..19 à z=-3,5)
	await walk_route("départ vers Maya", [Vector3(13.5, 0, -1.0), Vector3(16.0, 0, -4.8)])
	check(game.current_prompt == "Parler à Maya", "à pied : invite Maya")
	await tap("interact")
	await advance_dialogue()
	check(quests.get("step_index") == 1, "à pied : étape 1 (Maya)")
	# Caisse
	await walk_route("Maya vers la caisse", [Vector3(18.6, 0, -4.4)])
	await tap("interact")
	check(player.get("carrying") == world.get("crate"), "à pied : caisse ramassée")
	# Grange : par le chemin, puis la porte ouest (x=28, z entre -14 et -10)
	await walk_route("caisse vers la grange", [Vector3(24, 0, -5.5), Vector3(24, 0, -12), Vector3(31.5, 0, -12)])
	check(game.current_prompt == "Poser la caisse ici", "à pied : invite de dépôt")
	await tap("interact")
	await advance_dialogue()
	check(quests.get("step_index") == 2, "à pied : étape 2 (dépôt)")
	# Poutre
	await walk_route("zone de dépôt vers la poutre", [Vector3(34.5, 0, -15.2)])
	check(game.current_prompt == "Soulever la poutre", "à pied : invite poutre")
	await tap("interact")
	var t0 := Time.get_ticks_msec()
	while not quests.get("chapter_done") and Time.get_ticks_msec() - t0 < 90000:
		if dialogue.active:
			await tap("interact")
			await wait(0.3)
		else:
			await wait(0.25)
	check(quests.get("chapter_done") == true, "à pied : chapitre terminé")
	await wait(2.0)
	var end_screen: CanvasLayer = world.get("chapter_end")
	check(end_screen.visible, "à pied : écran de fin affiché")
	end_screen.call("_on_continue")


# ====================================================================== Politique de sauvegarde

func valid_save() -> Dictionary:
	return {
		"version": 2, "step": 1, "powers": {"unlocked": [], "selected": ""},
		"flags": {}, "play_time": 12.0, "position": [10.0, 0.2, 0.0],
		"world": {"crate": {"state": "start", "pos": [18.6, 0.35, -5.6]}},
	}


func save_variant(key: String, value: Variant) -> String:
	var d := valid_save()
	if typeof(value) == TYPE_STRING and value == "<ERASE>":
		d.erase(key)
	else:
		d[key] = value
	return JSON.stringify(d)


func test_save_policy() -> void:
	var strength := {"unlocked": ["super_strength"], "selected": "super_strength"}
	var refused := {
		"fichier vide": "", "JSON tronqué": "{", "tableau": "[]", "null": "null",
		"version absente": save_variant("version", "<ERASE>"),
		"version 0": save_variant("version", 0),
		"version 3 (future)": save_variant("version", 3),
		"version texte": save_variant("version", "x"),
		"étape texte": save_variant("step", "abc"),
		"étape 99": save_variant("step", 99),
		"étape -1": save_variant("step", -1),
		"étape absente": save_variant("step", "<ERASE>"),
		"pouvoirs absents": save_variant("powers", "<ERASE>"),
		"pouvoirs = 5": save_variant("powers", 5),
		"pouvoir inconnu": save_variant("powers", {"unlocked": ["vol"], "selected": ""}),
		"flags = 7": save_variant("flags", 7),
		"play_time texte": save_variant("play_time", "y"),
		"play_time négatif": save_variant("play_time", -3),
		"position courte": save_variant("position", [1, 2]),
		"position hors carte": save_variant("position", [9999, 0, 0]),
		"position absente": save_variant("position", "<ERASE>"),
		"monde absent": save_variant("world", "<ERASE>"),
		"monde = texte": save_variant("world", "x"),
		"état de caisse inconnu": save_variant("world", {"crate": {"state": "zzz", "pos": [0, 0.35, 0]}}),
		"caisse livrée à l'étape 1": save_variant("world", {"crate": {"state": "delivered", "pos": [0, 0.35, 0]}}),
		"caisse au départ à l'étape 2": save_variant("step", 2),
		"étape 3 sans pouvoir": save_variant("step", 3),
		"pouvoir avant la fin": save_variant("powers", strength),
	}
	quests.call("load_step", 2)   # sentinelle : un refus ne doit RIEN modifier
	for label in refused.keys():
		write_save(String(refused[label]))
		var ok: bool = game.call("load_game")
		check(ok == false, "refusée : %s" % label)
		check(String(game.get("last_load_error")) != "", "message d'erreur fourni : %s" % label)
		check(quests.get("step_index") == 2, "état inchangé après refus : %s" % label)

	# Acceptées
	write_save(JSON.stringify(valid_save()))
	check(game.call("load_game") == true, "acceptée : sauvegarde v2 valide")
	var done := valid_save()
	done["step"] = 3
	done["powers"] = strength
	done["world"] = {"crate": {"state": "delivered", "pos": [30.4, 0.35, -15.6]}}
	write_save(JSON.stringify(done))
	check(game.call("load_game") == true, "acceptée : chapitre terminé (v2)")
	var v1 := {"version": 1, "step": 2, "powers": {"unlocked": [], "selected": ""}, "flags": {},
		"play_time": 5.0, "position": [1.0, 0.2, 2.0]}
	write_save(JSON.stringify(v1))
	check(game.call("load_game") == true, "migration v1 -> v2 acceptée")
	await spawn_world()
	check(world.get("crate").get("delivered") == true, "migration v1 : caisse livrée reconstruite depuis l'étape")
	await free_world()

	# Échec d'écriture : l'ancienne sauvegarde doit rester intacte et lisible.
	write_save(JSON.stringify(valid_save()))
	game.call("new_game")
	var good_path: String = game.get("save_path")
	game.set("save_path", "user://dossier_inexistant/eveil.json")
	check(game.call("save_game") == false, "échec d'écriture détecté (dossier inexistant)")
	check(String(game.get("last_save_error")) != "", "message d'erreur de sauvegarde fourni")
	game.set("save_path", good_path)
	check(game.call("load_game") == true, "ancienne sauvegarde toujours valide après l'échec")
	check(quests.get("step_index") == 1, "ancienne sauvegarde inchangée (étape 1)")
	# Non simulé ici : échec du renommage seul (nécessite une injection de panne du système de fichiers).


# ====================================================================== Diagnostics (non comptés)

## Un événement tactile injecté par le chemin réel arrive-t-il à un nœud _input ? (affiche seulement)
func test_dispatch_probe() -> void:
	var gs := GDScript.new()
	gs.source_code = "extends Node\nvar touches := 0\nvar mouse := 0\nfunc _input(e):\n\tif e is InputEventScreenTouch:\n\t\ttouches += 1\n\tif e is InputEventMouseButton:\n\t\tmouse += 1\n"
	gs.reload()
	var probe := Node.new()
	probe.set_script(gs)
	root.add_child(probe)
	var ev := InputEventScreenTouch.new()
	ev.index = 0
	ev.position = Vector2(100, 100)
	ev.pressed = true
	await send_event(ev)
	await wait(0.2)
	var up := InputEventScreenTouch.new()
	up.index = 0
	up.position = Vector2(100, 100)
	up.pressed = false
	await send_event(up)
	await wait(0.2)
	print("[DIAG] sonde d'événements : ScreenTouch reçus par _input = %d ; MouseButton émulés = %d ; emulate_mouse_from_touch = %s" % [
		int(probe.get("touches")), int(probe.get("mouse")), str(Input.is_emulating_mouse_from_touch())])
	probe.queue_free()


## Libère des mondes dans plusieurs états pour localiser les « Parameter "m" is null » :
## les lignes ERROR du journal apparaissent entre les marqueurs du cas fautif.
## Variante « E » : reproduit volontairement l'ANCIEN schéma (caisse sortie puis rentrée dans l'arbre).
## Elle n'est exécutée que si EVEIL_DIAG_REPRO=1 (workflow de prévisualisation), car elle est
## censée provoquer l'erreur du moteur ; le workflow principal ne la lance pas.
func test_teardown_diag() -> void:
	var variants := ["A frais", "B caisse portée", "C caisse portée puis déposée",
		"D aura active", "F set_carried bascule seul", "G caisse libérée seule avant le monde"]
	if OS.get_environment("EVEIL_DIAG_REPRO") == "1":
		variants.append("E caisse sortie puis rentrée dans l'arbre (ancien schéma)")
	for variant in variants:
		game.call("new_game")
		await spawn_world()
		var p: Node3D = world.get("player")
		var c: Node3D = world.get("crate")
		match variant:
			"B caisse portée":
				p.call("pick_up", c)
			"C caisse portée puis déposée":
				p.call("pick_up", c)
				await wait(0.3)
				p.call("drop_carried")
			"D aura active":
				p.call("set_aura", true)
			"F set_carried bascule seul":
				c.call("set_carried", true)
				c.call("set_carried", false)
			"G caisse libérée seule avant le monde":
				c.queue_free()
				await wait(0.3)
			"E caisse sortie puis rentrée dans l'arbre (ancien schéma)":
				var par := c.get_parent()
				par.remove_child(c)
				par.add_child(c)
		await wait(0.3)
		print("[DIAG] teardown variante « %s »" % variant)
		await free_world()
