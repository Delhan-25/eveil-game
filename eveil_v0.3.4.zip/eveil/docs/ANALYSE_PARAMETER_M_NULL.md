# « Parameter "m" is null » — analyse (v0.3.4)
Erreur : `mesh_get_surface_count (servers/rendering/dummy/storage/mesh_storage.h:120)`. Journaux v0.3.3 : 159/159 vérifications OK, mais l'étape échoue à cause de la ligne `ERROR:`.
Je n'ai PAS reçu les journaux v0.3.3 : cette analyse repose sur votre description (variante C) et sur le code.

## Ce qui est établi
- L'erreur vient du serveur de rendu (« dummy » = headless) : un RID de maillage invalide est interrogé. Elle survient à la libération du monde, après `pick_up` + `drop_carried`.
- Elle persistait après le remplacement de `Node.reparent` par `remove_child/add_child` (v0.3.3) : **le mécanisme `reparent` en lui-même n'était donc pas la cause** ; le point commun est que la caisse **sort de l'arbre de scène puis y rentre**.
- Les cas libérés sans cette sortie/rentrée (monde frais, caisse seulement portée, mondes migrés v1) n'avaient pas montré l'erreur dans les journaux v0.3.2.

## Audit des ressources (code lu, rien d'anormal trouvé)
| Élément | Constat |
|---|---|
| `Crate` (5 `MeshInstance3D`) | un `BoxMesh` propre à chaque instance ; `_ready` n'est exécuté qu'une fois ; aucun maillage partagé |
| `world.add_box/add_cyl`, bulbes, balise, marqueur de zone | un maillage par instance, aucun partage de RID |
| `MultiMesh` des arbres | `trunk_mesh` (1 instance) et `cone_mesh` (partagé par 2 `MultiMesh`, détenu par les deux) : partage sain ; compte d'instances fixé avant usage |
| `CharacterBuilder` | un maillage par `MeshInstance3D` |
| Aura `CPUParticles3D` | maillage détenu par le nœud |
Aucun maillage libéré à la main, aucun `free()` explicite, aucun `RID` manipulé dans le projet.

## Cause : NON PROUVÉE
Hypothèse la plus probable : une instance de rendu d'un `MeshInstance3D` de la caisse, détruite à la sortie de l'arbre puis recréée à la rentrée, laisse la file de mise à jour du serveur de rendu pointer un maillage déjà libéré quand le monde est détruit. Je n'ai pas pu l'observer (pas de Godot ici) ; je ne l'affirme pas.

## Erreur du moteur headless ou défaut du jeu ?
- Le serveur « dummy » n'existe qu'en headless, mais le contrôle de nullité (`ERR_FAIL_NULL`) est le même dans les serveurs réels : un RID invalide interrogé est un symptôme de cycle de vie, pas une particularité du headless.
- Aucun effet visible sur le jeu (tous les tests de gameplay verts). **Je ne peux pas dire** si l'erreur apparaît sur WebGL/iPhone : à observer dans la console du navigateur sur la prévisualisation.
- Verdict : défaut de cycle de vie **probable, mineur**, révélé par le mode headless. Pas de preuve d'un bug de moteur.

## Correction v0.3.4 (supprime le mécanisme suspect, ne masque rien)
`scripts/player/player.gd` : la caisse **reste enfant du monde en permanence** ; `_follow_carried()` copie la position du point de portage à chaque pas physique ; `drop_carried()` la pose devant le joueur. Plus aucune sortie/rentrée de l'arbre. Comportement identique (porter, poser, sauvegarder en transport, livrer).
Aucune ligne `ERROR:` n'est ignorée : `tools/run_tests.sh` reste strict.

## Si l'erreur persiste : bissection fournie
`test_teardown_diag` libère des mondes dans 6 états (A frais, B portée, C portée puis déposée, D aura, F `set_carried`, G caisse libérée seule) avec marqueurs `[DIAG]` ; la variante **E** (ancien schéma : sortie puis rentrée de la caisse) ne s'exécute que dans la prévisualisation (`EVEIL_DIAG_REPRO=1`). Lire les `ERROR` entre les marqueurs :
- E seule en erreur → cause confirmée (sortie/rentrée de l'arbre), corrigée par v0.3.4.
- C/B/D/F/G en erreur → la cause est ailleurs (envoyez le journal, je poursuivrai).
