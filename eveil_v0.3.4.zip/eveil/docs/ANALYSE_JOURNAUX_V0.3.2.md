# Analyse des journaux réels de la v0.3.2 (Godot 4.3.stable, GitHub Actions)
Journaux bruts : `docs/ci_logs_v0.3.2/`. Résultat : import OK, fumée OK (0 échec), intégration 6 échecs / 159.

## Acquis prouvés par ces journaux
Parcours à pied complet (15/15), caisse portée/posée/livrée, cinématique, super-force, écran de fin, pause, 3 cycles sauvegarde→rechargement, 26 refus de sauvegarde, migration v1, échec d'écriture. Le warning Unicode a disparu.

## Les 6 échecs
| Échec | Indice dans le journal |
|---|---|
| multitouch : joystick actif ; joystick toujours actif | `touch_move` jamais > 0,5 |
| multitouch : saut pressé | l'action `jump` n'est jamais pressée |
| bouton AGIR : fait avancer le dialogue | `dialogue=true` reste actif |
| pause tactile : ouverte ; réouverture | le jeu ne se met jamais en pause |
Le même motif touche joystick, bouton et pause : **aucune** de ces commandes ne réagit.

## Bug réel ou simulation ? (verdict prudent)
- **Pas de bug trouvé dans la logique de `touch_controls.gd`** : relecture de `_touch_down/_update_joy/_press` avec les valeurs du test (viewport 1280×1280, doigt 0 à gauche, doigt 2 sur SAUT) → joystick ≈ 0,89 et action `jump` pressée. Les ratios et la taille (1280×1280, non nulle) sont valides.
- **Cause la plus probable : problème de simulation.** Les événements envoyés par `Input.parse_input_event` + `flush_buffered_events` n'atteignent apparemment pas `TouchControls._input` en headless. Preuve indirecte : « caméra tourne » passait alors que le doigt de la caméra suit le même chemin ; la caméra tournait très probablement via la **souris émulée** (`emulate_mouse_from_touch`) captée par `CameraRig`, pas via `touch_look` → faux positif.
- **Ce n'est qu'une hypothèse** : elle n'est pas prouvée par les journaux. Une sonde de diagnostic (ci-dessous) la confirmera ou l'infirmera au prochain run.

## Erreurs « Parameter "m" is null » (3 occurrences)
`mesh_get_surface_count (servers/rendering/dummy/storage/mesh_storage.h:120)` : moteur de rendu factice du mode headless, un maillage dont le RID est invalide est interrogé.
Chronologie du journal : chaque erreur tombe **dans `free_world()`**, après une sauvegarde et avant le rechargement (lignes 18, 36, 55). Elle apparaît pour les 3 mondes où la caisse a été déposée par `drop_carried()` (donc `Node.reparent(world, true)`), et **pas** pour le monde libéré avec la caisse portée ni pour les mondes migrés de la v1 (caisse jamais déplacée).
- Corrélation nette, **cause non prouvée**. Pas d'effet visible sur le jeu (tests de gameplay verts autour). Probablement sans gravité en rendu réel, mais je ne peux pas l'affirmer.
- Mesure appliquée : `reparent` remplacé par `remove_child` + `add_child` (`player.gd`). **Peut ne pas suffire.**
- Localisation : `test_teardown_diag()` libère 4 mondes (A frais, B caisse portée, C portée puis déposée, D aura) avec des marqueurs `[DIAG]` ; les lignes `ERROR` entre les marqueurs désignent le cas fautif.
- `tools/run_tests.sh` traite toujours `^ERROR:` comme un échec : **je n'ai rien whitelisté**. Si ces erreurs persistent, l'étape restera rouge, volontairement.

## Corrections apportées (v0.3.3)
1. `tests/integration_test.gd` : les événements tactiles sont livrés directement à `TouchControls._input` au début d'une itération, sans livraison si le nœud est en pause (comme le moteur). Les 6 vérifications gardent exactement leurs critères. La caméra est testée avec souris visible : plus de faux positif possible.
2. Sonde `test_dispatch_probe()` : affiche (`[DIAG]`, non comptée) si un événement injecté atteint un `_input` par le chemin réel, et si des souris émulées sont créées.
3. `player.gd` : `reparent` → `remove_child/add_child`.
**Limite assumée** : le routage moteur → `TouchControls` n'est plus asserté en headless ; il n'est que diagnostiqué. Il ne sera réellement validé que sur Safari/iPhone.
