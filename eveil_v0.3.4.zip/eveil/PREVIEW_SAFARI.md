# Prévisualisation Web NON VALIDÉE — tester dans Safari

> Ce build est **non validé** : il peut être cassé. Il sert uniquement à vérifier le chargement dans Safari. **Ne pas publier.**
> Workflow `.github/workflows/web-preview.yml` : jamais exécuté (écrit seulement).

## Obtenir le build
1. GitHub → **Actions → « Preview Web (NON VALIDÉE) » → Run workflow** (manuel uniquement ; aucun push ne le déclenche).
2. Attendre la fin (il peut finir **rouge** si des tests échouent : normal, l'export est quand même produit). Le résumé du run affiche la bannière NON VALIDÉE, l'état des tests et de l'export.
3. Télécharger l'artefact `eveil-web-PREVIEW-NON-VALIDEE-<sha>` (fichiers) ou `…-zip` (le ZIP est dans un second ZIP GitHub : le décompresser une fois). Conservé 7 jours. Journaux : `journaux-preview-<sha>`.
Si l'export lui-même échoue (étape rouge « Export Web »), il n'y a pas de build : envoyez-moi `journaux-preview-<sha>`.

## Ouvrir dans Safari (iPhone), sans installer Godot
Le jeu doit être servi par HTTP(S) (ouvrir `index.html` depuis les Fichiers ne marche pas : le `.wasm` exige un serveur).
- **Réseau local (le plus simple)** : sur un ordinateur, décompresser, puis `python3 tools/serve_web.py <dossier> 8080` ; sur l'iPhone (même Wi-Fi) ouvrir `http://<IP-de-l-ordinateur>:8080`, en paysage. L'export est sans multithreading : aucun en-tête spécial requis.
- **Hébergement privé de votre choix** (HTTPS) : envoyer le contenu du dossier à la racine d'un site de test.
- Déroulez `WEB_TEST_CHECKLIST.md` (W2–W19) et notez : modèle d'iPhone, iOS, FPS (menu pause → « FPS : oui »).

## Ce qu'il ne faut PAS faire
Ne pas l'envoyer sur itch.io en public, ne pas l'attacher à une Release. Le workflow strict `Build Web (HTML5)` reste le seul à pouvoir publier (Pages/Release), et seulement après des tests verts.
