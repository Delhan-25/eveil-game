# Obtenir le jeu Web compilé (v0.3.2 : le workflow a déjà tourné une fois — voir docs/ANALYSE_JOURNAUX_V0.3.1.md) (GitHub Actions) — sans installer Godot

> **État honnête : aucune compilation réelle n'a eu lieu.** L'environnement de l'auteur n'a ni Godot ni accès réseau.
> Le workflow `.github/workflows/web-build.yml` est écrit et son YAML est valide ; il n'a **jamais été exécuté**.
> Vous êtes la première personne à le lancer : le premier run peut échouer (voir §5).

## 1. Mettre le projet sur GitHub
1. Créer un dépôt GitHub (public ou privé) vide.
2. Dans le dossier `eveil/` du ZIP : `git init && git add -A && git commit -m "Éveil v0.3.1"`
   puis `git branch -M main && git remote add origin https://github.com/<vous>/<depot>.git && git push -u origin main`.
   (Le dossier `.github/` doit être poussé : il est caché sur certains systèmes.)

## 2. Lancer la compilation
Le push sur `main` la déclenche. Sinon : onglet **Actions → « Build Web (HTML5) » → Run workflow**.
Le workflow : installe Godot 4.3.0 + modèles d'export (`chickensoft-games/setup-godot@v2`) → import → démarrage du menu → test de fumée → **test d'intégration** → export Web sans multithreading → vérification des fichiers → ZIP.
**Il échoue** si l'une de ces étapes échoue (code de sortie non nul, ou « SCRIPT ERROR »/« Parse Error »/« ERROR: » dans un journal).

## 3. Récupérer le jeu compilé
Dans le run terminé (onglet Actions → cliquer le run → section **Artifacts**) :
| Artefact | Contenu |
|---|---|
| `eveil-web-VALIDE-<sha>` | les fichiers réels : `index.html`, `index.js`, `index.wasm`, `index.pck` (+ icônes) |
| `eveil-web-VALIDE-<sha>-zip-itch` | `eveil_web_itch.zip` (à envoyer sur itch.io ; GitHub l'emballe dans un second ZIP : le décompresser une fois) |
| `journaux-godot-<sha>` | tous les journaux (`build/logs/*.log`, `summary.txt`) — toujours fournis, même en cas d'échec |
Si vous poussez un **tag** `v0.3.1` (`git tag v0.3.1 && git push --tags`), le ZIP est aussi attaché à une **Release** (téléchargement direct, sans double ZIP).
Le résumé des tests s'affiche en haut de la page du run.

## 4. Jouer sur iPhone, Safari
**Option A — GitHub Pages (HTTPS, sans itch.io)** : *Settings → Pages → Source : GitHub Actions*. Après un build **valide** sur `main`, le job `deploy-pages` publie le jeu ;
l'URL est affichée dans le run (`https://<vous>.github.io/<depot>/`). Ouvrez-la dans Safari, iPhone en **paysage**.
**Option B — itch.io** : décompresser l'artefact `...-zip-itch`, envoyer `eveil_web_itch.zip` (voir `PUBLICATION_ITCH.md`).
Dans les deux cas, dérouler `WEB_TEST_CHECKLIST.md`.

## 5. Si ça échoue (probable au premier essai)
- Ouvrir l'artefact `journaux-godot-<sha>` : `04_smoke.log` / `05_integration.log` montrent l'erreur exacte (lignes `[ECHEC]`, `SCRIPT ERROR`). Renvoyez-moi ces fichiers : je corrigerai.
- **Pour obtenir quand même un build à essayer sur iPhone** : *Run workflow* avec **« Exporter MÊME si les tests échouent »** coché. L'export est alors produit sous le nom `eveil-web-NON-VALIDE-tests-en-echec-<sha>` et **le run reste rouge**. Ce build n'est pas validé. Il n'est jamais déployé sur Pages ni attaché à une Release.
- Un échec à l'étape « Installer Godot » : vérifier `GODOT_VERSION` (en haut du workflow) ; l'action doit pouvoir télécharger la version indiquée.
- Un `ERROR:` bénin émis par le moteur peut faire échouer une étape : lire le journal avant de conclure.

## 6. Critère « terminé »
Le projet n'est considéré terminé que lorsque : le run est **vert**, l'artefact `eveil-web-VALIDE-*` contient `index.html/.js/.wasm/.pck`, et le jeu a été lancé dans Safari sur iPhone (checklist W2→W19).
