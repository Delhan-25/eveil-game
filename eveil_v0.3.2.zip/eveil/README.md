# ÉVEIL v0.3.2 — Prototype Chapitre 1 « Valbrume » (Godot 4.3+)

Jeu narratif 3D à la troisième personne. Vous incarnez Aël, 11 ans, qui découvre sa super-force.
Tout est généré par code (aucun asset externe, aucune dépendance payante) — personnages, village, UI.

## Version Web (iPhone/Safari, itch.io)
**Export Web NON produit ici** (Godot absent, réseau coupé). **Compilation automatique : `GITHUB_ACTIONS_WEB.md`** (workflow jamais exécuté). Procédure : `PUBLICATION_ITCH.md` ; tests : `WEB_TEST_CHECKLIST.md` ; état : `TEST_REPORT_WEB.md`.
`GODOT=/chemin/godot sh tools/export_web.sh` → `build/eveil_web_itch.zip`.

## Lancement
1. Installer **Godot 4.3 ou plus récent** (version standard, GDScript) : https://godotengine.org
2. Ouvrir `project.godot` dans l'éditeur (la première ouverture importe le projet et construit le cache des classes — **indispensable**, sinon les `class_name` ne sont pas reconnus).
3. Lancer avec F5 (scène principale : menu).
   En ligne de commande : `godot --headless --import` une fois, puis `godot --path .`.

### Commandes ordinateur
ZQSD/WASD ou flèches : bouger · Maj : courir · Espace : sauter · E/F/Entrée : interagir / continuer un dialogue ·
R : pouvoir · Échap ou P : pause · souris : caméra · F2 : afficher les commandes tactiles.
Pour tester le tactile à la souris : Paramètres du projet → Input Devices → Pointing → *Emulate Touch From Mouse*, puis F2 en jeu.

### Commandes smartphone (taille réglable dans le menu pause)
Joystick flottant (moitié gauche : inclinaison forte = course) · glisser dans la moitié droite = caméra ·
boutons SAUT / AGIR / POUVOIR / pause. Chaque doigt est suivi séparément (multitouch).

## Mission du chapitre
1. Parler à Maya (devant la ferme, à l'est du point de départ). 2. Ramasser la caisse (AGIR), la poser dans la grange (zone dorée).
3. Soulever la poutre qui bloque Noé : cinématique d'éveil de la Super-force, puis écran de fin de chapitre.
Un faisceau lumineux doré indique l'objectif.

## Structure
- `scripts/autoload/` : `Game` (entrées, sauvegarde JSON `user://eveil_save.json`), `Quests` (missions pilotées par données),
  `Dialogue` (répliques), `Powers` (registre extensible).
- `scripts/powers/` : `Power` (base) + `PowerSuperStrength`. Nouveau pouvoir = nouvelle classe + `register()` dans `power_manager.gd`.
- `scripts/player/` : Aël, caméra à ressort, constructeur de personnages.
- `scripts/world/` : monde, caisse, zones d'interaction. `scripts/ui/` : HUD, tactile, menus.
- `tests/smoke_test.gd` (état interne) et `tests/integration_test.gd` (parcours réel) ; `tools/run_tests.sh` les enchaîne.
- `tools/check_project.py` : analyse statique (équilibre des délimiteurs, références, appels d'autoloads).

## ⚠️ État des vérifications (honnêteté)
**Godot n'était pas disponible (ni réseau, ni SDK Android) : le projet n'a JAMAIS été exécuté, aucun APK n'existe, rien n'a été testé sur téléphone.**
Seule l'analyse statique `tools/check_project.py` a été lancée (OK). Voir `TEST_REPORT.md` (faits et blocages) et
`ACCEPTANCE_CHECKLIST.md` (tout « NON VÉRIFIÉ » sauf l'analyse statique). Ce lot **n'est pas validé** comme prototype jouable.

### Pour le valider (vous, avec Godot 4.3+)
```
GODOT=/chemin/vers/godot sh tools/run_tests.sh      # ou ./tools/run_tests.sh
```
Le lanceur retourne 0 seulement si TOUT réussit (1 = échec, 127 = Godot introuvable) ; journaux dans `build/logs/`.
Cela enchaîne import, démarrage du menu, `tests/smoke_test.gd` (état interne) et `tests/integration_test.gd`
(vrai parcours : interactions, caisse portée, cinématique, sauvegarde/rechargement, sauvegardes corrompues, multitouch injecté).
Joignez `build/logs/` à votre retour. Puis jouez la checklist manuelle, sur ordinateur puis sur téléphone.

## Nouveautés v0.3 (voir CHANGELOG.md)
Lanceur de tests corrigé (testé avec faux Godot), sauvegarde à version obligatoire et remplacement sans perte, parcours à pied testable (`docs/WALKTHROUGH_MANUEL.md`).

## Nouveautés v0.2
Sauvegarde cohérente (caisse portée/posée/livrée, validation anti-corruption), zones sûres + taille réglable des commandes
(menu pause), tests d'intégration, presets d'export modèles.

## Limites connues
- Aucun son ; personnages et décor en primitives ; carte plate ; seule la grange est enterable. Plan graphique : `docs/PLAN_PASSE_GRAPHIQUE.md`.
- Zones sûres et multitouch : implémentés mais jamais observés sur appareil.
- Une seule sauvegarde ; impossible de sauvegarder pendant une cinématique (par conception).

## Export (presets modèles fournis : `export_presets.cfg`, NON VÉRIFIÉS)

## Export Android
1. Installer JDK 17, Android SDK (command-line tools, platform-tools, build-tools 34, platform 34) ; dans Godot : *Éditeur → Paramètres → Export → Android* (chemins SDK/JDK).
2. *Projet → Installer le modèle de build Android* (Gradle), ou utiliser les templates d'export (*Gérer les modèles d'export*).
3. *Projet → Exporter → Ajouter… → Android* ; renseigner un identifiant (ex. `com.exemple.eveil`), version, keystore (debug auto, release : `keytool`), architectures arm64-v8a.
4. Orientation paysage déjà réglée. Rendu : Compatibility (déjà actif). Exporter en APK (test) ou AAB (Play Store).
5. Tester sur appareil : `adb install eveil.apk`.

## Export iOS
1. Nécessite un **Mac avec Xcode** et un compte Apple Developer.
2. Installer les modèles d'export Godot ; *Projet → Exporter → Ajouter… → iOS* : Team ID, Bundle Identifier, signature, descriptions d'usage.
3. Exporter : Godot génère un projet Xcode ; l'ouvrir, choisir l'appareil, signer, lancer (Run).
4. Distribution : Archive → TestFlight / App Store.

## Note export
Les mots de passe/keystores ne vont jamais dans le dépôt : saisissez-les dans l'éditeur Godot (Éditeur → Paramètres) ou par variables d'environnement.
Blocage à lever pour obtenir un APK : installer Android SDK (platform-tools, build-tools, platform), les modèles d'export Godot de **la même version** que l'éditeur,
puis `godot --headless --path . --export-debug "Android (test)" build/eveil-test.apk`. Pour iOS : Mac + Xcode + compte Apple Developer, aucune IPA n'est promise ici.
