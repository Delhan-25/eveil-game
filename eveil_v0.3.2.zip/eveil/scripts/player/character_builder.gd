class_name CharacterBuilder
extends RefCounted
## Construit un personnage low-poly à partir de primitives (aucun asset externe).
## Le personnage regarde vers -Z. Retourne un Dictionary de parties animables.


static func _mat(c: Color, emissive: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.95
	if emissive > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emissive
	return m


static func _mesh(parent: Node3D, mesh: Mesh, pos: Vector3, material: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mesh.material = material
	mi.mesh = mesh
	mi.position = pos
	parent.add_child(mi)
	return mi


static func _capsule(radius: float, height: float) -> CapsuleMesh:
	var c := CapsuleMesh.new()
	c.radius = radius
	c.height = height
	c.radial_segments = 10
	c.rings = 4
	return c


static func _sphere(radius: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = 12
	s.rings = 6
	return s


static func build(opts: Dictionary) -> Dictionary:
	var shirt: Color = opts.get("shirt", Color(0.12, 0.55, 0.62))
	var pants: Color = opts.get("pants", Color(0.15, 0.18, 0.3))
	var skin: Color = opts.get("skin", Color(0.93, 0.76, 0.62))
	var hair: Color = opts.get("hair", Color(0.18, 0.2, 0.35))
	var accent: Color = opts.get("accent", Color(0.92, 0.42, 0.2))
	var shoes: Color = opts.get("shoes", Color(0.25, 0.17, 0.12))
	var s: float = opts.get("scale", 1.0)
	var has_gem: bool = opts.get("gem", false)

	var root := Node3D.new()
	root.name = "Model"
	root.scale = Vector3.ONE * s
	var parts: Dictionary = {"root": root}

	var m_shirt := _mat(shirt)
	var m_pants := _mat(pants)
	var m_skin := _mat(skin)
	var m_hair := _mat(hair)
	var m_accent := _mat(accent)
	var m_shoes := _mat(shoes)

	# Jambes (pivot à la hanche)
	for side in [-1, 1]:
		var pivot := Node3D.new()
		pivot.position = Vector3(0.11 * side, 0.55, 0.0)
		root.add_child(pivot)
		_mesh(pivot, _capsule(0.075, 0.55), Vector3(0, -0.27, 0), m_pants)
		var foot := BoxMesh.new()
		foot.size = Vector3(0.14, 0.07, 0.22)
		_mesh(pivot, foot, Vector3(0, -0.53, -0.04), m_shoes)
		parts["leg_l" if side == -1 else "leg_r"] = pivot

	# Torse
	_mesh(root, _capsule(0.17, 0.52), Vector3(0, 0.82, 0), m_shirt)

	# Bras (pivot à l'épaule)
	for side in [-1, 1]:
		var pivot := Node3D.new()
		pivot.position = Vector3(0.235 * side, 1.03, 0.0)
		root.add_child(pivot)
		_mesh(pivot, _capsule(0.058, 0.46), Vector3(0, -0.2, 0), m_shirt)
		_mesh(pivot, _sphere(0.06), Vector3(0, -0.44, 0), m_skin)
		parts["arm_l" if side == -1 else "arm_r"] = pivot

	# Écharpe
	var torus := TorusMesh.new()
	torus.inner_radius = 0.12
	torus.outer_radius = 0.2
	torus.rings = 10
	torus.ring_segments = 6
	_mesh(root, torus, Vector3(0, 1.07, 0), m_accent)

	# Tête et cheveux
	var head := Node3D.new()
	head.position = Vector3(0, 1.22, 0)
	root.add_child(head)
	_mesh(head, _sphere(0.17), Vector3.ZERO, m_skin)
	var hair_mesh := _mesh(head, _sphere(0.18), Vector3(0, 0.05, 0.03), m_hair)
	hair_mesh.scale = Vector3(1.0, 0.75, 1.0)
	_mesh(head, _sphere(0.07), Vector3(0.0, 0.12, -0.12), m_hair)  # mèche
	for side in [-1, 1]:
		_mesh(head, _sphere(0.026), Vector3(0.065 * side, -0.01, -0.152), _mat(Color(0.08, 0.08, 0.1)))
	parts["head"] = head

	# Pendentif (cristal bleu qui s'illumine à l'éveil des pouvoirs)
	if has_gem:
		var gem_mat := _mat(Color(0.35, 0.8, 1.0), 0.8)
		var gem := _mesh(root, _sphere(0.045), Vector3(0, 0.98, -0.175), gem_mat)
		gem.scale = Vector3(1.0, 1.3, 0.8)
		parts["gem_mat"] = gem_mat

	return parts
