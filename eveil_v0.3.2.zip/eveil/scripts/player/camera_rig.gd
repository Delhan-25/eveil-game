class_name CameraRig
extends Node3D
## Caméra troisième personne : suivi lissé, orbite, bras à ressort anti-collision.

const MOUSE_SENS := 0.0025
const TOUCH_SENS := 0.0052
const PITCH_MIN := -1.15
const PITCH_MAX := 0.45

var yaw: float = 0.0
var pitch: float = -0.3
var target: Node3D
var follow_offset := Vector3(0.0, 1.45, 0.0)
var arm: SpringArm3D
var cam: Camera3D

var _first: bool = true
var _shake_time: float = 0.0
var _shake_total: float = 0.01
var _shake_strength: float = 0.0


func setup(t: Node3D) -> void:
	target = t
	top_level = true
	arm = SpringArm3D.new()
	arm.spring_length = 4.4
	arm.margin = 0.25
	arm.collision_mask = 1
	var sh := SphereShape3D.new()
	sh.radius = 0.2
	arm.shape = sh
	add_child(arm)
	cam = Camera3D.new()
	cam.fov = 68.0
	cam.near = 0.1
	cam.far = 300.0
	arm.add_child(cam)
	cam.make_current()


func shake(strength: float, duration: float) -> void:
	_shake_strength = maxf(_shake_strength, strength)
	_shake_time = maxf(_shake_time, duration)
	_shake_total = maxf(_shake_time, 0.01)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var mm := event as InputEventMouseMotion
		yaw -= mm.relative.x * MOUSE_SENS
		pitch = clampf(pitch - mm.relative.y * MOUSE_SENS, PITCH_MIN, PITCH_MAX)
	elif event is InputEventMouseButton and not Game.touch_active:
		var mb := event as InputEventMouseButton
		if mb.pressed and Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _process(delta: float) -> void:
	if target == null or not is_instance_valid(target):
		return
	var look: Vector2 = Game.touch_look
	Game.touch_look = Vector2.ZERO
	if look != Vector2.ZERO:
		yaw -= look.x * TOUCH_SENS
		pitch = clampf(pitch - look.y * TOUCH_SENS, PITCH_MIN, PITCH_MAX)

	var goal := target.global_position + follow_offset
	if _first:
		global_position = goal
		_first = false
	else:
		var kxz := 1.0 - exp(-16.0 * delta)
		var ky := 1.0 - exp(-8.0 * delta)
		var p := global_position
		p.x = lerpf(p.x, goal.x, kxz)
		p.z = lerpf(p.z, goal.z, kxz)
		p.y = lerpf(p.y, goal.y, ky)
		global_position = p
	rotation.y = yaw
	arm.rotation.x = pitch

	if _shake_time > 0.0:
		_shake_time -= delta
		var k := clampf(_shake_time / _shake_total, 0.0, 1.0)
		cam.h_offset = randf_range(-1.0, 1.0) * _shake_strength * k
		cam.v_offset = randf_range(-1.0, 1.0) * _shake_strength * k
	else:
		_shake_strength = 0.0
		cam.h_offset = 0.0
		cam.v_offset = 0.0
