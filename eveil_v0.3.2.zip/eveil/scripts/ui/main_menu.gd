extends Control
## Menu principal.

var _continue_btn: Button
var _status: Label


func _ready() -> void:
	theme = UiTheme.make()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	resized.connect(queue_redraw)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	center.add_child(box)

	var title := Label.new()
	title.text = "ÉVEIL"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 96)
	title.add_theme_color_override("font_color", Color(0.78, 0.93, 1.0))
	title.add_theme_constant_override("outline_size", 10)
	title.add_theme_color_override("font_outline_color", Color(0.05, 0.1, 0.25, 0.9))
	box.add_child(title)
	var sub := Label.new()
	sub.text = "Chapitre 1 — Valbrume"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 26)
	sub.add_theme_color_override("font_color", Color(1.0, 0.88, 0.5))
	box.add_child(sub)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 14)
	box.add_child(gap)

	box.add_child(_button("Nouvelle partie", _on_new))
	_continue_btn = _button("Continuer", _on_continue)
	_continue_btn.disabled = not Game.has_save()
	box.add_child(_continue_btn)
	if not (OS.has_feature("ios") or OS.has_feature("web")):
		box.add_child(_button("Quitter", _on_quit))

	_status = Label.new()
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.add_theme_font_size_override("font_size", 18)
	_status.add_theme_color_override("font_color", Color(1.0, 0.6, 0.5))
	box.add_child(_status)

	var ver := Label.new()
	ver.text = "Prototype v%s" % Game.VERSION
	ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ver.add_theme_font_size_override("font_size", 14)
	ver.add_theme_color_override("font_color", Color(0.6, 0.7, 0.85, 0.7))
	box.add_child(ver)


func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(420, 70)
	b.pressed.connect(cb)
	return b


func _on_new() -> void:
	Game.new_game()
	Game.start_world()


func _on_continue() -> void:
	if Game.load_game():
		Game.start_world()
	else:
		_status.text = Game.last_load_error


func _on_quit() -> void:
	get_tree().quit()


func _draw() -> void:
	var s := size
	var top := Color(0.07, 0.1, 0.28)
	var bottom := Color(0.55, 0.45, 0.55)
	draw_polygon(
		PackedVector2Array([Vector2.ZERO, Vector2(s.x, 0), s, Vector2(0, s.y)]),
		PackedColorArray([top, top, bottom, bottom]))
	for i in 45:
		var p := Vector2(fposmod(i * 97.3, s.x), fposmod(i * 53.1, s.y * 0.55))
		draw_circle(p, 1.4 + float(i % 3) * 0.4, Color(1, 1, 1, 0.35 + float(i % 4) * 0.12))
	draw_circle(Vector2(s.x * 0.76, s.y * 0.6), 80.0, Color(1.0, 0.85, 0.55, 0.22))
	draw_circle(Vector2(s.x * 0.76, s.y * 0.6), 46.0, Color(1.0, 0.9, 0.65, 0.5))
	_hills(s, 0.74, 0.05, 0.4, Color(0.16, 0.2, 0.34))
	_hills(s, 0.84, 0.045, 1.3, Color(0.07, 0.13, 0.2))


func _hills(s: Vector2, base: float, amp: float, phase: float, color: Color) -> void:
	var pts := PackedVector2Array()
	for i in 41:
		var x := s.x * float(i) / 40.0
		var y := s.y * (base + sin(float(i) * 0.45 + phase) * amp + sin(float(i) * 0.17 + phase * 2.0) * amp)
		pts.append(Vector2(x, y))
	pts.append(Vector2(s.x, s.y))
	pts.append(Vector2(0, s.y))
	draw_colored_polygon(pts, color)
