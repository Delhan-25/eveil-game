class_name ChapterEnd
extends CanvasLayer
## Écran de fin de chapitre.

var _stats: Label


func _ready() -> void:
	layer = 30
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.theme = UiTheme.make()
	add_child(root)
	var bg := ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.02, 0.04, 0.1, 0.9)
	root.add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	center.add_child(box)

	box.add_child(_label("CHAPITRE 1 TERMINÉ", 52, Color(1.0, 0.88, 0.4)))
	box.add_child(_label("L'éveil", 34, Color(0.75, 0.92, 1.0)))
	_stats = _label("", 22, Color.WHITE)
	box.add_child(_stats)
	box.add_child(_label("À suivre : Chapitre 2 — L'adolescence", 20, Color(0.7, 0.8, 0.95)))
	var b1 := Button.new()
	b1.text = "Continuer à explorer"
	b1.custom_minimum_size = Vector2(420, 68)
	b1.pressed.connect(_on_continue)
	box.add_child(b1)
	var b2 := Button.new()
	b2.text = "Menu principal"
	b2.custom_minimum_size = Vector2(420, 68)
	b2.pressed.connect(_on_menu)
	box.add_child(b2)


func _label(text: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


func show_end() -> void:
	var secs := int(Game.play_time)
	_stats.text = "Temps de jeu : %02d:%02d\nÉtapes accomplies : 3 / 3\nPouvoir débloqué : Super-force" % [floori(secs / 60.0), secs % 60]
	Game.release_all_actions()
	Game.chapter_screen_open = true
	get_tree().paused = true
	visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _on_continue() -> void:
	visible = false
	Game.chapter_screen_open = false
	Game.flags["chapter_end_seen"] = true
	get_tree().paused = false
	if not Game.touch_active:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	Game.save_game()


func _on_menu() -> void:
	Game.flags["chapter_end_seen"] = true
	Game.save_game()
	visible = false
	Game.chapter_screen_open = false
	Game.go_to_menu()
