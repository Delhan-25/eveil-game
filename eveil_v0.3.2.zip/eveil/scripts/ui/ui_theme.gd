class_name UiTheme
extends RefCounted
## Thème d'interface commun (boutons larges, adaptés au tactile).


static func _box(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(14)
	return sb


static func make() -> Theme:
	var t := Theme.new()
	t.default_font_size = 22
	t.set_stylebox("normal", "Button", _box(Color(0.10, 0.17, 0.28, 0.95), Color(0.45, 0.75, 1.0, 0.9)))
	t.set_stylebox("hover", "Button", _box(Color(0.16, 0.26, 0.42, 0.98), Color(0.7, 0.9, 1.0, 1.0)))
	t.set_stylebox("pressed", "Button", _box(Color(0.06, 0.11, 0.2, 1.0), Color(1.0, 0.85, 0.4, 1.0)))
	t.set_stylebox("disabled", "Button", _box(Color(0.12, 0.12, 0.14, 0.8), Color(0.35, 0.35, 0.4, 0.6)))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", Color(1, 1, 1))
	t.set_color("font_hover_color", "Button", Color(1, 1, 1))
	t.set_color("font_pressed_color", "Button", Color(1.0, 0.9, 0.5))
	t.set_color("font_disabled_color", "Button", Color(0.55, 0.55, 0.6))
	t.set_font_size("font_size", "Button", 26)
	t.set_stylebox("panel", "PanelContainer", _box(Color(0.04, 0.07, 0.13, 0.88), Color(0.45, 0.75, 1.0, 0.55)))
	return t
