class_name PauseMenu
extends CanvasLayer
## Menu pause : Reprendre / Sauvegarder / Menu principal.

var _status: Label
var _scale_label: Label
var _shadow_btn: Button
var _fps_btn: Button


func _ready() -> void:
	layer = 20
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	Game.pause_requested.connect(open)

	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.theme = UiTheme.make()
	add_child(root)
	var dim := ColorRect.new()
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0.02, 0.06, 0.7)
	root.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	panel.add_child(box)
	var title := Label.new()
	title.text = "PAUSE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 40)
	title.add_theme_color_override("font_color", Color(1.0, 0.9, 0.5))
	box.add_child(title)
	box.add_child(_button("Reprendre", close))
	box.add_child(_button("Sauvegarder", _on_save))
	box.add_child(_button("Menu principal", _on_menu))
	_scale_label = Label.new()
	_scale_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_scale_label.add_theme_font_size_override("font_size", 20)
	box.add_child(_scale_label)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 20)
	var minus := _button("−", _on_scale_minus)
	minus.custom_minimum_size = Vector2(120, 60)
	var plus := _button("+", _on_scale_plus)
	plus.custom_minimum_size = Vector2(120, 60)
	row.add_child(minus)
	row.add_child(plus)
	box.add_child(row)
	var qrow := HBoxContainer.new()
	qrow.alignment = BoxContainer.ALIGNMENT_CENTER
	qrow.add_theme_constant_override("separation", 16)
	_shadow_btn = _button("", _on_shadows)
	_shadow_btn.custom_minimum_size = Vector2(250, 58)
	_fps_btn = _button("", _on_fps)
	_fps_btn.custom_minimum_size = Vector2(250, 58)
	qrow.add_child(_shadow_btn)
	qrow.add_child(_fps_btn)
	box.add_child(qrow)
	_status = Label.new()
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.add_theme_font_size_override("font_size", 18)
	_status.add_theme_color_override("font_color", Color(0.6, 0.9, 0.7))
	box.add_child(_status)


func _button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(420, 68)
	b.pressed.connect(cb)
	return b


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		if visible:
			close()
		else:
			open()
		get_viewport().set_input_as_handled()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:  # bouton Retour d'Android
		if visible:
			close()
		else:
			open()


func open() -> void:
	if visible or Game.input_locked or Game.chapter_screen_open or not Game.in_game:
		return
	Game.release_all_actions()
	_status.text = ""
	_refresh_scale_label()
	_refresh_quality_labels()
	get_tree().paused = true
	visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func close() -> void:
	if not visible:
		return
	visible = false
	get_tree().paused = false
	if not Game.touch_active:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _on_save() -> void:
	if Game.save_game():
		_status.text = "Partie sauvegardée."
	else:
		_status.text = "Échec : %s" % Game.last_save_error


func _refresh_scale_label() -> void:
	_scale_label.text = "Taille des commandes tactiles : %d %%" % int(round(Game.touch_scale * 100.0))


func _refresh_quality_labels() -> void:
	_shadow_btn.text = "Ombres : %s" % ("oui" if Game.shadows_enabled else "non")
	_fps_btn.text = "FPS : %s" % ("oui" if Game.show_fps else "non")


func _on_shadows() -> void:
	Game.set_shadows(not Game.shadows_enabled)
	_refresh_quality_labels()


func _on_fps() -> void:
	Game.set_show_fps(not Game.show_fps)
	_refresh_quality_labels()


func _on_scale_minus() -> void:
	Game.set_touch_scale(Game.touch_scale - 0.1)
	_refresh_scale_label()


func _on_scale_plus() -> void:
	Game.set_touch_scale(Game.touch_scale + 0.1)
	_refresh_scale_label()


func _on_menu() -> void:
	Game.save_game()
	visible = false
	Game.go_to_menu()
