class_name GameHud
extends CanvasLayer
## Interface en jeu : objectif, dialogues, messages, bannière de pouvoir, flash.

var _root: Control
var _obj_title: Label
var _obj_hint: Label
var _prompt: Label
var _dlg_panel: PanelContainer
var _dlg_speaker: Label
var _dlg_text: Label
var _dlg_hint: Label
var _toast: Label
var _banner: PanelContainer
var _banner_title: Label
var _banner_sub: Label
var _flash: ColorRect
var _help: Label
var _power_label: Label
var _toast_tween: Tween
var _banner_tween: Tween
var _help_time: float = 16.0
var _layout_timer: float = 0.0
var _fps: Label


func _ready() -> void:
	layer = 10
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.theme = UiTheme.make()
	add_child(_root)

	_build_objective()
	_build_prompt()
	_build_dialogue()
	_build_toast()
	_build_banner()
	_build_help()
	_build_flash()
	_build_fps()

	Game.toast_requested.connect(show_toast)
	Game.prompt_changed.connect(_on_prompt_changed)
	Game.banner_requested.connect(show_banner)
	Game.flash_requested.connect(flash)
	Quests.step_changed.connect(_on_step_changed)
	Quests.quest_completed.connect(_update_objective)
	Dialogue.dialogue_started.connect(_on_dialogue_started)
	Dialogue.line_shown.connect(_on_line_shown)
	Dialogue.finished.connect(_on_dialogue_finished)
	Game.touch_scale_changed.connect(_apply_layout)
	Game.quality_changed.connect(_refresh_fps_visibility)
	_update_objective()
	_apply_layout()


func _label(text: String, size: int, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _outline(l: Label) -> void:
	l.add_theme_constant_override("outline_size", 6)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))


func _build_objective() -> void:
	var p := PanelContainer.new()
	p.position = Vector2(16, 16)
	p.custom_minimum_size = Vector2(330, 0)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(p)
	var v := VBoxContainer.new()
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(v)
	v.add_child(_label("OBJECTIF", 14, Color(0.55, 0.8, 1.0)))
	_obj_title = _label("", 24, Color(1.0, 0.92, 0.6))
	_obj_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_obj_title)
	_obj_hint = _label("", 16, Color(0.85, 0.88, 0.95))
	_obj_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_obj_hint)


func _build_prompt() -> void:
	_prompt = _label("", 26, Color(1, 1, 1))
	_outline(_prompt)
	_prompt.anchor_left = 0.25
	_prompt.anchor_right = 0.75
	_prompt.anchor_top = 0.78
	_prompt.anchor_bottom = 0.86
	_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_prompt.visible = false
	_root.add_child(_prompt)


func _build_dialogue() -> void:
	_dlg_panel = PanelContainer.new()
	_dlg_panel.anchor_left = 0.04
	_dlg_panel.anchor_right = 0.70
	_dlg_panel.anchor_top = 0.68
	_dlg_panel.anchor_bottom = 0.96
	_dlg_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_dlg_panel.visible = false
	_dlg_panel.gui_input.connect(_on_dialogue_gui_input)
	_root.add_child(_dlg_panel)
	var v := VBoxContainer.new()
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_dlg_panel.add_child(v)
	_dlg_speaker = _label("", 26, Color(1.0, 0.85, 0.4))
	v.add_child(_dlg_speaker)
	_dlg_text = _label("", 24, Color.WHITE)
	_dlg_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_dlg_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(_dlg_text)
	var hint := "Touche « Agir » pour continuer" if Game.touch_active else "[E] pour continuer"
	_dlg_hint = _label(hint, 15, Color(0.6, 0.8, 1.0))
	_dlg_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	v.add_child(_dlg_hint)


func _build_toast() -> void:
	_toast = _label("", 24, Color(1, 1, 1))
	_outline(_toast)
	_toast.anchor_left = 0.2
	_toast.anchor_right = 0.8
	_toast.anchor_top = 0.08
	_toast.anchor_bottom = 0.16
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_toast.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast.modulate.a = 0.0
	_root.add_child(_toast)


func _build_banner() -> void:
	_banner = PanelContainer.new()
	_banner.anchor_left = 0.22
	_banner.anchor_right = 0.78
	_banner.anchor_top = 0.28
	_banner.anchor_bottom = 0.5
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.modulate.a = 0.0
	_root.add_child(_banner)
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.add_child(v)
	_banner_title = _label("", 40, Color(1.0, 0.88, 0.4))
	_banner_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_banner_title)
	_banner_sub = _label("", 26, Color(0.8, 0.93, 1.0))
	_banner_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner_sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_banner_sub)


func _build_help() -> void:
	_power_label = _label("", 18, Color(0.7, 0.9, 1.0))
	_outline(_power_label)
	_power_label.anchor_left = 0.5
	_power_label.anchor_right = 0.98
	_power_label.anchor_top = 0.02
	_power_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_root.add_child(_power_label)
	if Game.touch_active:
		return
	_help = _label("WASD/ZQSD : bouger · Maj : courir · Espace : sauter · E : interagir · R : pouvoir · Échap : pause", 15, Color(0.9, 0.95, 1.0))
	_outline(_help)
	_help.anchor_left = 0.02
	_help.anchor_right = 0.98
	_help.anchor_top = 0.96
	_help.anchor_bottom = 1.0
	_help.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_root.add_child(_help)


func _build_fps() -> void:
	_fps = _label("", 16, Color(0.7, 1.0, 0.7))
	_outline(_fps)
	_fps.anchor_left = 0.4
	_fps.anchor_right = 0.6
	_fps.anchor_top = 0.0
	_fps.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_root.add_child(_fps)
	_refresh_fps_visibility()


func _refresh_fps_visibility() -> void:
	_fps.visible = Game.show_fps


func _build_flash() -> void:
	_flash = ColorRect.new()
	_flash.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_flash.color = Color(1, 1, 1, 1)
	_flash.modulate.a = 0.0
	_flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_flash)


# ---------------------------------------------------------------- Mise à jour

func _apply_layout() -> void:
	var ins := Game.get_safe_insets()
	_root.offset_left = float(ins["left"])
	_root.offset_top = float(ins["top"])
	_root.offset_right = -float(ins["right"])
	_root.offset_bottom = -float(ins["bottom"])
	if Game.touch_active:
		# Le dialogue s'arrête avant la zone des boutons tactiles.
		_dlg_panel.anchor_right = 1.0
		_dlg_panel.offset_right = -(330.0 * Game.touch_scale)
	else:
		_dlg_panel.anchor_right = 0.70
		_dlg_panel.offset_right = 0.0


func _process(delta: float) -> void:
	if _fps.visible:
		_fps.text = "%d FPS" % int(Engine.get_frames_per_second())
	_layout_timer += delta
	if _layout_timer > 0.5:
		_layout_timer = 0.0
		_apply_layout()
	if Dialogue.active:
		_dlg_text.visible_characters = int(Dialogue.reveal)
		_dlg_hint.visible = Dialogue.reveal >= float(Dialogue.current_length)
	if _help != null and _help_time > 0.0:
		_help_time -= delta
		if _help_time <= 0.0:
			_help.visible = false
	_update_power_label()


func _update_power_label() -> void:
	var p := Powers.selected_power()
	if p == null:
		_power_label.text = ""
		return
	var key := "" if Game.touch_active else "[R] "
	if p.active:
		_power_label.text = "%s%s : actif (%d s)" % [key, p.display_name, ceili(p.time_left)]
	elif p.cooldown_left > 0.0:
		_power_label.text = "%s%s : recharge (%d s)" % [key, p.display_name, ceili(p.cooldown_left)]
	else:
		_power_label.text = "%s%s : prêt" % [key, p.display_name]


func _update_objective() -> void:
	if Quests.chapter_done:
		_obj_title.text = "Chapitre terminé"
		_obj_hint.text = "Explore Valbrume librement."
	else:
		var s := Quests.current_step()
		_obj_title.text = String(s["title"])
		_obj_hint.text = String(s["hint"])


func _on_step_changed(_i: int) -> void:
	_update_objective()
	show_toast("Nouvel objectif : %s" % String(Quests.current_step()["title"]))


func _on_prompt_changed(text: String) -> void:
	_prompt.visible = text != ""
	if text != "":
		_prompt.text = text if Game.touch_active else "[E] %s" % text


func _on_dialogue_started() -> void:
	_dlg_panel.visible = true


func _on_line_shown(speaker: String, text: String) -> void:
	_dlg_speaker.text = speaker
	_dlg_speaker.visible = speaker != ""
	_dlg_text.text = text
	_dlg_text.visible_characters = 0
	_dlg_hint.visible = false


func _on_dialogue_finished() -> void:
	_dlg_panel.visible = false


func _on_dialogue_gui_input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton:
		var mb := ev as InputEventMouseButton
		if mb.pressed and mb.button_index == MOUSE_BUTTON_LEFT:
			Dialogue.advance()


func show_toast(text: String) -> void:
	_toast.text = text
	if _toast_tween != null and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(2.6)
	_toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.6)


func show_banner(title: String, subtitle: String) -> void:
	_banner_title.text = title
	_banner_sub.text = subtitle
	if _banner_tween != null and _banner_tween.is_valid():
		_banner_tween.kill()
	_banner.modulate.a = 0.0
	_banner_tween = create_tween()
	_banner_tween.tween_property(_banner, "modulate:a", 1.0, 0.4)
	_banner_tween.tween_interval(3.2)
	_banner_tween.tween_property(_banner, "modulate:a", 0.0, 0.7)


func flash(duration: float) -> void:
	_flash.modulate.a = 0.95
	var tw := create_tween()
	tw.tween_property(_flash, "modulate:a", 0.0, duration)
