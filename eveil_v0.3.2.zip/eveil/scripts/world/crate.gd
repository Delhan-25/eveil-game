class_name Crate
extends Node3D
## Caisse de provisions transportable.

var body: StaticBody3D
var interactable: Interactable
var carried: bool = false
var delivered: bool = false


func _ready() -> void:
	body = StaticBody3D.new()
	body.collision_layer = 16
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(0.7, 0.7, 0.7)
	cs.shape = bs
	body.add_child(cs)
	add_child(body)

	var wood := StandardMaterial3D.new()
	wood.albedo_color = Color(0.62, 0.43, 0.22)
	wood.roughness = 1.0
	var strap := StandardMaterial3D.new()
	strap.albedo_color = Color(0.33, 0.21, 0.1)
	strap.roughness = 1.0

	_add_mesh(Vector3(0.7, 0.7, 0.7), Vector3.ZERO, wood)
	_add_mesh(Vector3(0.74, 0.1, 0.74), Vector3(0, 0.22, 0), strap)
	_add_mesh(Vector3(0.74, 0.1, 0.74), Vector3(0, -0.22, 0), strap)
	_add_mesh(Vector3(0.1, 0.74, 0.74), Vector3(0.22, 0, 0), strap)
	_add_mesh(Vector3(0.1, 0.74, 0.74), Vector3(-0.22, 0, 0), strap)

	interactable = Interactable.create(self, Vector3.ZERO, 1.0, "Ramasser la caisse")


func _add_mesh(size: Vector3, pos: Vector3, material: Material) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	bm.material = material
	mi.mesh = bm
	mi.position = pos
	add_child(mi)


func set_carried(on: bool) -> void:
	carried = on
	body.collision_layer = 0 if on else 16


func mark_delivered() -> void:
	delivered = true
	carried = false
	body.collision_layer = 16
	interactable.enabled = false
