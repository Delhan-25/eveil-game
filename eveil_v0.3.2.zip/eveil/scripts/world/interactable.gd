class_name Interactable
extends Area3D
## Zone d'interaction (calque 4 = valeur 8). Détectée par le capteur du joueur.

signal interacted(player: Node3D)

var prompt: String = "Interagir"
var enabled: bool = true
var available_check: Callable = Callable()


func _init() -> void:
	collision_layer = 8
	collision_mask = 0
	monitoring = false
	monitorable = true


func is_available() -> bool:
	if not enabled:
		return false
	if available_check.is_valid():
		return bool(available_check.call())
	return true


func interact(player: Node3D) -> void:
	interacted.emit(player)


static func create(parent: Node, pos: Vector3, radius: float, prompt_text: String) -> Interactable:
	var it := Interactable.new()
	it.prompt = prompt_text
	it.position = pos
	var cs := CollisionShape3D.new()
	var sp := SphereShape3D.new()
	sp.radius = radius
	cs.shape = sp
	it.add_child(cs)
	parent.add_child(it)
	return it
