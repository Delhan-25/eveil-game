extends Node3D
## Valbrume : monde 3D construit entièrement par code (aucun asset externe).
## Contient aussi la logique de la mission du Chapitre 1.

const BARN_ORIGIN := Vector3(34.0, 0.0, -12.0)
const MAYA_POS := Vector3(14.5, 0.0, -5.5)
const CRATE_START := Vector3(18.6, 0.35, -5.6)
const PLAYER_START := Vector3(6.0, 0.2, -0.5)

# Positions de la scène du sauvetage, relatives à BARN_ORIGIN.
const BEAM_LOCAL := Vector3(3.0, 0.7, -1.7)
const BEAM_ASIDE_LOCAL := Vector3(3.0, 0.25, 3.0)
const NOE_LYING_LOCAL := Vector3(3.0, 0.22, -2.2)
const NOE_FREE_LOCAL := Vector3(3.0, 0.0, -3.8)
const RESCUE_STAND_LOCAL := Vector3(0.25, 0.0, -1.7)
const CRATE_DELIVERED_LOCAL := Vector3(-3.6, 0.35, -3.6)
const ZONE_LOCAL := Vector3(-2.0, 0.8, 0.0)

var player: Player
var hud: GameHud
var pause_menu: PauseMenu
var chapter_end: ChapterEnd
var touch_controls: TouchControls

var maya: Node3D
var tobias: Node3D
var noe: Node3D
var crate: Crate
var beam: Node3D
var beam_body: StaticBody3D
var barn_zone: Interactable
var zone_marker: MeshInstance3D
var beacon: MeshInstance3D
var noe_talk: Interactable
var sun: DirectionalLight3D

var _mats: Dictionary = {}
var _keepouts: Array[Rect2] = []
var _rescue_running: bool = false


func _ready() -> void:
	Game.ensure_started()
	_build_environment()
	_build_ground()
	_build_roads()
	_build_farm()
	_build_barn()
	_build_village()
	_build_props()
	_build_trees()
	_build_backdrop()
	_build_npcs()
	_build_quest_objects()
	_spawn_player()
	_build_ui()
	Game.world_snapshot = _snapshot
	Game.quality_changed.connect(_apply_quality)
	Quests.step_changed.connect(_on_step_changed)
	Quests.quest_completed.connect(_on_quest_completed)
	_apply_saved_state()
	_update_markers()
	if not Game.touch_active:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_start_intro()


func _apply_quality() -> void:
	if sun != null:
		sun.shadow_enabled = Game.shadows_enabled


func _exit_tree() -> void:
	Game.world_snapshot = Callable()
	Powers.deactivate_all()
	Game.set_prompt("")


func _process(_delta: float) -> void:
	_update_beacon()


# =================================================================== Helpers

func mat(c: Color, double_sided: bool = false, emissive: float = 0.0) -> StandardMaterial3D:
	var key := "%s_%s_%s" % [c.to_html(true), double_sided, emissive]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 1.0
	if double_sided:
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
	if emissive > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emissive
	if c.a < 0.99:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_mats[key] = m
	return m


func _static_body(pos: Vector3, rot_y: float, shape: Shape3D) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	body.position = pos
	body.rotation.y = rot_y
	var cs := CollisionShape3D.new()
	cs.shape = shape
	body.add_child(cs)
	return body


func add_box(parent: Node, pos: Vector3, size: Vector3, color: Color,
		collide: bool = true, rot_y: float = 0.0) -> Node3D:
	var node: Node3D
	if collide:
		var bs := BoxShape3D.new()
		bs.size = size
		node = _static_body(pos, rot_y, bs)
	else:
		node = Node3D.new()
		node.position = pos
		node.rotation.y = rot_y
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	bm.material = mat(color)
	mi.mesh = bm
	node.add_child(mi)
	parent.add_child(node)
	return node


func add_cyl(parent: Node, pos: Vector3, radius: float, height: float, color: Color,
		collide: bool = true, top_radius: float = -1.0) -> Node3D:
	var node: Node3D
	if collide:
		var cs := CylinderShape3D.new()
		cs.radius = radius
		cs.height = height
		node = _static_body(pos, 0.0, cs)
	else:
		node = Node3D.new()
		node.position = pos
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.bottom_radius = radius
	cm.top_radius = radius if top_radius < 0.0 else top_radius
	cm.height = height
	cm.radial_segments = 14
	cm.rings = 1
	cm.material = mat(color)
	mi.mesh = cm
	node.add_child(mi)
	parent.add_child(node)
	return node


func _keep(cx: float, cz: float, half_w: float, half_d: float) -> void:
	_keepouts.append(Rect2(cx - half_w, cz - half_d, half_w * 2.0, half_d * 2.0))


func _is_free(x: float, z: float, margin: float) -> bool:
	var p := Vector2(x, z)
	for r in _keepouts:
		if r.grow(margin).has_point(p):
			return false
	return true


# =================================================================== Environnement

func _build_environment() -> void:
	var env := Environment.new()
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.27, 0.52, 0.86)
	sm.sky_horizon_color = Color(0.72, 0.84, 0.93)
	sm.ground_horizon_color = Color(0.62, 0.74, 0.7)
	sm.ground_bottom_color = Color(0.3, 0.42, 0.3)
	sky.sky_material = sm
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.74, 0.83, 0.9)
	env.fog_density = 0.004
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52.0, -38.0, 0.0)
	sun.light_energy = 1.15
	sun.light_color = Color(1.0, 0.96, 0.88)
	sun.shadow_enabled = Game.shadows_enabled
	sun.directional_shadow_max_distance = 50.0
	add_child(sun)


func _build_ground() -> void:
	add_box(self, Vector3(0, -0.5, 0), Vector3(150, 1, 150), Color(0.36, 0.55, 0.28))
	add_box(self, Vector3(0, -0.6, 0), Vector3(900, 0.1, 900), Color(0.3, 0.46, 0.25), false)
	# Murs invisibles aux limites de la carte.
	for s in [-1, 1]:
		var wz := _static_body(Vector3(0, 5, 75.0 * s), 0.0, _box_shape(Vector3(152, 12, 2)))
		add_child(wz)
		var wx := _static_body(Vector3(75.0 * s, 5, 0), 0.0, _box_shape(Vector3(2, 12, 152)))
		add_child(wx)


func _box_shape(size: Vector3) -> BoxShape3D:
	var b := BoxShape3D.new()
	b.size = size
	return b


func _build_roads() -> void:
	var dirt := Color(0.58, 0.47, 0.34)
	var stone := Color(0.62, 0.62, 0.6)
	add_box(self, Vector3(0, 0.02, 0), Vector3(140, 0.04, 5), dirt, false)
	add_box(self, Vector3(0, 0.03, 0), Vector3(5, 0.04, 140), dirt, false)
	add_cyl(self, Vector3(0, 0.03, 0), 5.5, 0.06, stone, false)
	_keep(0, 0, 72, 3.5)
	_keep(0, 0, 3.5, 72)
	# Chemins de la ferme
	add_box(self, Vector3(16, 0.025, -5.25), Vector3(2.6, 0.05, 5.5), dirt, false)
	add_box(self, Vector3(20, 0.03, -5.5), Vector3(8, 0.05, 2.2), dirt, false)
	add_box(self, Vector3(24, 0.034, -8.75), Vector3(2.2, 0.05, 7.0), dirt, false)
	add_box(self, Vector3(26.2, 0.038, -12), Vector3(4.6, 0.05, 2.6), dirt, false)


# =================================================================== Bâtiments

func _gable_roof(parent: Node3D, base_y: float, w: float, d: float, rise: float,
		roof_color: Color, wall_color: Color) -> void:
	# Faîtage selon X. Les deux pans sont des dalles inclinées, pignons en prisme.
	var half := d * 0.5 + 0.25
	var ang := atan2(rise, half)
	var slab_len := sqrt(half * half + rise * rise) + 0.05
	for s in [-1, 1]:
		var slab := Node3D.new()
		slab.position = Vector3(0, base_y + rise * 0.5 + 0.1, s * half * 0.5)
		slab.rotation.x = ang * s
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(w + 0.5, 0.18, slab_len)
		bm.material = mat(roof_color, true)
		mi.mesh = bm
		slab.add_child(mi)
		parent.add_child(slab)
	var pm := PrismMesh.new()
	pm.size = Vector3(d, rise, w + 0.04)
	pm.material = mat(wall_color)
	var prism := MeshInstance3D.new()
	prism.mesh = pm
	prism.rotation_degrees.y = 90.0
	prism.position = Vector3(0, base_y + rise * 0.5, 0)
	parent.add_child(prism)


func _house(pos: Vector3, rot_deg: float, w: float, d: float, h: float,
		wall_c: Color, roof_c: Color, door_c: Color = Color(0.35, 0.22, 0.14)) -> Node3D:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_deg
	add_child(root)
	add_box(root, Vector3(0, h * 0.5, 0), Vector3(w, h, d), wall_c)
	_gable_roof(root, h, w, d, 1.6, roof_c, wall_c)
	add_box(root, Vector3(0, 1.05, d * 0.5 + 0.03), Vector3(1.1, 2.1, 0.06), door_c, false)
	for x in [-w * 0.3, w * 0.3]:
		add_box(root, Vector3(x, 1.7, d * 0.5 + 0.03), Vector3(0.9, 0.9, 0.06), Color(0.6, 0.8, 0.95), false)
	_keep(pos.x, pos.z, w * 0.5 + 1.5, d * 0.5 + 1.5)
	return root


func _build_farm() -> void:
	var farmhouse := _house(Vector3(16, 0, -11), 0.0, 8.0, 6.0, 3.2,
		Color(0.95, 0.9, 0.78), Color(0.7, 0.3, 0.2))
	add_box(farmhouse, Vector3(2.2, 4.4, -1.0), Vector3(0.6, 2.0, 0.6), Color(0.55, 0.3, 0.25), false)
	# Porche
	add_box(farmhouse, Vector3(0, 0.15, 3.9), Vector3(2.8, 0.3, 1.6), Color(0.5, 0.36, 0.22))
	# Enclos : x 8..43, z -21..-3.5, ouverture au sud entre x 13 et 19.
	_keep(25.5, -12.2, 20.5, 11.5)
	_fence(Vector3(8, 0, -21), Vector3(43, 0, -21))
	_fence(Vector3(43, 0, -21), Vector3(43, 0, -3.5))
	_fence(Vector3(43, 0, -3.5), Vector3(19, 0, -3.5))
	_fence(Vector3(13, 0, -3.5), Vector3(8, 0, -3.5))
	_fence(Vector3(8, 0, -3.5), Vector3(8, 0, -21))
	# Silo
	add_cyl(self, Vector3(36, 3.2, -19.3), 1.8, 6.4, Color(0.78, 0.8, 0.84))
	add_cyl(self, Vector3(36, 7.1, -19.3), 1.9, 1.4, Color(0.7, 0.28, 0.22), false, 0.0)
	# Bottes de foin et tonneaux
	var hay := Color(0.86, 0.73, 0.36)
	add_box(self, Vector3(23.0, 0.4, -17.5), Vector3(1.3, 0.8, 0.9), hay)
	add_box(self, Vector3(24.5, 0.4, -17.5), Vector3(1.3, 0.8, 0.9), hay)
	add_box(self, Vector3(23.7, 1.2, -17.5), Vector3(1.3, 0.8, 0.9), hay)
	add_cyl(self, Vector3(20.9, 0.45, -9.0), 0.4, 0.9, Color(0.5, 0.33, 0.2))
	add_cyl(self, Vector3(20.9, 0.45, -10.0), 0.4, 0.9, Color(0.5, 0.33, 0.2))
	# Potager
	for i in 4:
		add_box(self, Vector3(12.0, 0.1, -16.5 - i * 1.1), Vector3(6.0, 0.2, 0.6),
			Color(0.3 + 0.05 * i, 0.5, 0.22), false)


func _fence(a: Vector3, b: Vector3) -> void:
	var diff := b - a
	diff.y = 0.0
	var length := diff.length()
	if length < 0.1:
		return
	var dir := diff / length
	var yaw := atan2(-dir.z, dir.x)
	var mid := (a + b) * 0.5
	var wood := Color(0.52, 0.37, 0.22)
	# Collision invisible + lattes décoratives.
	add_child(_static_body(mid + Vector3(0, 0.55, 0), yaw, _box_shape(Vector3(length, 1.1, 0.25))))
	add_box(self, mid + Vector3(0, 0.45, 0), Vector3(length, 0.08, 0.06), wood, false, yaw)
	add_box(self, mid + Vector3(0, 0.9, 0), Vector3(length, 0.08, 0.06), wood, false, yaw)
	var n := maxi(1, ceili(length / 2.0))
	for i in n + 1:
		var p := a + dir * (length * float(i) / float(n))
		add_box(self, p + Vector3(0, 0.55, 0), Vector3(0.12, 1.1, 0.12), wood.darkened(0.15), false)


func _build_barn() -> void:
	var root := Node3D.new()
	root.name = "Barn"
	root.position = BARN_ORIGIN
	add_child(root)
	var red := Color(0.62, 0.2, 0.17)
	var trim := Color(0.93, 0.9, 0.84)
	# Murs (ouverture de 4 m côté ouest, en z = -2..2 local)
	add_box(root, Vector3(0, 2.5, -5.0), Vector3(12.4, 5, 0.4), red)
	add_box(root, Vector3(0, 2.5, 5.0), Vector3(12.4, 5, 0.4), red)
	add_box(root, Vector3(6.0, 2.5, 0), Vector3(0.4, 5, 10.0), red)
	add_box(root, Vector3(-6.0, 2.5, -3.5), Vector3(0.4, 5, 3.0), red)
	add_box(root, Vector3(-6.0, 2.5, 3.5), Vector3(0.4, 5, 3.0), red)
	add_box(root, Vector3(-6.0, 4.2, 0), Vector3(0.4, 1.6, 4.0), red)
	# Cadre de la porte
	add_box(root, Vector3(-6.25, 1.7, -2.1), Vector3(0.15, 3.4, 0.2), trim, false)
	add_box(root, Vector3(-6.25, 1.7, 2.1), Vector3(0.15, 3.4, 0.2), trim, false)
	add_box(root, Vector3(-6.25, 3.45, 0), Vector3(0.15, 0.2, 4.4), trim, false)
	# Sol de paille et toit à double pente
	add_box(root, Vector3(0, 0.025, 0), Vector3(11.6, 0.05, 9.6), Color(0.78, 0.66, 0.4), false)
	_gable_roof(root, 5.0, 12.4, 10.4, 3.0, Color(0.36, 0.3, 0.28), red)
	# Éclairage intérieur
	var lamp := OmniLight3D.new()
	lamp.position = Vector3(0, 3.8, 0)
	lamp.light_color = Color(1.0, 0.86, 0.6)
	lamp.light_energy = 2.2
	lamp.omni_range = 11.0
	root.add_child(lamp)
	var lamp2 := OmniLight3D.new()
	lamp2.position = Vector3(3.0, 3.0, -2.0)
	lamp2.light_color = Color(1.0, 0.9, 0.7)
	lamp2.light_energy = 1.6
	lamp2.omni_range = 7.0
	root.add_child(lamp2)
	# Décor intérieur
	var hay := Color(0.86, 0.73, 0.36)
	add_box(root, Vector3(-4.3, 0.4, 3.9), Vector3(1.2, 0.8, 0.8), hay)
	add_box(root, Vector3(-3.0, 0.4, 3.9), Vector3(1.2, 0.8, 0.8), hay)
	add_box(root, Vector3(-3.7, 1.2, 3.9), Vector3(1.2, 0.8, 0.8), hay)
	add_cyl(root, Vector3(5.1, 0.5, 3.6), 0.4, 1.0, Color(0.5, 0.33, 0.2))
	add_cyl(root, Vector3(5.1, 0.5, 4.4), 0.4, 1.0, Color(0.5, 0.33, 0.2))
	add_box(root, Vector3(1.5, 0.5, 4.2), Vector3(2.0, 1.0, 1.0), hay)
	# Zone de dépôt de la caisse
	barn_zone = Interactable.create(self, BARN_ORIGIN + ZONE_LOCAL, 2.0, "Poser la caisse ici")
	barn_zone.available_check = func() -> bool:
		return Quests.is_step("carry_crate") and player != null and player.carrying == crate
	barn_zone.interacted.connect(_on_barn_zone)
	zone_marker = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.2
	cm.bottom_radius = 1.2
	cm.height = 0.02
	cm.material = mat(Color(1.0, 0.85, 0.3, 0.45), true, 1.5)
	zone_marker.mesh = cm
	zone_marker.position = BARN_ORIGIN + Vector3(ZONE_LOCAL.x, 0.06, ZONE_LOCAL.z)
	zone_marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(zone_marker)


func _build_village() -> void:
	var defs := [
		[Vector3(-14, 0, -10), 0.0, 7.0, 6.0, 3.0, Color(0.93, 0.88, 0.75), Color(0.55, 0.25, 0.2)],
		[Vector3(-28, 0, -11), 0.0, 8.0, 6.0, 3.2, Color(0.85, 0.9, 0.95), Color(0.25, 0.35, 0.5)],
		[Vector3(-13, 0, 11), 180.0, 7.0, 6.0, 3.0, Color(0.95, 0.82, 0.7), Color(0.45, 0.3, 0.25)],
		[Vector3(-27, 0, 12), 180.0, 9.0, 6.0, 3.2, Color(0.9, 0.75, 0.6), Color(0.3, 0.45, 0.3)],
		[Vector3(12, 0, 11), 180.0, 7.0, 6.0, 3.0, Color(0.9, 0.9, 0.8), Color(0.6, 0.3, 0.2)],
		[Vector3(26, 0, 12), 180.0, 8.0, 6.0, 3.2, Color(0.88, 0.82, 0.9), Color(0.35, 0.3, 0.45)],
	]
	var dirt := Color(0.58, 0.47, 0.34)
	for d in defs:
		var pos: Vector3 = d[0]
		var rot: float = d[1]
		var depth: float = d[3]
		_house(pos, rot, d[2], depth, d[4], d[5], d[6])
		var door_z: float = pos.z + (depth * 0.5) * (1.0 if rot == 0.0 else -1.0)
		var road_z: float = -2.5 if pos.z < 0.0 else 2.5
		add_box(self, Vector3(pos.x, 0.027, (door_z + road_z) * 0.5),
			Vector3(2.4, 0.05, absf(door_z - road_z) + 0.2), dirt, false)


func _build_props() -> void:
	# Puits sur la place
	add_cyl(self, Vector3(3.4, 0.45, 3.4), 0.95, 0.9, Color(0.6, 0.6, 0.62))
	add_cyl(self, Vector3(3.4, 0.9, 3.4), 0.7, 0.04, Color(0.2, 0.4, 0.6), false)
	add_box(self, Vector3(2.5, 1.4, 3.4), Vector3(0.12, 1.0, 0.12), Color(0.45, 0.32, 0.2), false)
	add_box(self, Vector3(4.3, 1.4, 3.4), Vector3(0.12, 1.0, 0.12), Color(0.45, 0.32, 0.2), false)
	add_box(self, Vector3(3.4, 1.95, 3.4), Vector3(2.2, 0.12, 1.4), Color(0.5, 0.28, 0.2), false)
	# Lampadaires
	for p in [Vector2(-5.5, -5.5), Vector2(5.5, -5.5), Vector2(-5.5, 5.5), Vector2(5.5, 5.5),
			Vector2(-22, 4.2), Vector2(22, -4.2)]:
		add_cyl(self, Vector3(p.x, 1.6, p.y), 0.07, 3.2, Color(0.2, 0.2, 0.22))
		var bulb := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.2
		sm.height = 0.4
		sm.material = mat(Color(1.0, 0.9, 0.6), false, 1.2)
		bulb.mesh = sm
		bulb.position = Vector3(p.x, 3.3, p.y)
		add_child(bulb)
	# Bancs
	add_box(self, Vector3(-7.0, 0.45, 6.0), Vector3(1.8, 0.1, 0.5), Color(0.5, 0.36, 0.22))
	add_box(self, Vector3(-7.6, 0.2, 6.0), Vector3(0.1, 0.4, 0.45), Color(0.3, 0.3, 0.32), false)
	add_box(self, Vector3(-6.4, 0.2, 6.0), Vector3(0.1, 0.4, 0.45), Color(0.3, 0.3, 0.32), false)
	# Panneau d'entrée du village
	add_box(self, Vector3(10, 0.8, 4.0), Vector3(0.14, 1.6, 0.14), Color(0.4, 0.28, 0.18))
	add_box(self, Vector3(10, 1.5, 4.0), Vector3(0.12, 0.8, 2.8), Color(0.55, 0.4, 0.25), false)
	var sign_label := Label3D.new()
	sign_label.text = "VALBRUME"
	sign_label.font_size = 72
	sign_label.pixel_size = 0.009
	sign_label.outline_size = 12
	sign_label.modulate = Color(1.0, 0.95, 0.8)
	sign_label.rotation_degrees.y = -90.0
	sign_label.position = Vector3(9.9, 1.5, 4.0)
	add_child(sign_label)
	# Rochers
	for p in [Vector3(-40, 0, 20), Vector3(45, 0, 30), Vector3(-45, 0, -30), Vector3(30, 0, -40), Vector3(-15, 0, 35)]:
		var r := add_box(self, Vector3(p.x, 0.5, p.z), Vector3(2.0, 1.0, 1.6), Color(0.5, 0.5, 0.52), true, p.x * 0.1)
		r.rotation.z = 0.0
		_keep(p.x, p.z, 2.0, 2.0)


# =================================================================== Nature

func _build_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20260
	var pts: Array[Vector3] = []
	var tries := 0
	while pts.size() < 95 and tries < 4000:
		tries += 1
		var x := rng.randf_range(-68.0, 68.0)
		var z := rng.randf_range(-68.0, 68.0)
		if tries % 2 == 0:
			if rng.randf() < 0.5:
				x = signf(rng.randf() - 0.5) * rng.randf_range(52.0, 68.0)
			else:
				z = signf(rng.randf() - 0.5) * rng.randf_range(52.0, 68.0)
		if not _is_free(x, z, 1.5):
			continue
		var ok := true
		for p in pts:
			if Vector2(p.x, p.z).distance_to(Vector2(x, z)) < 3.2:
				ok = false
				break
		if ok:
			pts.append(Vector3(x, rng.randf_range(0.8, 1.5), z))
	var n := pts.size()

	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 0.16
	trunk_mesh.bottom_radius = 0.24
	trunk_mesh.height = 1.6
	trunk_mesh.radial_segments = 6
	trunk_mesh.rings = 1
	trunk_mesh.material = mat(Color(0.4, 0.28, 0.18))
	var cone_mesh := CylinderMesh.new()
	cone_mesh.top_radius = 0.0
	cone_mesh.bottom_radius = 1.5
	cone_mesh.height = 2.8
	cone_mesh.radial_segments = 8
	cone_mesh.rings = 1
	var fm := StandardMaterial3D.new()
	fm.vertex_color_use_as_albedo = true
	fm.roughness = 1.0
	cone_mesh.material = fm

	var mm_trunk := _multimesh(trunk_mesh, n, false)
	var mm_c1 := _multimesh(cone_mesh, n, true)
	var mm_c2 := _multimesh(cone_mesh, n, true)
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	for i in n:
		var p := pts[i]
		var s := p.y
		var ts := Transform3D(Basis().scaled(Vector3(s, s, s)), Vector3(p.x, 0.8 * s, p.z))
		mm_trunk.set_instance_transform(i, ts)
		mm_c1.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(s, s, s)), Vector3(p.x, 2.4 * s, p.z)))
		var s2 := s * 0.72
		mm_c2.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(s2, s2, s2)), Vector3(p.x, 3.31 * s, p.z)))
		var tint := rng.randf()
		var col := Color(0.14 + tint * 0.1, 0.36 + tint * 0.16, 0.18 + tint * 0.06)
		mm_c1.set_instance_color(i, col)
		mm_c2.set_instance_color(i, col.lightened(0.08))
		var cs := CollisionShape3D.new()
		var cyl := CylinderShape3D.new()
		cyl.radius = 0.35
		cyl.height = 3.0
		cs.shape = cyl
		cs.position = Vector3(p.x, 1.5, p.z)
		body.add_child(cs)
	for mm in [mm_trunk, mm_c1, mm_c2]:
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		add_child(mmi)
	add_child(body)


func _multimesh(mesh: Mesh, count: int, colors: bool) -> MultiMesh:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = colors
	mm.mesh = mesh
	mm.instance_count = count
	return mm


func _build_backdrop() -> void:
	for i in 14:
		var a := TAU * float(i) / 14.0 + 0.2
		var r := 105.0 + float(i % 3) * 12.0
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 1.0
		sm.height = 2.0
		sm.radial_segments = 12
		sm.rings = 6
		sm.material = mat(Color(0.33 + 0.03 * float(i % 3), 0.5, 0.36))
		mi.mesh = sm
		mi.scale = Vector3(36.0 + float(i % 4) * 6.0, 12.0 + float(i % 5) * 3.0, 36.0)
		mi.position = Vector3(cos(a) * r, -2.0, sin(a) * r)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
	for i in 9:
		var a := TAU * float(i) / 9.0 + 0.5
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.0
		cm.bottom_radius = 30.0
		cm.height = 55.0 + float(i % 3) * 14.0
		cm.radial_segments = 7
		cm.rings = 1
		cm.material = mat(Color(0.5, 0.58, 0.7))
		mi.mesh = cm
		mi.position = Vector3(cos(a) * 150.0, cm.height * 0.5 - 4.0, sin(a) * 150.0)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)


# =================================================================== PNJ et objets de quête

func _make_npc(npc_name: String, pos: Vector3, face_target: Vector3, opts: Dictionary,
		prompt: String) -> Dictionary:
	var root := Node3D.new()
	root.name = npc_name
	root.position = pos
	add_child(root)
	var parts := CharacterBuilder.build(opts)
	var model: Node3D = parts["root"]
	root.add_child(model)
	var d := face_target - pos
	model.rotation.y = atan2(-d.x, -d.z)
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.5
	var body := StaticBody3D.new()
	body.collision_layer = 16
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	cs.shape = cap
	cs.position = Vector3(0, 0.75, 0)
	body.add_child(cs)
	root.add_child(body)
	var it := Interactable.create(root, Vector3(0, 1.0, 0), 1.6, prompt)
	var base_scale := model.scale
	var tw := model.create_tween().set_loops()
	tw.tween_property(model, "scale", base_scale * Vector3(1.0, 1.015, 1.0), 1.7)
	tw.tween_property(model, "scale", base_scale, 1.7)
	return {"root": root, "model": model, "interactable": it}


func _build_npcs() -> void:
	var spawn_face := PLAYER_START
	var m := _make_npc("Maya", MAYA_POS, spawn_face, {
		"shirt": Color(0.85, 0.5, 0.25), "pants": Color(0.35, 0.28, 0.25),
		"hair": Color(0.35, 0.2, 0.12), "accent": Color(0.95, 0.9, 0.8), "scale": 1.38,
	}, "Parler à Maya")
	maya = m["root"]
	(m["interactable"] as Interactable).interacted.connect(_on_maya)

	var t := _make_npc("Tobias", Vector3(-4.0, 0, 3.2), Vector3(0, 0, 0), {
		"shirt": Color(0.3, 0.45, 0.3), "pants": Color(0.3, 0.27, 0.22),
		"hair": Color(0.82, 0.82, 0.85), "accent": Color(0.6, 0.2, 0.2), "scale": 1.32,
	}, "Parler à Tobias")
	tobias = t["root"]
	(t["interactable"] as Interactable).interacted.connect(_on_tobias)

	# Noé : allongé sous la poutre au départ (sans collision, il est libre ensuite).
	noe = Node3D.new()
	noe.name = "Noe"
	noe.position = BARN_ORIGIN + NOE_LYING_LOCAL
	noe.rotation.x = PI * 0.5
	add_child(noe)
	var np := CharacterBuilder.build({
		"shirt": Color(0.9, 0.75, 0.25), "pants": Color(0.3, 0.4, 0.55),
		"hair": Color(0.85, 0.7, 0.35), "accent": Color(0.3, 0.6, 0.35), "scale": 0.95,
	})
	noe.add_child(np["root"] as Node3D)
	noe_talk = Interactable.create(noe, Vector3(0, 0.6, 0), 1.6, "Parler à Noé")
	noe_talk.available_check = func() -> bool: return Quests.chapter_done
	noe_talk.interacted.connect(_on_noe)


func _build_quest_objects() -> void:
	crate = Crate.new()
	crate.name = "Caisse"
	crate.position = CRATE_START
	add_child(crate)
	crate.interactable.available_check = func() -> bool:
		return Quests.step_reached("carry_crate") and not crate.carried and not crate.delivered
	crate.interactable.interacted.connect(_on_crate)

	# Poutre posée sur deux blocs, en travers des jambes de Noé.
	for x in [1.1, 4.9]:
		add_box(self, BARN_ORIGIN + Vector3(x, 0.225, BEAM_LOCAL.z), Vector3(0.7, 0.45, 0.9), Color(0.45, 0.32, 0.2))
	beam = Node3D.new()
	beam.name = "Poutre"
	beam.position = BARN_ORIGIN + BEAM_LOCAL
	add_child(beam)
	var bm := BoxMesh.new()
	bm.size = Vector3(4.2, 0.5, 0.5)
	bm.material = mat(Color(0.42, 0.28, 0.17))
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	beam.add_child(mi)
	for x in [-2.0, 2.0]:
		add_box(beam, Vector3(x, 0, 0), Vector3(0.1, 0.56, 0.56), Color(0.25, 0.18, 0.12), false)
	beam_body = _static_body(Vector3.ZERO, 0.0, _box_shape(Vector3(4.2, 0.5, 0.5)))
	beam.add_child(beam_body)
	var bi := Interactable.create(beam, Vector3.ZERO, 2.6, "Soulever la poutre")
	bi.available_check = func() -> bool:
		return Quests.is_step("rescue_noe") and not _rescue_running
	bi.interacted.connect(_on_beam)

	# Faisceau lumineux d'objectif
	beacon = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.3
	cm.bottom_radius = 0.3
	cm.height = 8.0
	cm.radial_segments = 12
	cm.rings = 1
	var bmat := StandardMaterial3D.new()
	bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bmat.cull_mode = BaseMaterial3D.CULL_DISABLED
	bmat.albedo_color = Color(1.0, 0.85, 0.3, 0.22)
	cm.material = bmat
	beacon.mesh = cm
	beacon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(beacon)


func _spawn_player() -> void:
	player = Player.new()
	player.name = "Ael"
	var start := PLAYER_START
	if Game.has_saved_position:
		var sp := Game.player_position
		if sp.is_finite() and absf(sp.x) <= 70.0 and absf(sp.z) <= 70.0 and sp.y > -1.0 and sp.y < 20.0:
			start = sp + Vector3(0, 0.2, 0)
	player.position = start
	add_child(player)
	player.rig.yaw = -PI * 0.5
	player.model.rotation.y = -PI * 0.5
	Powers.deactivate_all()


func _build_ui() -> void:
	var tl := CanvasLayer.new()
	tl.layer = 5
	add_child(tl)
	touch_controls = TouchControls.new()
	tl.add_child(touch_controls)
	hud = GameHud.new()
	add_child(hud)
	pause_menu = PauseMenu.new()
	add_child(pause_menu)
	chapter_end = ChapterEnd.new()
	add_child(chapter_end)


# =================================================================== État / sauvegarde

func _snapshot() -> Dictionary:
	var state := "start"
	if crate.delivered:
		state = "delivered"
	elif player != null and player.carrying == crate:
		state = "carried"
	elif crate.global_position.distance_to(CRATE_START) > 0.1:
		state = "dropped"
	var cp := crate.global_position
	return {"crate": {"state": state, "pos": [cp.x, cp.y, cp.z]}}


func _read_pos(v: Variant) -> Variant:
	if typeof(v) != TYPE_ARRAY or (v as Array).size() != 3:
		return null
	var a: Array = v
	for e in a:
		if typeof(e) != TYPE_INT and typeof(e) != TYPE_FLOAT:
			return null
	var p := Vector3(float(a[0]), float(a[1]), float(a[2]))
	if not p.is_finite() or absf(p.x) > 70.0 or absf(p.z) > 70.0 or p.y < -1.0 or p.y > 10.0:
		return null
	return p


func _apply_saved_state() -> void:
	var saved: Dictionary = {}
	var cv: Variant = Game.loaded_world.get("crate", {})
	if typeof(cv) == TYPE_DICTIONARY:
		saved = cv
	var state := "start"
	var sv: Variant = saved.get("state", "start")
	if typeof(sv) == TYPE_STRING:
		state = sv
	# Cohérence avec la quête : la quête fait foi.
	if Quests.chapter_done or Quests.step_index >= 2:
		state = "delivered"
	elif Quests.step_index < 1 or state == "delivered":
		state = "start"
	match state:
		"delivered":
			crate.global_position = BARN_ORIGIN + CRATE_DELIVERED_LOCAL
			crate.mark_delivered()
		"carried":
			player.pick_up(crate)
		"dropped":
			var pos: Variant = _read_pos(saved.get("pos", null))
			if pos != null:
				crate.global_position = Vector3(pos.x, 0.35, pos.z)
	if Quests.chapter_done:
		Powers.unlock("super_strength")
		beam.position = BARN_ORIGIN + BEAM_ASIDE_LOCAL
		beam.rotation = Vector3(0, 0.3, 0)
		noe.position = BARN_ORIGIN + NOE_FREE_LOCAL
		noe.rotation = Vector3(0, PI * 0.5, 0)
	player.set_aura(false)
	Game.loaded_world = {}


func _update_markers() -> void:
	zone_marker.visible = Quests.is_step("carry_crate")


func _update_beacon() -> void:
	if player == null or beacon == null:
		return
	var target := Vector3.ZERO
	var beacon_on := true
	if Quests.chapter_done or _rescue_running:
		beacon_on = false
	elif Quests.is_step("talk_maya"):
		target = MAYA_POS
	elif Quests.is_step("carry_crate"):
		if player.carrying == crate:
			target = BARN_ORIGIN + ZONE_LOCAL
		else:
			target = crate.global_position
	else:
		target = beam.global_position
	beacon.visible = beacon_on
	if beacon_on:
		beacon.global_position = Vector3(target.x, 4.0, target.z)


func _on_step_changed(_i: int) -> void:
	_update_markers()


func _on_quest_completed() -> void:
	_update_markers()
	Game.save_game()
	await get_tree().create_timer(1.4).timeout
	chapter_end.show_end()


# =================================================================== Dialogues et mission

func _start_intro() -> void:
	if Quests.chapter_done:
		Game.toast("Chapitre 1 terminé — exploration libre.")
		return
	if Quests.step_index == 0 and not Game.flags.get("intro_done", false):
		Game.flags["intro_done"] = true
		await get_tree().create_timer(0.8).timeout
		await Dialogue.play([
			{"speaker": "", "text": "Valbrume. Un village tranquille, niché au creux des collines."},
			{"speaker": "", "text": "Aël a onze ans. Ce matin, comme tous les matins, il donne un coup de main à la ferme."},
		])


func _face_player(npc: Node3D) -> void:
	var model := npc.get_node("Model") as Node3D
	var d := player.global_position - npc.global_position
	model.rotation.y = atan2(-d.x, -d.z)


func _on_maya(_p: Node3D) -> void:
	_face_player(maya)
	if Quests.is_step("talk_maya"):
		await Dialogue.play([
			{"speaker": "Maya", "text": "Bonjour mon grand ! Déjà debout ? Le soleil se lève à peine sur Valbrume."},
			{"speaker": "Aël", "text": "Bonjour maman. Je n'arrivais plus à dormir... J'ai fait un drôle de rêve."},
			{"speaker": "Maya", "text": "Un rêve ? Tu me raconteras ça ce soir. Pour l'instant, j'ai besoin d'un coup de main."},
			{"speaker": "Maya", "text": "Cette caisse de provisions doit aller dans la grange. Noé devait la ranger, mais je ne l'ai pas vu de la matinée."},
			{"speaker": "Aël", "text": "D'accord, je m'en occupe !"},
			{"speaker": "Maya", "text": "Merci, mon cœur. La caisse est près de la porte, et la grange est un peu plus à l'est. Fais attention à toi."},
		])
		Quests.complete_step("talk_maya")
		Game.save_game()
	elif Quests.is_step("carry_crate"):
		await Dialogue.play([
			{"speaker": "Maya", "text": "La caisse est près de la porte. La grange, c'est le grand bâtiment rouge, à l'est."},
		])
	elif Quests.is_step("rescue_noe"):
		await Dialogue.play([
			{"speaker": "Maya", "text": "Tu as entendu ? On dirait que quelqu'un appelle depuis la grange !"},
		])
	else:
		await Dialogue.play([
			{"speaker": "Maya", "text": "Aël... ce qui s'est passé dans la grange... nous en reparlerons ensemble."},
			{"speaker": "Maya", "text": "Je suis fière de toi, quoi qu'il arrive."},
		])


func _on_tobias(_p: Node3D) -> void:
	_face_player(tobias)
	if Quests.chapter_done:
		await Dialogue.play([
			{"speaker": "Tobias", "text": "J'ai entendu un grand fracas du côté de la ferme... Tout va bien, petit ?"},
			{"speaker": "Aël", "text": "Oui, oui ! Tout va bien."},
		])
	else:
		await Dialogue.play([
			{"speaker": "Tobias", "text": "Ah, bonjour petit Aël ! L'automne s'annonce doux cette année."},
			{"speaker": "Tobias", "text": "Dis à ta mère que la vieille grange ne tient plus que par miracle. Il faudra vérifier la charpente."},
		])


func _on_noe(_p: Node3D) -> void:
	await Dialogue.play([
		{"speaker": "Noé", "text": "Ça va mieux, merci Aël. Je n'oublierai jamais ce que tu as fait."},
	])


func _on_crate(p: Node3D) -> void:
	(p as Player).pick_up(crate)


func _on_barn_zone(_p: Node3D) -> void:
	if player.carrying != crate:
		return
	Game.cutscene_running = true
	player.drop_carried()
	crate.global_position = BARN_ORIGIN + CRATE_DELIVERED_LOCAL
	crate.rotation = Vector3.ZERO
	crate.mark_delivered()
	_update_markers()
	await Dialogue.play([
		{"speaker": "Aël", "text": "Voilà, la caisse est rangée. Maman sera contente."},
		{"speaker": "Voix lointaine", "text": "...Au secours... Quelqu'un... Aidez-moi !"},
		{"speaker": "Aël", "text": "Cette voix... C'est Noé ! Il est quelque part dans la grange !"},
	])
	Game.cutscene_running = false
	Quests.complete_step("carry_crate")
	Game.save_game()


func _on_beam(_p: Node3D) -> void:
	if _rescue_running:
		return
	_rescue_running = true
	await _run_rescue()


func _run_rescue() -> void:
	Game.cutscene_running = true
	Game.set_prompt("")
	await Dialogue.play([
		{"speaker": "Noé", "text": "Aël ! Je suis coincé... la poutre est tombée sur mes jambes !"},
		{"speaker": "Aël", "text": "Tiens bon, Noé ! Je vais la soulever !"},
	])
	Game.input_locked = true

	# Aël rejoint l'extrémité de la poutre, la caméra se tourne vers elle.
	var stand := BARN_ORIGIN + RESCUE_STAND_LOCAL
	var yaw_from := player.rig.yaw
	var yaw_to := yaw_from + angle_difference(yaw_from, -PI * 0.5)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(player, "global_position", stand, 0.7)
	tw.tween_method(func(v: float) -> void: player.rig.yaw = v, yaw_from, yaw_to, 0.7)
	await tw.finished
	player.velocity = Vector3.ZERO
	player.face_toward(beam.global_position)

	await Dialogue.play([
		{"speaker": "Aël", "text": "Hhhh... Elle est beaucoup trop lourde !"},
		{"speaker": "Noé", "text": "Aël... ça fait mal... Ne me laisse pas !"},
		{"speaker": "Aël", "text": "Je ne te laisserai pas ! Je... je vais y arriver !"},
	])

	# Éveil du pouvoir
	player.lift_pose = true
	player.set_aura(true)
	player.rig.shake(0.05, 1.0)
	await get_tree().create_timer(0.9).timeout
	Game.flash_requested.emit(0.7)
	player.rig.shake(0.12, 1.8)
	beam_body.collision_layer = 0
	var rest_y := beam.position.y
	var lift := create_tween().set_parallel(true)
	lift.tween_property(beam, "position:y", rest_y + 1.7, 1.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	lift.tween_property(beam, "rotation:z", 0.12, 1.4)
	await lift.finished

	Powers.unlock("super_strength")
	Game.banner_requested.emit("POUVOIR DÉBLOQUÉ", "Super-force")

	# Noé se dégage et se relève.
	var crawl := create_tween()
	crawl.tween_property(noe, "position", BARN_ORIGIN + Vector3(NOE_LYING_LOCAL.x, NOE_LYING_LOCAL.y, NOE_FREE_LOCAL.z), 1.2)
	await crawl.finished
	var rise := create_tween().set_parallel(true)
	rise.tween_property(noe, "rotation:x", 0.0, 0.9)
	rise.tween_property(noe, "rotation:y", PI * 0.5, 0.9)
	rise.tween_property(noe, "position:y", 0.0, 0.9)
	await rise.finished

	# La poutre est reposée sur le côté.
	var drop := create_tween().set_parallel(true)
	drop.tween_property(beam, "position", BARN_ORIGIN + BEAM_ASIDE_LOCAL, 0.9).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	drop.tween_property(beam, "rotation", Vector3(0, 0.3, 0), 0.9)
	await drop.finished
	player.rig.shake(0.1, 0.5)
	beam_body.collision_layer = 1
	player.lift_pose = false
	await get_tree().create_timer(1.6).timeout
	player.set_aura(false)

	await Dialogue.play([
		{"speaker": "Noé", "text": "Aël ! Tu... tu as soulevé cette poutre tout seul ?!"},
		{"speaker": "Aël", "text": "Je ne sais pas ce qui s'est passé. J'ai voulu te sauver, et mon pendentif s'est mis à briller."},
		{"speaker": "Noé", "text": "C'est incroyable ! Il y a quelque chose de spécial en toi. Promets-moi d'en parler à ta mère."},
		{"speaker": "Aël", "text": "Promis. Viens, rentrons à la ferme."},
	])
	Game.toast("Appuie sur POUVOIR (ou R) pour activer la Super-force.")
	Game.input_locked = false
	Game.cutscene_running = false
	Quests.complete_step("rescue_noe")
