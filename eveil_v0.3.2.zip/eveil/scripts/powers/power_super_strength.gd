class_name PowerSuperStrength
extends Power
## Super-force : sauts plus hauts, course plus rapide, charges portées sans effort.


func _init() -> void:
	id = "super_strength"
	display_name = "Super-force"
	description = "Une force hors du commun : saute plus haut, cours plus vite."
	cooldown = 10.0
	duration = 8.0


func _on_activate(p: Node) -> void:
	p.set("speed_multiplier", 1.45)
	p.set("jump_multiplier", 1.55)
	p.call("set_aura", true)


func _on_deactivate(p: Node) -> void:
	p.set("speed_multiplier", 1.0)
	p.set("jump_multiplier", 1.0)
	p.call("set_aura", false)
