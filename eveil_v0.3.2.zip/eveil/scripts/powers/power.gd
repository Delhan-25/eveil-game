class_name Power
extends RefCounted
## Classe de base d'un pouvoir. Surcharger _on_activate / _on_deactivate.

var id: String = ""
var display_name: String = ""
var description: String = ""
var cooldown: float = 5.0
var duration: float = 0.0       # 0 = effet instantané
var cooldown_left: float = 0.0
var time_left: float = 0.0
var active: bool = false
var _player: Node = null


func can_use() -> bool:
	return cooldown_left <= 0.0 and not active


func activate(player: Node) -> void:
	_player = player
	time_left = duration
	active = duration > 0.0
	if not active:
		cooldown_left = cooldown
	_on_activate(player)


func tick(delta: float) -> void:
	if active:
		time_left -= delta
		if time_left <= 0.0:
			active = false
			cooldown_left = cooldown
			if is_instance_valid(_player):
				_on_deactivate(_player)
	elif cooldown_left > 0.0:
		cooldown_left = maxf(0.0, cooldown_left - delta)


func force_stop() -> void:
	if active and is_instance_valid(_player):
		_on_deactivate(_player)
	active = false


func reset_state() -> void:
	active = false
	time_left = 0.0
	cooldown_left = 0.0


func _on_activate(_p: Node) -> void:
	pass


func _on_deactivate(_p: Node) -> void:
	pass
