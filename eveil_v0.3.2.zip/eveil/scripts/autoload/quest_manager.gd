extends Node
## Autoload « Quests » : gestionnaire de missions piloté par les données.
## Pour ajouter une mission, ajouter des entrées à STEPS (ou plusieurs chapitres plus tard).

signal step_changed(step_index: int)
signal quest_completed

const CHAPTER_TITLE := "Chapitre 1 — Le matin de Valbrume"

const STEPS := [
	{"id": "talk_maya", "title": "Parler à Maya",
		"hint": "Maya t'attend devant la ferme."},
	{"id": "carry_crate", "title": "Apporter la caisse à la grange",
		"hint": "Ramasse la caisse près de la ferme, puis pose-la dans la grange."},
	{"id": "rescue_noe", "title": "Secourir Noé",
		"hint": "Quelqu'un appelle à l'aide dans la grange !"},
]

var step_index: int = 0
var chapter_done: bool = false


func reset() -> void:
	step_index = 0
	chapter_done = false


func load_step(index: int) -> void:
	step_index = clampi(index, 0, STEPS.size())
	chapter_done = step_index >= STEPS.size()


func current_step() -> Dictionary:
	if chapter_done:
		return {}
	return STEPS[step_index]


func index_of(id: String) -> int:
	for i in STEPS.size():
		if String(STEPS[i]["id"]) == id:
			return i
	return -1


## Vrai si `id` est l'étape en cours.
func is_step(id: String) -> bool:
	return not chapter_done and String(STEPS[step_index]["id"]) == id


## Vrai si l'étape `id` a commencé (en cours ou déjà terminée).
func step_reached(id: String) -> bool:
	var i := index_of(id)
	return i != -1 and step_index >= i


func complete_step(id: String) -> void:
	if not is_step(id):
		return
	step_index += 1
	if step_index >= STEPS.size():
		chapter_done = true
		quest_completed.emit()
	else:
		step_changed.emit(step_index)
