extends Node
## Autoload « Dialogue » : file de répliques. L'affichage est assuré par GameHud.
## Format d'une réplique : {"speaker": "Maya", "text": "..."}  (speaker vide = narration)
## Usage : await Dialogue.play([...])

signal dialogue_started
signal line_shown(speaker: String, text: String)
signal finished

const CHARS_PER_SECOND := 55.0

var active: bool = false
var reveal: float = 0.0           # nombre de caractères révélés (machine à écrire)
var current_length: int = 0
var last_end_ms: int = -10000     # sert à ignorer l'appui qui vient de fermer le dialogue

var _lines: Array = []
var _index: int = 0
var _start_ms: int = 0
var _on_done: Callable = Callable()


func start(lines: Array, on_done: Callable = Callable()) -> void:
	if lines.is_empty() or active:
		return
	_lines = lines
	_index = 0
	_on_done = on_done
	active = true
	_start_ms = Time.get_ticks_msec()
	dialogue_started.emit()
	_show_current()


func play(lines: Array) -> void:
	if lines.is_empty() or active:
		return
	start(lines)
	await finished


func advance() -> void:
	if not active:
		return
	if reveal < float(current_length):
		reveal = float(current_length)
		return
	_index += 1
	if _index >= _lines.size():
		_finish()
	else:
		_show_current()


func _show_current() -> void:
	var line: Dictionary = _lines[_index]
	var text := String(line.get("text", ""))
	reveal = 0.0
	current_length = text.length()
	line_shown.emit(String(line.get("speaker", "")), text)


func _finish() -> void:
	active = false
	last_end_ms = Time.get_ticks_msec()
	var cb := _on_done
	_on_done = Callable()
	finished.emit()
	if cb.is_valid():
		cb.call()


func _process(delta: float) -> void:
	if not active:
		return
	reveal += CHARS_PER_SECOND * delta
	if Input.is_action_just_pressed("interact") and Time.get_ticks_msec() - _start_ms > 250:
		advance()
