extends Node
## Autoload « Powers » : registre de pouvoirs extensible.
## Ajouter un pouvoir = créer un script qui étend Power puis l'enregistrer dans _ready().

signal power_unlocked(id: String)
signal power_used(id: String)

var _registry: Dictionary = {}
var unlocked: Array[String] = []
var selected: String = ""


func _ready() -> void:
	register(PowerSuperStrength.new())
	# Futurs pouvoirs (vol, vision, vitesse...) : register(PowerXxx.new())


func register(p: Power) -> void:
	_registry[p.id] = p


func get_power(id: String) -> Power:
	return _registry.get(id, null)


func selected_power() -> Power:
	return get_power(selected)


func is_unlocked(id: String) -> bool:
	return unlocked.has(id)


func is_active(id: String) -> bool:
	var p := get_power(id)
	return p != null and p.active


func unlock(id: String) -> void:
	if not _registry.has(id) or unlocked.has(id):
		return
	unlocked.append(id)
	if selected == "":
		selected = id
	power_unlocked.emit(id)


func try_use(player: Node) -> bool:
	var p := selected_power()
	if p == null:
		Game.toast("Tu n'as pas encore découvert de pouvoir...")
		return false
	if not p.can_use():
		if p.active:
			return false
		Game.toast("%s : recharge (%d s)" % [p.display_name, ceili(p.cooldown_left)])
		return false
	p.activate(player)
	power_used.emit(p.id)
	return true


func deactivate_all() -> void:
	for p in _registry.values():
		(p as Power).force_stop()


func reset() -> void:
	deactivate_all()
	unlocked.clear()
	selected = ""
	for p in _registry.values():
		(p as Power).reset_state()


func get_save_data() -> Dictionary:
	return {"unlocked": unlocked.duplicate(), "selected": selected}


func load_save_data(data: Variant) -> void:
	unlocked.clear()
	selected = ""
	if typeof(data) != TYPE_DICTIONARY:
		return
	var d: Dictionary = data
	var arr: Variant = d.get("unlocked", [])
	if typeof(arr) == TYPE_ARRAY:
		for id in arr:
			if typeof(id) == TYPE_STRING and _registry.has(id) and not unlocked.has(id):
				unlocked.append(id)
	var sel: Variant = d.get("selected", "")
	if typeof(sel) == TYPE_STRING and unlocked.has(sel):
		selected = sel
	elif not unlocked.is_empty():
		selected = unlocked[0]


func _process(delta: float) -> void:
	for p in _registry.values():
		(p as Power).tick(delta)
