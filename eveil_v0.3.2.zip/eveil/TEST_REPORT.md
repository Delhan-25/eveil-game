# TEST_REPORT — ÉVEIL v0.3.2

Statuts : **RÉUSSI** · **ÉCHOUÉ** · **NON EXÉCUTÉ**.

## Preuves réelles reçues (exécution Godot 4.3.stable sur GitHub Actions, v0.3.1)
Voir `docs/ANALYSE_JOURNAUX_V0.3.1.md` et `docs/ci_logs_v0.3.1/`. Rappel : import RÉUSSI, démarrage RÉUSSI, test de fumée ÉCHOUÉ (1), intégration ÉCHOUÉE (40/153), export Web non lancé.
Les corrections de cette v0.3.2 visent ces échecs précis (cause racine : harnais de test + un vrai défaut d'encodage dans la configuration d'export).

## Ce que j'ai réellement pu exécuter pour la v0.3.2 (environnement SANS Godot, SANS réseau)
| Vérification | Résultat | Portée |
|---|---|---|
| `python3 tools/check_project.py` | **RÉUSSI** (code 0) | structure uniquement ; le v0.3.1 avait déjà passé cette analyse et échoué dans Godot |
| Scan UTF-8 de tous les fichiers du projet | **RÉUSSI** | aucun octet invalide |
| `export_presets.cfg` : `head_include` identique à `web/head_include.html`, ASCII pur, sans `\u` | **RÉUSSI** | |
| Écran de rotation (Chromium émulé iPhone, `head_include` lu depuis le `.cfg`) | **RÉUSSI** | accents corrects (« Tourne ton téléphone »), visible en portrait uniquement, DPR plafonné à 1,5 ; ≠ Safari |
| `tools/run_tests.sh` avec 6 faux exécutables (23, SCRIPT ERROR, Unicode, intégration seule, ok, absent) | **RÉUSSI** (codes 1,1,1,1,0,127) | lanceur seulement (`docs/launcher_selftest.txt`) |
| YAML du workflow | **RÉUSSI** (v0.3.1, inchangé) | |

## Ce que je n'ai PAS pu exécuter
| Élément | Statut |
|---|---|
| Import / démarrage / test de fumée / test d'intégration dans Godot | **NON EXÉCUTÉ** (Godot absent) |
| Parcours à pied, cinématique, multitouch, pause tactile | **NON EXÉCUTÉ** (jamais exercés réellement : ils étaient bloqués par le dialogue) |
| Export Web et ZIP `index.html/js/wasm/pck` | **NON EXÉCUTÉ** |
| Safari / iPhone | **NON EXÉCUTÉ** |
**Je ne peux donc pas affirmer que la v0.3.2 est verte.** Elle corrige les causes identifiées ; le prochain run GitHub Actions est le juge.

## Risques résiduels (hypothèses)
1. Défauts réels encore masqués derrière le blocage du dialogue (route à pied, cinématique, restaurations, multitouch).
2. `Input.flush_buffered_events()` en headless : comportement supposé d'après la documentation ; à confirmer par le journal.
3. Taille de `TouchControls`/HUD en headless : diagnostics ajoutés (échec explicite si nulle).
4. Performances iPhone, persistance IndexedDB, plein écran iPhone : inchangés, non vérifiés.
