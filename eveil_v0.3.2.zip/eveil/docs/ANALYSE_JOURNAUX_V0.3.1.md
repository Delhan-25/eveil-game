# Analyse des journaux réels de la v0.3.1 (Godot 4.3.stable.official.77dcf97d8, GitHub Actions)
Journaux bruts archivés dans `docs/ci_logs_v0.3.1/`. Résultat observé : import OK, démarrage OK, test de fumée 1 échec, intégration 40 échecs / 153, export non lancé.

## Ce que les journaux ont PROUVÉ
Installation Godot, import, chargement de toutes les scènes/scripts (aucune erreur de parsing GDScript), monde instancié, joueur présent, sauvegardes (refus/acceptation/migration/échec d'écriture : 100 % des cas OK), dialogue d'introduction affiché.

## Causes des échecs (40 + 1)
| # | Symptôme dans les journaux | Cause réelle | Nature | Correction (fichier) |
|---|---|---|---|---|
| 1 | `à pied : … bloqué à (6, 0.000243, -0.5)` ; 12 échecs « à pied » | Le dialogue d'introduction n'était jamais refermé : le joueur restait verrouillé (`Dialogue.active`) | **Harnais de test** | `tests/integration_test.gd` |
| 2 | `introduction terminée` ✗, puis cascade : Maya, caisse, dépôt, poutre, cinématique, fin de chapitre, pouvoir, restaurations (≈ 22 échecs) | Même cause que #1 : les appuis étaient émis par `Input.action_press` depuis une coroutine de minuterie. `Dialogue._process` utilise `is_action_just_pressed`, vrai seulement pour la frame de l'appui ; l'appui était horodaté au mauvais moment. Le moteur livre les entrées au début de l'itération, avant tous les `_process`. (Le polling de `Player._physics_process` fonctionnait, d'où « dialogue de Maya lancé ».) | **Harnais de test** (le jeu réel reçoit ses entrées au bon moment) | `press/release/tap` attendent `process_frame` avant d'appuyer |
| 3 | `invite « Parler à Maya » affichée` ✗ | Conséquence : le joueur est verrouillé par le dialogue, donc aucune invite | Cascade de #2 | — |
| 4 | multitouch : joystick, caméra, saut, AGIR, pause tactile ✗ (≈ 8 échecs) | Les événements injectés par `Input.parse_input_event` restent dans le tampon en mode headless tant qu'on n'appelle pas `Input.flush_buffered_events()` ; de plus l'injection n'était pas synchronisée sur `process_frame` | **Harnais de test** | `send_event()` : `process_frame` + `parse_input_event` + `flush_buffered_events` |
| 5 | `ERROR: The InputMap action "jump" doesn't exist` (×4, `action_release`) | `Game.new_game()` appelé par le test avant que l'autoload `Game` ait exécuté `_ready` (la carte d'entrées n'existait pas encore) | Harnais + **garde défensive côté jeu** | test : 2 × `await process_frame` avant de commencer ; `Game.release_all_actions()` vérifie `InputMap.has_action` |
| 6 | Smoke : `sauvegarde relue` ✗ | Le test enregistrait « étape 2 + super-force débloquée + caisse au départ », un état **incohérent** que la politique de sauvegarde v0.3 refuse à juste titre au chargement | **Test erroné** (le jeu avait raison) | `tests/smoke_test.gd` : état cohérent pour le cycle sauvegarde/rechargement ; l'état incohérent est maintenant vérifié comme REFUSÉ |
| 7 | Import : `Unicode parsing error … (e9 … 6c …)` et `(e9 … 70 …)` | **Vrai bug du projet.** Les octets sont ceux de « t**é**l**é**phone » : Godot décode les échappements `\u00e9` du champ `html/head_include` de `export_presets.cfg` en octet brut invalide. Aucun fichier du projet n'est invalide en UTF-8 (vérifié). Effet : l'écran de rotation web aurait affiché « t�l�phone » | **Bug réel (v0.3.1)** | `web/head_include.html` : entités HTML `&eacute;` (ASCII pur) ; `tools/make_web_preset.py` refuse désormais tout non-ASCII et tout antislash ; `export_presets.cfg` régénéré |
| 8 | Import : `cannot connect to daemon at tcp:5037` | Greffon d'export Android qui cherche `adb` | Bénin, hors périmètre | aucune (ne cause pas d'échec) |
| 9 | `WARNING: ObjectDB instances leaked at exit` | Objets encore vivants à la fermeture du script de test | Bénin | aucune |

## Défauts de processus corrigés
- Un `Unicode parsing error` dans un journal n'était pas considéré comme un échec : `tools/run_tests.sh` et `tools/export_web.sh` le traitent maintenant comme tel (même avec code 0).
- `check()` affiche désormais le contexte (étape, dialogue, invite, position, verrou) à chaque échec, pour des journaux plus directs.
- Diagnostics ajoutés : taille de `TouchControls` et du HUD non nulle.

## Aucune vérification n'a été désactivée ni affaiblie
Les 153 vérifications existantes sont conservées (et 6 ajoutées). Les entrées sont simulées plus fidèlement au moteur, pas contournées.

## Ce que ces journaux NE permettent PAS de conclure
Comme le dialogue bloquait tout, **le parcours à pied, la caisse, la cinématique, la restauration d'après-mission et le multitouch n'ont jamais réellement été exercés**. Des défauts réels peuvent encore apparaître au prochain run, à partir du premier point qui atteindra ces zones.
