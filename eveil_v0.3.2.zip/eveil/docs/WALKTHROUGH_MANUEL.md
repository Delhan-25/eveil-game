# Parcours manuel à pied (sans téléportation) — procédure reproductible

But : prouver que chaque objectif est ATTEIGNABLE en marchant (clôtures, murs de la grange, obstacles).
Cette procédure n'a PAS encore été exécutée (aucun Godot). Remplir la colonne *Observé*.
Le test automatique équivalent est `test_walkthrough()` dans `tests/integration_test.gd` (non exécuté non plus).

Repères (mètres, axes X = est, Z = sud ; départ = (6, 0, -0,5), caméra tournée vers l'est).
| # | Action | Waypoint (X, Z) | Attendu | Observé |
|---|---|---|---|---|
| 1 | Nouvelle partie, lire l'introduction (E / bouton AGIR) | (6, -0,5) | contrôle rendu | |
| 2 | Aller vers l'est puis entrer dans l'enclos par l'**ouverture de la clôture sud** (x 13→19) | (13,5 ; -1) puis (16 ; -4,8) | clôture bloque ailleurs, ouverture franchissable | |
| 3 | Parler à Maya (devant la ferme) | (14,5 ; -5,5) | invite « Parler à Maya », dialogue, objectif → caisse | |
| 4 | Ramasser la caisse | (18,6 ; -5,6) | invite « Ramasser la caisse », caisse portée devant Aël | |
| 5 | Porter la caisse par le chemin vers la grange | (24 ; -5,5) → (24 ; -12) → (31,5 ; -12) | pas de blocage ; entrée par la grande porte ouest (x=28, z −14 à −10) | |
| 6 | Poser la caisse sur la zone dorée | (32 ; -12) | invite « Poser la caisse ici », voix de Noé, objectif → Noé | |
| 7 | Rejoindre la poutre | (34,5 ; -15,2) | invite « Soulever la poutre » | |
| 8 | Interagir : cinématique | — | poutre soulevée, flash, bannière « POUVOIR DÉBLOQUÉ », Noé se relève, écran de fin | |
| 9 | Continuer à explorer, sauvegarder (Pause), quitter, Continuer | — | état restauré | |

À noter si échec : position où Aël est bloqué (afficher les coordonnées via le débogueur), capture d'écran, journal de la Sortie.
