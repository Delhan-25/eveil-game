# Plan — future passe graphique (HORS périmètre du MVP actuel, rien ici n'est réalisé)

Objectif : passer du low-poly en primitives à une direction artistique cohérente et optimisée mobile.
À lancer SEULEMENT après validation de la boucle complète du chapitre 1 sur appareil réel.

1. **Direction artistique** : choisir un style (cel-shading stylisé recommandé pour le mobile, plutôt que le photoréalisme),
   moodboard, palette, silhouette d'Aël (pendentif/écharpe), charte UI.
2. **Modèles** : personnages (Aël, Maya, Noé, villageois) ~5–8 k triangles ; bâtiments modulaires ; props (caisse, poutre, clôtures).
   Format glTF 2.0, échelle 1 u = 1 m, atlas de textures partagés pour limiter les draw calls.
3. **Rigging et animation** : squelette humanoïde (Godot `Skeleton3D`/`AnimationTree`) ; cycles idle, marche, course, saut,
   chute, atterrissage, port de caisse, poussée, soulèvement ; animations d'éveil des pouvoirs.
4. **Textures et matériaux** : albédo + normal compressés ETC2/ASTC, pas de transparence coûteuse ; atlas de 1024–2048 px.
5. **Éclairage** : cycle jour/aube, lightmaps cuites pour l'intérieur de la grange, ombres limitées au joueur/proches ;
   budget : 1 lumière directionnelle + ≤ 2 locales par zone (Compatibility).
6. **Effets** : particules de l'éveil (CPU), halo du pendentif, poussière, brume volumétrique légère.
7. **Son** : musique adaptative, ambiances (vent, oiseaux, grange), pas selon le sol, voix/bruitages d'éveil, mixage et réglages de volume.
8. **Optimisation et mesure** : profil sur 2–3 appareils (bas/moyen/haut de gamme), cibles 30–60 FPS, mémoire < 1 Go,
   LOD, occlusion simple, MultiMesh pour la végétation, options de qualité (ombres on/off, échelle de rendu).
9. **Validation** : captures comparatives, tests de lisibilité des interactions, régression gameplay (relancer `tools/run_tests.sh`).
