# ACCEPTANCE_CHECKLIST — scénario chapitre 1 (v0.3)

Légende : ✅ validé · ❌ en échec · ⬜ **NON VÉRIFIÉ**.
État de cette livraison : **tout est ⬜**, sauf la ligne marquée « statique ». Aucun test n'a été exécuté dans Godot ni sur appareil.
« Auto » = couvert par `tests/integration_test.gd` (écrit, jamais exécuté). « Manuel » = à faire à la main ; colonne *Observé* à remplir.

## A. Démarrage
| # | Étape | Type | Statut | Observé |
|---|---|---|---|---|
| A1 | Scripts : délimiteurs, références, autoloads (analyse statique) | Statique | ✅ (analyse statique seulement) | `check_project.py` OK |
| A1b | Le lanceur `run_tests.sh` retourne non-zéro quand Godot échoue | Faux exécutables | ✅ (lanceur seulement, pas Godot) | `docs/launcher_selftest.txt` |
| A2 | `godot --headless --import` sans erreur | Manuel | ⬜ | |
| A3 | Menu principal s'affiche (paysage) | Manuel | ⬜ | |
| A4 | Nouvelle partie charge le monde sans erreur de script | Auto+Manuel | ⬜ | |

## B. Parcours du chapitre
| # | Étape | Type | Statut | Observé |
|---|---|---|---|---|
| B1 | Introduction (2 répliques) puis contrôle rendu | Auto+Manuel | ⬜ | |
| B1b | Parcours COMPLET à pied, sans téléportation (`docs/WALKTHROUGH_MANUEL.md`) | Auto+Manuel | ⬜ | |
| B2 | Aël marche, court, saute, la caméra suit | Manuel | ⬜ | |
| B3 | Collisions : maisons, clôtures, arbres, grange bloquent Aël | Manuel | ⬜ | |
| B4 | Invite « Parler à Maya » → dialogue → étape 2 | Auto+Manuel | ⬜ | |
| B5 | Ramasser la caisse (invite, objet porté visible) | Auto+Manuel | ⬜ | |
| B6 | Poser la caisse hors zone (touche Agir) | Auto+Manuel | ⬜ | |
| B7 | Dépôt dans la grange → appel de Noé → étape 3 | Auto+Manuel | ⬜ | |
| B8 | Invite « Soulever la poutre » uniquement à l'étape 3 | Auto+Manuel | ⬜ | |
| B9 | Cinématique : poutre soulevée, flash, tremblement, bannière « POUVOIR DÉBLOQUÉ », Noé se relève | Manuel | ⬜ | |
| B10 | Super-force débloquée et utilisable (touche R / bouton) | Auto+Manuel | ⬜ | |
| B11 | Écran de fin de chapitre → Continuer à explorer | Auto+Manuel | ⬜ | |

## C. Sauvegarde
| # | Étape | Type | Statut | Observé |
|---|---|---|---|---|
| C1 | Sauvegarder pendant le transport → quitter → Continuer : caisse toujours portée | Auto+Manuel | ⬜ | |
| C2 | Sauvegarder caisse posée → recharger : caisse au même endroit | Auto+Manuel | ⬜ | |
| C3 | Sauvegarder après la mission → recharger : chapitre terminé, pouvoir, Noé debout | Auto+Manuel | ⬜ | |
| C4 | Sauvegarde corrompue/incohérente/sans version : refusée avec message, état inchangé | Auto+Manuel | ⬜ | |
| C4b | Échec d'écriture : l'ancienne sauvegarde reste valide | Auto | ⬜ | |
| C4c | Migration d'une sauvegarde v1 | Auto | ⬜ | |
| C5 | Sauvegarde refusée pendant la cinématique (message) | Manuel | ⬜ | |
| C6 | Menu → Nouvelle partie → Quitter → Continuer (cycle complet) | Manuel | ⬜ | |

## D. Mobile (appareil réel requis)
| # | Étape | Type | Statut | Observé |
|---|---|---|---|---|
| D1 | Joystick + glissement caméra + SAUT simultanés | Auto(injecté)+Manuel | ⬜ | |
| D2 | AGIR fait avancer un dialogue ; interaction pendant un dialogue sans double déclenchement | Auto+Manuel | ⬜ | |
| D3 | Pause (bouton) / reprise ; bouton Pause réutilisable ; joystick non « coincé » | Auto(injecté)+Manuel | ⬜ | |
| D4 | Bouton Retour d'Android ouvre/ferme la pause (ne ferme pas l'app) | Manuel | ⬜ | |
| D5 | Mise en arrière-plan puis retour : sauvegarde auto, pas de crash | Manuel | ⬜ | |
| D6 | Paysage forcé (gauche et droite) | Manuel | ⬜ | |
| D7 | Ratios 16:9, 19.5:9, 20:9 : boutons et HUD entièrement visibles | Manuel | ⬜ | |
| D8 | Encoche / îlot dynamique / barre de gestes : rien de masqué (iPhone récent, Android à encoche) | Manuel | ⬜ | |
| D9 | Taille des commandes réglable (pause − / +), mémorisée au redémarrage | Manuel | ⬜ | |
| D10 | Fluidité (≥ 30 FPS) et température après 10 min | Manuel | ⬜ | |

## E. Livraison
| # | Étape | Statut | Observé |
|---|---|---|---|
| E1 | APK de test compilé et installé | ⬜ (aucun APK : pas de SDK/templates) | |
| E2 | IPA / projet Xcode | ⬜ (Mac + Xcode + signature requis) | |

## Procédure manuelle
1. Ouvrir `project.godot` (Godot 4.3+), attendre l'import, F5. Noter la version exacte de Godot et les messages rouges de la Sortie.
2. Dérouler A→C dans l'ordre ; pour chaque ligne, remplir *Observé* (ce qui s'est réellement passé) et le statut.
3. Sur téléphone : exporter (voir README), installer, dérouler D. Noter modèle, OS, ratio.
4. Joindre captures et journaux (`adb logcat | grep -i godot`).
