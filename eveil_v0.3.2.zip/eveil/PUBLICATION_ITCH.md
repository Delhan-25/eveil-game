# Publier ÉVEIL (Web, iPhone/Safari) sur itch.io

> **État honnête : l'export Web n'a PAS été produit dans cet environnement** (Godot et ses modèles d'export absents, pas de réseau).
> Ce ZIP contient le **projet prêt à exporter** + les outils. Vous devez faire l'export (≈ 5 minutes, ci-dessous), puis tester sur iPhone.
> Rien dans ce document n'a été vérifié sur iPhone ni dans itch.io.

## 1. Produire l'export (une fois, sur un ordinateur)
1. Installer **Godot 4.3 ou plus récent** (version standard) : https://godotengine.org/download
2. Dans Godot : *Éditeur → Gérer les modèles d'export → Télécharger et installer* (modèles de **la même version** que l'éditeur).
3. Ouvrir `project.godot` (la première ouverture importe le projet).
4. **Méthode automatique** (recommandée) :
   ```
   GODOT=/chemin/vers/godot sh tools/export_web.sh
   ```
   Le script régénère le preset Web (**multithreading désactivé**), importe, exporte dans `build/web/`, lance `tools/verify_web_export.py`
   (refuse un export multithreadé ou incomplet) puis crée `build/eveil_web_itch.zip` (index.html à la racine du ZIP). Il retourne non-zéro au premier échec.
5. **Méthode manuelle** : *Projet → Exporter → « Web (iPhone/itch.io) »* ; vérifier que **« Thread Support » est décoché** ; exporter le projet vers `build/web/index.html` ;
   zipper **le contenu** du dossier (pas le dossier lui-même) : `index.html` doit être à la racine du ZIP.
   Si vous exportez à la main, lancez quand même `python3 tools/verify_web_export.py build/web`.
   (Le preset utilise le champ « Head Include » ; il est généré depuis `web/head_include.html` par `python3 tools/make_web_preset.py`.)

## 2. Tester AVANT de publier (obligatoire)
`python3 tools/serve_web.py build/web 8080`, puis ouvrir `http://<IP-de-votre-ordinateur>:8080` dans **Safari sur l'iPhone** (même Wi-Fi) et dérouler `WEB_TEST_CHECKLIST.md`.
Ne publiez pas si le chargement, le tactile ou la fluidité échouent.

## 3. Publier sur itch.io
1. itch.io → *Dashboard → Create new project*.
2. **Kind of project : HTML**.
3. *Uploads* : envoyer `eveil_web_itch.zip`, cocher **« This file will be played in the browser »**.
4. *Embed options* :
   - **Viewport dimensions** : 1280 × 720.
   - **Mobile friendly** : activé, orientation **Landscape**.
   - **Fullscreen button** : activé.
   - **SharedArrayBuffer support** : **laisser décoché** (inutile : l'export est sans multithreading).
   - Éviter « Automatically start on page load » tant que le chargement n'est pas validé sur iPhone.
5. *Visibility* : commencer par **Draft/Restricted** (mot de passe), tester l'URL sur iPhone, puis passer en **Public**.
6. Noms exacts des options : peuvent varier ; se fier à l'interface itch.io actuelle.

## 4. Limites iPhone à connaître (à confirmer par vos essais)
- **Pas de plein écran** sur iPhone Safari pour une page web (API Fullscreen non disponible) : le bouton « Fullscreen » d'itch.io ne fonctionnera pas ; la barre d'adresse réduit la zone de jeu.
  Option hors itch.io : héberger l'export ailleurs (HTTPS) avec `progressive_web_app/enabled=true` puis « Ajouter à l'écran d'accueil » pour un affichage plein écran. **Non testé.**
- **Pas de verrouillage d'orientation** : la page affiche « Tourne ton téléphone en mode paysage » en portrait (testé dans Chromium émulé, pas Safari) et le jeu se met en pause en portrait.
- **Sauvegarde** : stockée dans le navigateur (IndexedDB). Elle disparaît en navigation privée et Safari peut purger les données de sites peu utilisés ; elle est propre à chaque navigateur/appareil. Une sauvegarde automatique est déclenchée à la perte de focus de l'onglet. **Persistance non vérifiée sur iPhone.**
- **Performances** : WebGL 2 requis (iOS 15+). Ombres désactivées par défaut sur Web ; résolution plafonnée à 1,5×. Activez « FPS : oui » dans le menu pause pour mesurer. Cible : ≥ 30 FPS. **Non mesuré.**
- Pas de son (aucun son dans le jeu).
