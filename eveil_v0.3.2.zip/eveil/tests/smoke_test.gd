extends SceneTree
## Test de fumée RAPIDE (état interne) : charge les scripts, instancie le monde, vérifie la
## sauvegarde sur un état COHÉRENT et le refus d'un état incohérent.
## Il appelle Quests.complete_step() directement : il NE prouve PAS le parcours joueur
## (voir tests/integration_test.gd).
## Lancer : godot --headless --path . -s res://tests/smoke_test.gd   (code 0 = OK)

var _frame := 0
var _failures := 0
var _world: Node = null


func _check(ok: bool, msg: String) -> void:
	print(("OK     " if ok else "ECHEC  ") + msg)
	if not ok:
		_failures += 1


func _process(_delta: float) -> bool:
	_frame += 1
	var game := root.get_node("Game")
	var quests := root.get_node("Quests")
	var powers := root.get_node("Powers")
	if _frame == 3:   # après _ready des autoloads
		for path in ["res://scripts/player/player.gd", "res://scripts/world/world.gd",
				"res://scripts/ui/hud.gd", "res://scripts/ui/touch_controls.gd",
				"res://scripts/ui/pause_menu.gd", "res://scripts/ui/chapter_end.gd",
				"res://scenes/main_menu.tscn", "res://scenes/world.tscn"]:
			_check(load(path) != null, "chargement " + path)
		game.call("new_game")
		_world = (load("res://scenes/world.tscn") as PackedScene).instantiate()
		root.add_child(_world)
	elif _frame == 30:
		_check(_world.get("player") != null, "joueur instancié")
		_check(_world.get("crate") != null, "caisse instanciée")
		quests.call("complete_step", "talk_maya")
		_check(quests.get("step_index") == 1, "étape 0 -> 1")
	elif _frame == 35:
		# État cohérent (étape 1, caisse au départ, aucun pouvoir) : doit être sauvegardable et rechargeable.
		_check(game.call("save_game"), "sauvegarde écrite (état cohérent)")
		_check(game.call("load_game"), "sauvegarde relue (état cohérent)")
		_check(quests.get("step_index") == 1, "étape restaurée")
	elif _frame == 40:
		powers.call("unlock", "super_strength")
		_check(powers.call("is_unlocked", "super_strength"), "pouvoir débloqué")
		_check(powers.call("try_use", _world.get("player")), "pouvoir utilisable")
		# Étape 1 + super-force = incohérent : la sauvegarde doit être refusée au chargement.
		_check(game.call("save_game"), "sauvegarde d'un état incohérent écrite")
		_check(game.call("load_game") == false, "état incohérent (pouvoir avant la fin) refusé au chargement")
		_check(String(game.get("last_load_error")) != "", "message d'erreur fourni")
	elif _frame >= 60:
		var dir := DirAccess.open("user://")
		if dir != null and FileAccess.file_exists("user://eveil_save.json"):
			DirAccess.remove_absolute("user://eveil_save.json")
		_world.queue_free()
		print("Échecs : %d" % _failures)
		quit(_failures)
		return true
	return false
