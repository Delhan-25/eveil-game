#!/bin/sh
# Exporte la version Web (sans multithreading), la vérifie et fabrique le ZIP itch.io.
# Usage : GODOT=/chemin/vers/godot sh tools/export_web.sh
# Prérequis : Godot 4.3+ ET les modèles d'export Web de la MÊME version installés
#             (Éditeur > Gérer les modèles d'export). Retourne non-zéro au premier échec.
GODOT="${GODOT:-godot}"
cd "$(dirname "$0")/.." || exit 2
command -v "$GODOT" > /dev/null 2>&1 || [ -x "$GODOT" ] || { echo "Godot introuvable ($GODOT)"; exit 127; }
python3 tools/make_web_preset.py || exit 1
rm -rf build/web build/logs/web_*.log; mkdir -p build/web build/logs
"$GODOT" --headless --path . --import > build/logs/web_01_import.log 2>&1
code=$?; echo "[import] code=$code"; [ "$code" -eq 0 ] || { tail -n 20 build/logs/web_01_import.log; exit 1; }
"$GODOT" --headless --path . --export-release "Web (iPhone/itch.io)" build/web/index.html > build/logs/web_02_export.log 2>&1
code=$?; echo "[export] code=$code"; tail -n 20 build/logs/web_02_export.log
[ "$code" -eq 0 ] || exit 1
grep -E 'SCRIPT ERROR|Parse Error|^ERROR:|Unicode parsing error' build/logs/web_02_export.log > /dev/null && { echo "erreurs dans le journal d'export"; exit 1; }
python3 tools/verify_web_export.py build/web || exit 1
python3 - <<'PY' || exit 1
import os, zipfile
src, out = 'build/web', 'build/eveil_web_itch.zip'
if os.path.exists(out): os.remove(out)
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for f in sorted(os.listdir(src)):          # index.html DOIT être à la racine du ZIP
        z.write(os.path.join(src, f), f)
print('ZIP itch.io :', out, '(', round(os.path.getsize(out)/1e6, 2), 'Mo )')
PY
