#!/usr/bin/env python3
"""Serveur local pour tester l'export Web : python3 tools/serve_web.py [dossier=build/web] [port=8080]
Ouvrir ensuite http://<IP-du-PC>:8080 depuis Safari (iPhone sur le même Wi-Fi).
Sans multithreading, aucun en-tête COOP/COEP n'est nécessaire. Localhost/HTTP suffit pour le test."""
import http.server, os, sys, socketserver
d = sys.argv[1] if len(sys.argv) > 1 else 'build/web'
port = int(sys.argv[2]) if len(sys.argv) > 2 else 8080
os.chdir(d)
class H(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      '.wasm': 'application/wasm', '.js': 'text/javascript', '.pck': 'application/octet-stream'}
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store'); super().end_headers()
with socketserver.TCPServer(('', port), H) as s:
    print(f'Servi : http://0.0.0.0:{port}  (dossier {os.getcwd()})'); s.serve_forever()
