#!/usr/bin/env python3
"""Vérifications statiques du projet (sans moteur Godot).
Usage : python3 tools/check_project.py   (depuis la racine du projet)
Ne remplace PAS un vrai lancement dans Godot."""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errors, warnings = [], []
gd_files = []
for d, _, fs in os.walk(ROOT):
    if '/.godot' in d: continue
    for f in fs:
        if f.endswith('.gd'): gd_files.append(os.path.join(d, f))

def strip_strings(line):
    out, q, esc = [], None, False
    for ch in line:
        if q:
            if esc: esc = False
            elif ch == '\\': esc = True
            elif ch == q: q = None
            continue
        if ch in '"\'': q = ch; continue
        if ch == '#': break
        out.append(ch)
    return ''.join(out)

class_names, funcs_by_file, text_by_file = {}, {}, {}
for p in gd_files:
    rel = os.path.relpath(p, ROOT)
    txt = open(p, encoding='utf-8').read()
    text_by_file[rel] = txt
    funcs_by_file[rel] = set(re.findall(r'^\s*(?:static\s+)?func\s+(\w+)', txt, re.M))
    m = re.search(r'^class_name\s+(\w+)', txt, re.M)
    if m:
        if m.group(1) in class_names: errors.append(f'{rel}: class_name dupliqué {m.group(1)}')
        class_names[m.group(1)] = rel

for rel, txt in text_by_file.items():
    depth = {'(': 0, '[': 0, '{': 0}
    pairs = {')': '(', ']': '[', '}': '{'}
    for i, raw in enumerate(txt.split('\n'), 1):
        if raw.strip() == '' : continue
        indent = re.match(r'^[ \t]*', raw).group(0)
        if ' ' in indent and depth['('] == depth['['] == depth['{'] == 0 and not raw.lstrip().startswith('#'):
            errors.append(f'{rel}:{i}: indentation avec espaces')
        line = strip_strings(raw)
        for ch in line:
            if ch in depth: depth[ch] += 1
            elif ch in pairs: depth[pairs[ch]] -= 1
            if any(v < 0 for v in depth.values()):
                errors.append(f'{rel}:{i}: parenthèse fermante en trop'); depth = {k: 0 for k in depth}
    if any(depth.values()): errors.append(f'{rel}: délimiteurs non équilibrés {depth}')
    # connect(handler) : le handler doit exister dans le fichier
    for m in re.finditer(r'\.connect\((_?\w+)\)', txt):
        h = m.group(1)
        if h not in funcs_by_file[rel] and h not in ('queue_redraw',):
            # peut être une méthode d'un autre script (ex: open/close) -> avertissement seulement
            warnings.append(f'{rel}: handler connecté introuvable localement : {h}')
    # ':=' sur une valeur Variant connue (dictionnaires / .get) -> inférence impossible
    for i, raw in enumerate(txt.split('\n'), 1):
        if re.search(r':=\s*[\w\.]+\.get\(', raw) or re.search(r':=\s*\w+\[["\'\w]+\]\s*$', raw):
            warnings.append(f'{rel}:{i}: ":=" sur Variant probable -> {raw.strip()}')

# Références res://
all_text = '\n'.join(list(text_by_file.values()))
for p in [os.path.join(ROOT, 'project.godot')] + [os.path.join(d, f) for d, _, fs in os.walk(ROOT) for f in fs if f.endswith('.tscn')]:
    t = open(p, encoding='utf-8').read(); all_text += '\n' + t
for ref in set(re.findall(r'res://[\w/\.\-]+', all_text)):
    if not os.path.exists(os.path.join(ROOT, ref[6:])): errors.append(f'référence cassée : {ref}')

# Autoloads : méthodes appelées existent ?
auto = {'Game': 'scripts/autoload/game.gd', 'Quests': 'scripts/autoload/quest_manager.gd',
        'Dialogue': 'scripts/autoload/dialogue_manager.gd', 'Powers': 'scripts/autoload/power_manager.gd'}
members = {}
for name, rel in auto.items():
    t = text_by_file[rel]
    members[name] = set(re.findall(r'^\s*func\s+(\w+)', t, re.M)) | set(re.findall(r'^var\s+(\w+)', t, re.M)) \
        | set(re.findall(r'^signal\s+(\w+)', t, re.M)) | set(re.findall(r'^const\s+(\w+)', t, re.M))
for rel, t in text_by_file.items():
    for name in auto:
        for m in re.finditer(r'\b%s\.(\w+)' % name, t):
            if m.group(1) not in members[name]:
                errors.append(f'{rel}: {name}.{m.group(1)} inexistant')

# Classes globales utilisées existent ?
for rel, t in text_by_file.items():
    for m in re.finditer(r'\b([A-Z]\w+)\.(?:new|create|build|make)\(', t):
        n = m.group(1)
        builtin = {'Timer','Node3D','Label','Button','Control','ColorRect','CanvasLayer','MeshInstance3D','Area3D',
                   'StaticBody3D','CollisionShape3D','BoxShape3D','SphereShape3D','CapsuleShape3D','CylinderShape3D',
                   'BoxMesh','SphereMesh','CylinderMesh','CapsuleMesh','TorusMesh','PrismMesh','Environment','Sky',
                   'ProceduralSkyMaterial','WorldEnvironment','DirectionalLight3D','OmniLight3D','StandardMaterial3D',
                   'MultiMesh','MultiMeshInstance3D','Label3D','CPUParticles3D','InputEventKey','Theme','StyleBoxFlat',
                   'StyleBoxEmpty','PanelContainer','VBoxContainer','CenterContainer','Gradient','Basis','RandomNumberGenerator',
                   'SpringArm3D','Camera3D','JSON','InputEventScreenTouch','InputEventScreenDrag','Transform3D','Vector2','Vector3','Color','PackedVector2Array','PackedColorArray','Callable'}
        if n not in class_names and n not in builtin:
            warnings.append(f'{rel}: classe inconnue {n}')

print(f'{len(gd_files)} scripts analysés, {len(class_names)} class_name.')
for w in warnings: print('AVERTISSEMENT', w)
for e in errors: print('ERREUR', e)
print('RÉSULTAT :', 'ÉCHEC' if errors else 'OK (analyse statique uniquement)')
sys.exit(1 if errors else 0)
