#!/usr/bin/env python3
"""Vérifie un dossier d'export Web ÉVEIL (statique) : fichiers, absence de multithreading, shell iPhone.
Usage : python3 tools/verify_web_export.py [dossier=build/web]
Ne prouve PAS que le jeu fonctionne : il faut l'ouvrir dans Safari (voir WEB_TEST_CHECKLIST.md)."""
import os, re, sys
d = sys.argv[1] if len(sys.argv) > 1 else 'build/web'
errs, info = [], []
def has(name): return os.path.isfile(os.path.join(d, name))
if not os.path.isdir(d): sys.exit(f'ERREUR : dossier introuvable : {d}')
files = sorted(os.listdir(d))
for need in ('index.html', 'index.js', 'index.wasm', 'index.pck'):
    if not has(need): errs.append(f'fichier manquant : {need}')
workers = [f for f in files if f.endswith('.worker.js') or f.endswith('.audio.worklet.js')]
if workers: errs.append(f'export MULTITHREADÉ détecté (fichiers worker : {workers}) -> thread_support doit être false')
if has('index.html'):
    h = open(os.path.join(d, 'index.html'), encoding='utf-8', errors='replace').read()
    if '"threads":true' in h.replace(' ', '') or '"threads": true' in h: errs.append('index.html : config threads=true')
    if 'eveil-rotate' not in h: errs.append("index.html : écran de rotation absent (head_include non appliqué)")
    if 'user-scalable=no' not in h: errs.append('index.html : meta viewport iPhone absente')
    if 'devicePixelRatio' not in h: errs.append('index.html : plafond de résolution absent')
    m = re.search(r'"executable"\s*:\s*"([^"]+)"', h)
    if m and not has(m.group(1) + '.wasm'): errs.append(f'executable "{m.group(1)}" : .wasm correspondant absent')
total = 0
for f in files:
    sz = os.path.getsize(os.path.join(d, f)); total += sz
    info.append(f'  {f:28s} {sz/1e6:8.2f} Mo')
print('\n'.join(info)); print(f'  TOTAL {total/1e6:.2f} Mo')
if has('index.wasm') and os.path.getsize(os.path.join(d,'index.wasm')) < 1_000_000: errs.append('index.wasm anormalement petit')
for e in errs: print('ERREUR', e)
print('RÉSULTAT :', 'ÉCHEC' if errs else 'OK (vérification statique de l\'export seulement)')
sys.exit(1 if errs else 0)
