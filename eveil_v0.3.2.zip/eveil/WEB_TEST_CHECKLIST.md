# WEB_TEST_CHECKLIST — iPhone / Safari

Légende : ✅ validé · ❌ échec · ⬜ **NON VÉRIFIÉ**. État de cette livraison : tout est ⬜ sauf lignes « Chromium/outils ».
Noter : modèle d'iPhone, version d'iOS, URL testée, date.

| # | Vérification | Statut | Observé |
|---|---|---|---|
| W0a | Écran de rotation visible en portrait, masqué en paysage, DPR plafonné à 1,5, pas de défilement horizontal (Chromium émulé iPhone, page-test) | ✅ Chromium seulement | voir TEST_REPORT_WEB.md |
| W0b | `verify_web_export.py` refuse un export multithreadé/incomplet (dossiers synthétiques) | ✅ outils seulement | idem |
| W1 | Export produit par `tools/export_web.sh` sans erreur, `verify_web_export.py` OK | ⬜ | |
| W2 | Safari iPhone charge la page, barre de progression, menu principal visible | ⬜ | |
| W3 | Aucun message « SharedArrayBuffer »/COOP/COEP (export sans threads) | ⬜ | |
| **Affichage** | | | |
| W4 | Paysage : jeu plein cadre, HUD et boutons entièrement visibles (encoche/Dynamic Island, côté gauche et droit) | ⬜ | |
| W5 | Portrait : message « Tourne ton téléphone » + jeu en pause ; retour paysage → pause reprenable | ⬜ | |
| W6 | Pas de zoom au double tap, pas de scroll de page, pas de menu contextuel | ⬜ | |
| **Tactile** | | | |
| W7 | Joystick + glissement caméra + SAUT simultanés | ⬜ | |
| W8 | AGIR fait défiler les dialogues ; pas de double déclenchement | ⬜ | |
| W9 | Pause tactile, reprise, nouvelle pause (bouton pas « coincé ») | ⬜ | |
| W10 | Taille des commandes réglable (pause − / +) et mémorisée | ⬜ | |
| **Missions** | | | |
| W11 | Nouvelle partie → intro → Maya | ⬜ | |
| W12 | Ramasser/porter la caisse → grange → appel de Noé | ⬜ | |
| W13 | Poutre → cinématique → super-force → écran de fin | ⬜ | |
| W14 | Pouvoir utilisable (bouton POUVOIR) | ⬜ | |
| **Sauvegarde** | | | |
| W15 | Sauvegarder → fermer l'onglet → rouvrir → Continuer : état restauré | ⬜ | |
| W16 | Mise en arrière-plan (accueil iOS) puis retour : pas de crash, sauvegarde auto | ⬜ | |
| **Performances** | | | |
| W17 | FPS (menu pause → « FPS : oui ») dans le village, dans la grange, pendant la cinématique | ⬜ | min/moyen : |
| W18 | 10 min de jeu : pas de plantage Safari (mémoire), chauffe acceptable | ⬜ | |
| W19 | Comparaison ombres oui/non (impact FPS) | ⬜ | |
| **itch.io** | | | |
| W20 | Page itch.io (draft) : le jeu se lance dans l'iframe sur iPhone | ⬜ | |
| W21 | Taille du ZIP et temps de chargement en 4G | ⬜ | |
