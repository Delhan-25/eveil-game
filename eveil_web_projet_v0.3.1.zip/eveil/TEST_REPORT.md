# TEST_REPORT — ÉVEIL v0.3.0

Statuts : **RÉUSSI** · **ÉCHOUÉ** · **NON EXÉCUTÉ**.
> **Aucun test Godot n'a été exécuté. Le lot n'est pas validé comme jouable ni exportable.**

## Environnement (2026-10-18)
| Élément | Valeur |
|---|---|
| Système | Linux x86_64, conteneur sans écran/GPU |
| Godot | **absent** — version inconnue (`which godot` → introuvable) |
| Réseau | inaccessible (aucun téléchargement possible) |
| Java | OpenJDK 21 présent ; **Android SDK/adb absents** ; pas de Mac/Xcode ; aucun appareil |

## Résultats par exigence
| Exigence | Statut | Preuve / blocage |
|---|---|---|
| P1 — Lanceur `tools/run_tests.sh` ne masque plus les échecs | **RÉUSSI** (testé avec de FAUX exécutables, pas avec Godot) | `docs/launcher_selftest.txt` |
| P2 — Remplacement de sauvegarde sans suppression préalable | Code corrigé ; test automatique **NON EXÉCUTÉ** | `game.gd` `save_game()` |
| P2 — Politique de chargement explicite | Code + tests écrits ; **NON EXÉCUTÉ** | v2 obligatoire, v1 migrée, reste refusé |
| P3 — Mention « v0.1 » corrigée | Corrigé (`Game.VERSION` = 0.3.0) ; rendu **NON EXÉCUTÉ** | `main_menu.gd` |
| P3 — Import/ouverture Godot 4.3+, correction des erreurs de parsing | **NON EXÉCUTÉ** | Godot absent |
| P3 — Tests de fumée et d'intégration | **NON EXÉCUTÉ** | Godot absent |
| P3 — Parcours à pied sans téléportation | Test auto + procédure manuelle écrits ; **NON EXÉCUTÉ** | `test_walkthrough()`, `docs/WALKTHROUGH_MANUEL.md` |
| P3 — Pause tactile réutilisable, doigts relâchés, AGIR fait défiler | Test (événements injectés) écrit ; **NON EXÉCUTÉ**. Appareil réel : **NON EXÉCUTÉ** | `test_multitouch()` |
| Export APK / IPA | **NON EXÉCUTÉ** | pas de SDK/templates ; iOS : Mac + Xcode + signature requis |
| Analyse statique `tools/check_project.py` | **RÉUSSI** (code 0, 20 scripts, 12 class_name) | ne détecte pas les erreurs de typage/exécution |

## P1 en détail — preuve du lanceur (exécutée réellement, avec faux Godot)
Commande : `GODOT=<faux> sh tools/run_tests.sh`

| Faux exécutable | Comportement simulé | Code final du lanceur |
|---|---|---|
| `fake_fail23` | renvoie 23 à chaque appel (cas de l'audit) | **1** (arrêt à `--version`) |
| `fake_scripterr` | code 0 + « SCRIPT ERROR » dans la sortie | **1** |
| `fake_integ_fail` | tout réussit sauf `integration_test.gd` (code 1) | **1** (`[05_integration] code=1`) |
| `fake_ok` | réussit toujours | **0** (aucun faux échec) |
| inexistant | — | **127** |

Cause du défaut v0.2 : `cmd | tee` → `$?` = statut de `tee`. Correction : chaque commande écrit directement dans `build/logs/<nom>.log`, son code est lu immédiatement, aucun pipe ; le lanceur s'arrête si `--version`, l'import ou le démarrage échouent. Un journal contenant `SCRIPT ERROR`, `Parse Error` ou une ligne `ERROR:` fait échouer l'étape même avec code 0 (peut produire un faux échec si le moteur écrit un `ERROR:` bénin : lire alors le journal).
Variante portable : `sh tools/run_tests.sh` (le bit exécutable est conservé dans le ZIP).

## Politique de sauvegarde (v0.3)
- `version` obligatoire : 2 = courant ; 1 = migrée (caisse reconstruite depuis l'étape) ; autre/absente = refus.
- Champs requis : `step`, `powers`, `flags`, `play_time`, `position`, `world.crate`. Absent, mauvais type, hors limites → refus avec message, **aucune modification de l'état**.
- Cohérences exigées : caisse/étape (étape 0 → départ ; 1 → départ/portée/posée ; ≥2 → livrée), super-force ⇔ chapitre terminé.
- Écriture : fichier temporaire → relecture de contrôle → `rename_absolute` (remplace la destination, sans suppression préalable). Échec d'ouverture/écriture/relecture/renommage → ancienne sauvegarde conservée + message.
- **Non simulé** : échec du seul renommage (injection de panne système requise) ; dépendance au comportement de `rename_absolute` de Godot 4.3 (affirmé par l'audit, non vérifié ici).
- 26 cas de refus et 3 cas d'acceptation sont codés dans `test_save_policy()` (NON EXÉCUTÉ).

## Risques connus
Code jamais compilé : erreurs de parsing/typage possibles. `class_name` : première ouverture dans l'éditeur ou `--import` requise. Le multitouch injecté en headless est une hypothèse à confirmer. Le rendu n'a jamais été vu. Aucun son, graphismes en primitives (passe graphique = plan seulement).

## À renvoyer après essai avec Godot
`build/logs/` complet + `build/logs/summary.txt`, version exacte de Godot, cases remplies de `ACCEPTANCE_CHECKLIST.md` et de `docs/WALKTHROUGH_MANUEL.md`.
