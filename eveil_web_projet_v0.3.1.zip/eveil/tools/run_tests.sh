#!/bin/sh
# Lanceur de vérifications ÉVEIL — POSIX sh. Usage :
#   GODOT=/chemin/vers/godot sh tools/run_tests.sh      (ou ./tools/run_tests.sh)
# Chaque commande écrit DIRECTEMENT dans build/logs/<nom>.log (aucun pipe : on garde le
# vrai code de sortie de Godot). Le script retourne :
#   0 = tout a réussi ; 1 = au moins une étape a échoué ; 127 = Godot introuvable.
# Une étape échoue si son code de sortie est non nul OU si son journal contient
# « SCRIPT ERROR », « Parse Error » ou une ligne commençant par « ERROR: ».

GODOT="${GODOT:-godot}"
cd "$(dirname "$0")/.." || exit 2
LOGDIR="build/logs"
mkdir -p "$LOGDIR" || exit 2
rm -f "$LOGDIR"/*.log "$LOGDIR"/summary.txt
FAIL=0

note() { printf '%s\n' "$1" | tee -a "$LOGDIR/summary.txt"; }

# run_step <nom> <commande...> : exécute, conserve le code, inspecte le journal.
# Positionne STEP_CODE (0 = réussi, sinon échec).
run_step() {
    name="$1"; shift
    log="$LOGDIR/$name.log"
    "$@" > "$log" 2>&1
    code=$?
    STEP_CODE=$code
    if [ "$code" -eq 0 ] && grep -E 'SCRIPT ERROR|Parse Error|^ERROR:' "$log" > /dev/null 2>&1; then
        note "[$name] code=0 MAIS erreurs de script dans le journal -> ÉCHEC"
        STEP_CODE=1
    else
        note "[$name] code=$code"
    fi
    tail -n 20 "$log"
    if [ "$STEP_CODE" -ne 0 ]; then FAIL=1; fi
}

# Godot présent ?
if ! command -v "$GODOT" > /dev/null 2>&1 && [ ! -x "$GODOT" ]; then
    note "[godot] INTROUVABLE ($GODOT) -> NON EXÉCUTÉ. Définir GODOT=/chemin/vers/godot."
    exit 127
fi

run_step 00_version "$GODOT" --version
[ "$STEP_CODE" -ne 0 ] && { note "ARRÊT : Godot inutilisable."; exit 1; }

run_step 01_static python3 tools/check_project.py

run_step 02_import "$GODOT" --headless --path . --import
[ "$STEP_CODE" -ne 0 ] && { note "ARRÊT : l'import a échoué, les tests seraient sans valeur."; exit 1; }

run_step 03_boot_main_menu "$GODOT" --headless --path . --quit-after 120
[ "$STEP_CODE" -ne 0 ] && { note "ARRÊT : le menu principal ne démarre pas."; exit 1; }

run_step 04_smoke "$GODOT" --headless --path . -s res://tests/smoke_test.gd
run_step 05_integration "$GODOT" --headless --path . -s res://tests/integration_test.gd

if [ "$FAIL" -eq 0 ]; then
    note "RÉSULTAT GLOBAL : RÉUSSI"
    exit 0
fi
note "RÉSULTAT GLOBAL : ÉCHOUÉ (voir $LOGDIR/)"
exit 1
