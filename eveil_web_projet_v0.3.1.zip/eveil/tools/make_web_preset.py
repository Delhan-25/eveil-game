#!/usr/bin/env python3
"""Régénère le preset Web dans export_presets.cfg à partir de web/head_include.html.
Usage : python3 tools/make_web_preset.py   (depuis n'importe où)
Refuse un head_include contenant des guillemets doubles ou des antislashs (cassent le .cfg)."""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
head = open(os.path.join(ROOT, 'web', 'head_include.html'), encoding='utf-8').read()
if '"' in head or '\\' in head.replace('\\u00e9', ''):
    sys.exit('head_include.html : guillemets doubles / antislash interdits (utiliser \' et \\uXXXX).')
head = re.sub(r'\n\s*', '', head.strip())
preset = f'''[preset.2]

name="Web (iPhone/itch.io)"
platform="Web"
runnable=true
advanced_options=false
dedicated_server=false
custom_features=""
export_filter="all_resources"
include_filter=""
exclude_filter="tests/*, tools/*, docs/*, web/*, *.md"
export_path="build/web/index.html"
encryption_include_filters=""
encryption_exclude_filters=""
encrypt_pck=false
encrypt_directory=false

[preset.2.options]

custom_template/debug=""
custom_template/release=""
variant/extensions_support=false
variant/thread_support=false
vram_texture_compression/for_desktop=true
vram_texture_compression/for_mobile=false
html/export_icon=true
html/custom_html_shell=""
html/head_include="{head}"
html/canvas_resize_policy=2
html/focus_canvas_on_start=true
html/experimental_virtual_keyboard=false
progressive_web_app/enabled=false
'''
cfg_path = os.path.join(ROOT, 'export_presets.cfg')
cfg = open(cfg_path, encoding='utf-8').read()
cfg = re.split(r'\n\[preset\.2\]', cfg)[0].rstrip('\n') + '\n\n' + preset
open(cfg_path, 'w', encoding='utf-8').write(cfg)
print('Preset Web écrit dans', cfg_path, '(thread_support=false)')
