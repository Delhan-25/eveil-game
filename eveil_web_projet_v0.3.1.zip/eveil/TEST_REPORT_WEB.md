# TEST_REPORT_WEB — ÉVEIL Web v0.3.1

Statuts : **RÉUSSI** · **ÉCHOUÉ** · **NON EXÉCUTÉ**.

> **L'export Web n'a pas été produit ni testé : Godot et ses modèles d'export Web sont absents, le réseau est inaccessible.**
> Il n'existe donc ni `index.html`, ni `.wasm`, ni `.pck` dans cette livraison, et rien n'a tourné dans Safari.

## Environnement (2026-10-18)
Linux x86_64 sans GPU ; Godot absent ; modèles d'export absents ; réseau inaccessible ; Chromium headless (Playwright) présent ; aucun iPhone ni WebKit/Safari.

## Résultats
| Élément | Statut | Détail |
|---|---|---|
| Export Web sans multithreading (`thread_support=false`) | **NON EXÉCUTÉ** | preset écrit (`export_presets.cfg`, [preset.2]) ; jamais ouvert dans Godot |
| Lancement dans Safari iPhone | **NON EXÉCUTÉ** | |
| Commandes tactiles (réelles) | **NON EXÉCUTÉ** | tests injectés écrits (`tests/integration_test.gd`), jamais lancés |
| Missions de bout en bout | **NON EXÉCUTÉ** | idem |
| Performances iPhone (FPS) | **NON EXÉCUTÉ** | compteur FPS ajouté (menu pause) pour que vous mesuriez |
| Affichage paysage — couche HTML | **RÉUSSI (Chromium émulé, page-test)** | voir ci-dessous |
| `verify_web_export.py` (logique) | **RÉUSSI (dossiers synthétiques)** | ok→0 ; worker+threads→1 ; wasm manquant→1 |
| `export_web.sh` sans Godot | **RÉUSSI** (comportement d'échec) | code 127, message clair |
| Analyse statique GDScript | **RÉUSSI** | `check_project.py` code 0 (ne compile pas GDScript) |

### Test réel de la couche HTML (Chromium, émulation iPhone, `device_scale_factor=3`)
Page-test = `index.html` minimal contenant le `head_include` de production et un canvas (ce n'est pas le jeu).
| Viewport | `devicePixelRatio` vu par la page | Écran « Tourne ton téléphone » | `touch-action` | Défilement horizontal |
|---|---|---|---|---|
| 844×390 (paysage) | 1,5 (plafonné, réel 3) | masqué | none | non |
| 390×844 (portrait) | 1,5 | **visible** | none | non |
| 932×430 (paysage) | 1,5 | masqué | none | non |

Limites : Chromium ≠ Safari/WebKit ; la page-test n'est pas Godot. **Non vérifié** : que le moteur Godot Web respecte le DPR plafonné (hypothèse : il lit `window.devicePixelRatio`), la résolution réelle du canvas, la gestion des zones sûres (choix : pas de `viewport-fit=cover`, Safari garde le canvas dans la zone sûre).

## Modifications pour le Web (voir CHANGELOG)
Détection du tactile iOS/Android Web (`web_ios`, `web_android`) en plus de `is_touchscreen_available()` ; ombres désactivées par défaut sur Web/mobile + bascule dans le menu pause ;
compteur FPS (bascule) ; sauvegarde automatique à la perte de focus ; pause automatique en portrait sur Web ; bouton Quitter déjà masqué sur Web.

## Risques connus (hypothèses non confirmées)
1. Le code n'a jamais été compilé par Godot (erreurs possibles) ; 2. performances WebGL 2 sur iPhone inconnues (nombreux petits maillages ; si < 30 FPS, prochaine étape = fusion des maillages statiques) ;
3. persistance IndexedDB et purge Safari ; 4. pas de plein écran sur iPhone ; 5. comportement de l'iframe itch.io sur iPhone ; 6. Dynamic Island/encoche en paysage.

## À renvoyer après essai
Version de Godot, `build/logs/web_*.log`, sortie de `verify_web_export.py`, taille du ZIP, `WEB_TEST_CHECKLIST.md` remplie (modèle d'iPhone, iOS, FPS relevés).
