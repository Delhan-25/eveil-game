extends SceneTree
## Test de fumée RAPIDE (état interne uniquement) : charge les scripts, instancie le monde.
## Il appelle Quests.complete_step() directement : il NE prouve PAS le parcours joueur.
## Pour le parcours réel, voir tests/integration_test.gd.
## Lancer :  godot --headless --path . -s res://tests/smoke_test.gd
## Code de sortie 0 = OK. (Non exécuté par l'auteur : Godot n'était pas disponible.)

var _frame := 0
var _failures := 0
var _world: Node = null


func _check(ok: bool, msg: String) -> void:
	print(("OK     " if ok else "ECHEC  ") + msg)
	if not ok:
		_failures += 1


func _process(_delta: float) -> bool:
	_frame += 1
	var game := root.get_node("Game")
	var quests := root.get_node("Quests")
	var powers := root.get_node("Powers")
	if _frame == 1:
		for path in ["res://scripts/player/player.gd", "res://scripts/world/world.gd",
				"res://scripts/ui/hud.gd", "res://scripts/ui/touch_controls.gd",
				"res://scripts/ui/pause_menu.gd", "res://scripts/ui/chapter_end.gd",
				"res://scenes/main_menu.tscn", "res://scenes/world.tscn"]:
			_check(load(path) != null, "chargement " + path)
		game.call("new_game")
		_world = (load("res://scenes/world.tscn") as PackedScene).instantiate()
		root.add_child(_world)
	elif _frame == 30:
		_check(_world.get("player") != null, "joueur instancié")
		_check(_world.get("crate") != null, "caisse instanciée")
		quests.call("complete_step", "talk_maya")
		_check(quests.get("step_index") == 1, "étape 1 -> 2")
		quests.call("complete_step", "carry_crate")
		_check(quests.get("step_index") == 2, "étape 2 -> 3")
		powers.call("unlock", "super_strength")
		_check(powers.call("is_unlocked", "super_strength"), "pouvoir débloqué")
		_check(powers.call("try_use", _world.get("player")), "pouvoir utilisable")
	elif _frame == 40:
		_check(game.call("save_game"), "sauvegarde écrite")
		_check(game.call("load_game"), "sauvegarde relue")
		_check(quests.get("step_index") == 2, "étape restaurée")
	elif _frame >= 60:
		print("Échecs : %d" % _failures)
		quit(_failures)
		return true
	return false
