class_name TouchControls
extends Control
## Commandes tactiles multitouch : joystick flottant (gauche), caméra par glissement
## (droite) et boutons Saut / Agir / Pouvoir / Pause. Chaque doigt est suivi par son index.

const DEADZONE := 0.12
const LOOK_SPLIT := 0.42   # fraction de la largeur : à gauche = joystick, à droite = caméra

var _joy_index: int = -1
var _joy_center: Vector2 = Vector2.ZERO
var _joy_pos: Vector2 = Vector2.ZERO
var _knob_off: Vector2 = Vector2.ZERO
var _look_index: int = -1
var _btn_index: Dictionary = {}
var _release_queue: Dictionary = {}
var _font: Font
var _insets: Dictionary = {"left": 0.0, "top": 0.0, "right": 0.0, "bottom": 0.0}
var _inset_timer: float = 0.0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = Game.touch_active
	_font = ThemeDB.fallback_font
	for n in ["jump", "interact", "power", "pause"]:
		_btn_index[n] = -1
	resized.connect(_refresh_insets)
	Game.touch_scale_changed.connect(queue_redraw)
	_refresh_insets()


func _unhandled_key_input(event: InputEvent) -> void:
	# F2 : afficher/masquer les commandes tactiles (utile pour tester sur ordinateur).
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.pressed and not k.echo and k.keycode == KEY_F2:
			visible = not visible
			_release_all()


func _notification(what: int) -> void:
	if what == NOTIFICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		_release_all()


func _release_all() -> void:
	_joy_index = -1
	_look_index = -1
	_knob_off = Vector2.ZERO
	for n in _btn_index.keys():
		if _btn_index[n] != -1 and n != "pause":
			Input.action_release(n)
		_btn_index[n] = -1
	_release_queue.clear()
	Game.touch_move = Vector2.ZERO
	Game.touch_look = Vector2.ZERO
	queue_redraw()


func _refresh_insets() -> void:
	_insets = Game.get_safe_insets()
	queue_redraw()


func _joy_r() -> float:
	return 100.0 * Game.touch_scale


func _knob_r() -> float:
	return 42.0 * Game.touch_scale


## Géométrie d'un bouton, tenant compte des zones sûres et de la taille réglée.
func _btn(n: String) -> Dictionary:
	var k := Game.touch_scale
	var right := size.x - float(_insets["right"])
	var bottom := size.y - float(_insets["bottom"])
	var top := float(_insets["top"])
	match n:
		"jump":
			return {"c": Vector2(right - 115.0 * k, bottom - 115.0 * k), "r": 66.0 * k}
		"interact":
			return {"c": Vector2(right - 258.0 * k, bottom - 88.0 * k), "r": 54.0 * k}
		"power":
			return {"c": Vector2(right - 200.0 * k, bottom - 228.0 * k), "r": 50.0 * k}
		"pause":
			return {"c": Vector2(right - 52.0, top + 52.0), "r": 30.0 * maxf(k, 1.0)}
	return {"c": Vector2.ZERO, "r": 0.0}


func _hit(n: String, pos: Vector2) -> bool:
	var b := _btn(n)
	var c: Vector2 = b["c"]
	var r: float = b["r"]
	return pos.distance_to(c) <= r + 12.0


# ---------------------------------------------------------------- Entrées

func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			_touch_down(t.index, t.position)
		else:
			_touch_up(t.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_touch_drag(d.index, d.position, d.relative)


func _touch_down(idx: int, pos: Vector2) -> void:
	for n in _btn_index.keys():
		if _btn_index[n] == -1 and _hit(n, pos):
			_btn_index[n] = idx
			_press(n)
			get_viewport().set_input_as_handled()
			return
	if Dialogue.active:
		return
	if pos.x < size.x * LOOK_SPLIT:
		if _joy_index == -1:
			_joy_index = idx
			var r := _joy_r()
			var min_x := float(_insets["left"]) + r + 10.0
			var max_x := maxf(min_x, size.x * LOOK_SPLIT)
			var min_y := float(_insets["top"]) + r + 10.0
			var max_y := maxf(min_y, size.y - float(_insets["bottom"]) - r - 10.0)
			_joy_center = Vector2(clampf(pos.x, min_x, max_x), clampf(pos.y, min_y, max_y))
			_joy_pos = pos
			_update_joy()
	elif _look_index == -1:
		_look_index = idx


func _touch_up(idx: int) -> void:
	if idx == _joy_index:
		_joy_index = -1
		_knob_off = Vector2.ZERO
		Game.touch_move = Vector2.ZERO
	elif idx == _look_index:
		_look_index = -1
	for n in _btn_index.keys():
		if _btn_index[n] == idx:
			_btn_index[n] = -1
			if n != "pause":
				_release_queue[n] = 0.07


func _touch_drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	if idx == _joy_index:
		_joy_pos = pos
		_update_joy()
	elif idx == _look_index:
		Game.touch_look += rel


func _press(n: String) -> void:
	if n == "pause":
		Game.pause_requested.emit()
		return
	_release_queue.erase(n)
	Input.action_press(n)


func _update_joy() -> void:
	var v := _joy_pos - _joy_center
	var l := v.length()
	var jr := _joy_r()
	if l > jr:
		v = v / l * jr
		l = jr
	_knob_off = v
	var strength := l / jr
	if strength < DEADZONE:
		Game.touch_move = Vector2.ZERO
	else:
		strength = (strength - DEADZONE) / (1.0 - DEADZONE)
		Game.touch_move = v.normalized() * strength


func _process(delta: float) -> void:
	_inset_timer += delta
	if _inset_timer > 0.5:
		_inset_timer = 0.0
		_insets = Game.get_safe_insets()
	for n in _release_queue.keys():
		_release_queue[n] = float(_release_queue[n]) - delta
		if float(_release_queue[n]) <= 0.0:
			Input.action_release(n)
			_release_queue.erase(n)
	if visible:
		queue_redraw()


# ---------------------------------------------------------------- Dessin

func _draw() -> void:
	var k := Game.touch_scale
	var rest := Vector2(float(_insets["left"]) + 170.0 * k, size.y - float(_insets["bottom"]) - 170.0 * k)
	var base := _joy_center if _joy_index != -1 else rest
	var knob := base + _knob_off
	draw_circle(base, _joy_r(), Color(1, 1, 1, 0.07))
	draw_arc(base, _joy_r(), 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(knob, _knob_r(), Color(1, 1, 1, 0.32 if _joy_index != -1 else 0.18))

	_draw_button("jump", "SAUT", true, false, 0.0)
	var has_prompt := Game.current_prompt != ""
	_draw_button("interact", "AGIR", true, has_prompt, 0.0)
	var p := Powers.selected_power()
	if p == null:
		_draw_button("power", "?", false, false, 0.0)
	elif p.active:
		_draw_button("power", "ACTIF", true, true, 0.0)
	elif p.cooldown_left > 0.0:
		_draw_button("power", "POUVOIR", true, false, 1.0 - p.cooldown_left / p.cooldown)
	else:
		_draw_button("power", "POUVOIR", true, true, 0.0)

	var pb := _btn("pause")
	var pc: Vector2 = pb["c"]
	var pr: float = pb["r"]
	var pa := 0.55 if _btn_index["pause"] != -1 else 0.3
	draw_circle(pc, pr, Color(0.1, 0.15, 0.25, pa + 0.15))
	draw_arc(pc, pr, 0.0, TAU, 32, Color(1, 1, 1, pa + 0.25), 3.0)
	var pk := maxf(k, 1.0)
	draw_rect(Rect2(pc + Vector2(-9, -11) * pk, Vector2(6, 22) * pk), Color(1, 1, 1, 0.9))
	draw_rect(Rect2(pc + Vector2(3, -11) * pk, Vector2(6, 22) * pk), Color(1, 1, 1, 0.9))


func _draw_button(n: String, label: String, enabled: bool, highlight: bool, cooldown_frac: float) -> void:
	var b := _btn(n)
	var c: Vector2 = b["c"]
	var r: float = b["r"]
	var pressed: bool = _btn_index[n] != -1
	var a := 0.3
	if pressed:
		a = 0.55
	if not enabled:
		a = 0.12
	var fill := Color(0.1, 0.15, 0.25, a + 0.15)
	if highlight:
		fill = Color(0.25, 0.4, 0.6, a + 0.2)
	draw_circle(c, r, fill)
	var ring := Color(1.0, 0.88, 0.4, 0.95) if highlight else Color(1, 1, 1, a + 0.25)
	draw_arc(c, r, 0.0, TAU, 40, ring, 3.0)
	if cooldown_frac > 0.0:
		draw_arc(c, r - 7.0, -PI * 0.5, -PI * 0.5 + TAU * cooldown_frac, 40, Color(0.5, 0.85, 1.0, 0.9), 5.0)
	var fs := int(18.0 * Game.touch_scale)
	var ts := _font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	draw_string(_font, c + Vector2(-ts.x * 0.5, ts.y * 0.3), label,
		HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.95 if enabled else 0.45))
