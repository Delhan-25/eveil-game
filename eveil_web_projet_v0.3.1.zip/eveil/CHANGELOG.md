# CHANGELOG

## 0.3.1 — version Web HTML5 (iPhone/Safari, itch.io) — export NON produit
Base : v0.3 (qui inclut les correctifs de la v0.2).
- `export_presets.cfg` : preset **Web (iPhone/itch.io)**, `thread_support=false`, généré par `tools/make_web_preset.py` depuis `web/head_include.html`.
- `web/head_include.html` (nouveau) : meta viewport/iOS, fond noir, `touch-action:none`, blocage des gestes de zoom, écran « Tourne ton téléphone » en portrait, plafond du `devicePixelRatio` à 1,5.
- `tools/export_web.sh`, `tools/verify_web_export.py`, `tools/serve_web.py` (nouveaux) : export + vérification (refuse multithreading/fichiers manquants) + ZIP itch.io + serveur local.
- `scripts/autoload/game.gd` : version 0.3.1 ; détection tactile `web_ios`/`web_android` ; ombres par défaut désactivées sur Web/mobile (`shadows_enabled`, persistant) ; `show_fps` ; autosave à `NOTIFICATION_APPLICATION_FOCUS_OUT` ; pause automatique en portrait sur Web.
- `scripts/world/world.gd` : ombres du soleil pilotées par `Game.shadows_enabled`.
- `scripts/ui/hud.gd`, `scripts/ui/pause_menu.gd` : compteur FPS et boutons « Ombres » / « FPS ».
- `project.godot` : `rendering_method.web="gl_compatibility"`.
- Nouveaux documents : `PUBLICATION_ITCH.md`, `WEB_TEST_CHECKLIST.md`, `TEST_REPORT_WEB.md`.

## 0.3.0 — fiabilisation (issue de l'audit v0.2) — aucun test Godot exécuté
### P0 — Lanceur de tests (`tools/run_tests.sh`)
- Réécrit en sh POSIX : plus de `| tee` (qui masquait le code de Godot). Chaque commande écrit dans `build/logs/<nom>.log`,
  son vrai code est conservé, `summary.txt` généré, arrêt si version/import/démarrage échouent, 127 si Godot introuvable.
- Testé avec de faux exécutables (code 23, « SCRIPT ERROR » avec code 0, échec de l'intégration seule, succès, absent) :
  preuve dans `docs/launcher_selftest.txt`.
### P1 — Sauvegarde (`scripts/autoload/game.gd`)
- Remplacement sans suppression préalable de l'ancienne sauvegarde ; relecture de contrôle ; en cas d'échec : ancienne sauvegarde conservée + message.
- Chargement : version obligatoire (2 courant, 1 migrée, autre refusée) ; tous les champs requis vérifiés ; cohérences caisse/étape et pouvoir/étape ;
  refus sans modification de l'état. `save_path` rendu modifiable pour les tests.
### P2 — Divers
- `scripts/ui/main_menu.gd` : version affichée depuis `Game.VERSION` (0.3.0). `export_presets.cfg` : 0.3.0 / code 3.
### Tests et documents
- `tests/integration_test.gd` : parcours à pied (`walk_to`, sans téléportation), `test_save_policy()` (26 refus, 3 acceptations, échec d'écriture),
  pause tactile réutilisable, absence de fichier temporaire résiduel.
- Nouveaux : `docs/WALKTHROUGH_MANUEL.md`, `docs/launcher_selftest.txt`. Mis à jour : `TEST_REPORT.md`, `ACCEPTANCE_CHECKLIST.md`, `README.md`.
- Inchangé : rendu, modèles, contenu du chapitre 1 (pas de refonte graphique, pas de chapitre 2).

## 0.2.0 — passe « vérifiable » (aucun test Godot exécuté)
### Sauvegarde (point 4)
- `scripts/autoload/game.gd` : format v2 ; ajoute l'état du monde (caisse : départ / portée / posée / livrée) via `world_snapshot` ;
  validation stricte de chaque champ ; l'état du jeu n'est modifié que si la sauvegarde est entièrement valide ;
  écriture atomique (fichier temporaire + renommage) ; refus de sauvegarder pendant une scène (`cutscene_running`) ;
  messages d'erreur (`last_load_error`, `last_save_error`).
- `scripts/world/world.gd` : `_snapshot()`, `_apply_saved_state()` (la quête fait foi ; une caisse portée est rendue au joueur au chargement),
  `_read_pos()`, validation de la position de départ (hors carte → point de départ).
- `scripts/autoload/power_manager.gd` : `load_save_data` durci (types invalides ignorés).
- `scripts/ui/main_menu.gd` : affiche le motif d'un chargement impossible.

### Contrôles mobiles (point 3)
- `scripts/ui/touch_controls.gd` : positions calculées depuis les bords et les zones sûres ; tailles proportionnelles à `Game.touch_scale`.
- `scripts/autoload/game.gd` : `get_safe_insets()` (zone sûre → unités du viewport, mobile uniquement), réglage `touch_scale` persistant
  (`user://eveil_settings.json`).
- `scripts/ui/hud.gd` : HUD placé dans la zone sûre ; panneau de dialogue arrêté avant la zone des boutons ; flash plein écran conservé.
- `scripts/ui/pause_menu.gd` : réglage de la taille des commandes (− / +), message de sauvegarde détaillé.

### Tests et outillage (points 1, 2, 5)
- `tests/integration_test.gd` (nouveau) : parcours via les vraies interactions + sauvegardes + corruption + multitouch injecté.
- `tests/smoke_test.gd` : clairement étiqueté « état interne seulement ».
- `tools/run_tests.sh` (nouveau) : enchaîne import, démarrage, tests et journaux dans `build/logs/`.
- `tools/check_project.py` : liste de classes natives complétée.
- `export_presets.cfg` (nouveau) : modèle Android/iOS sans secret, NON VÉRIFIÉ.
- `docs/PLAN_PASSE_GRAPHIQUE.md` (nouveau) : plan séparé, non réalisé.
- `TEST_REPORT.md`, `ACCEPTANCE_CHECKLIST.md`, `README.md`, `.gitignore` mis à jour.

### Non modifié
Concept, chapitre 1 (3 étapes), rendu en primitives, absence de son : inchangés.
