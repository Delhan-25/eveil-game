extends Node
## Autoload « Game » : état global, carte d'entrées, sauvegarde locale.

signal toast_requested(text: String)
signal prompt_changed(text: String)
signal banner_requested(title: String, subtitle: String)
signal flash_requested(duration: float)
signal pause_requested
signal touch_scale_changed
signal quality_changed

const VERSION := "0.3.3"
const SAVE_PATH := "user://eveil_save.json"
const SAVE_VERSION := 2
const CRATE_STATES := ["start", "carried", "dropped", "delivered"]
const SETTINGS_PATH := "user://eveil_settings.json"

var in_game: bool = false
var input_locked: bool = false          # vrai pendant les scènes scriptées
var cutscene_running: bool = false      # empêche la sauvegarde en pleine scène
var chapter_screen_open: bool = false
var touch_active: bool = false
var touch_move: Vector2 = Vector2.ZERO  # alimenté par le joystick virtuel
var touch_look: Vector2 = Vector2.ZERO  # alimenté par le glissement caméra
var current_prompt: String = ""
var play_time: float = 0.0
var flags: Dictionary = {}
var player_position: Vector3 = Vector3.ZERO
var has_saved_position: bool = false
var touch_scale: float = 1.0            # taille des commandes tactiles (réglable)
var world_snapshot: Callable = Callable()  # fourni par le monde : état à sauvegarder
var loaded_world: Dictionary = {}       # état du monde lu dans la sauvegarde
var last_load_error: String = ""
var last_save_error: String = ""
var is_web: bool = OS.has_feature("web")
var shadows_enabled: bool = true        # désactivé par défaut sur Web/mobile (performances)
var show_fps: bool = false
var _portrait_timer: float = 0.0
var save_path: String = SAVE_PATH       # modifiable par les tests (simulation d'échec d'écriture)


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_input_map()
	touch_active = DisplayServer.is_touchscreen_available() \
		or OS.has_feature("web_ios") or OS.has_feature("web_android")
	shadows_enabled = not (is_web or OS.has_feature("mobile"))
	_load_settings()


func _process(delta: float) -> void:
	if in_game and not get_tree().paused and not chapter_screen_open:
		play_time += delta
		# Web : en portrait (iPhone), on met le jeu en pause (la page affiche « tourne ton téléphone »).
		if is_web:
			_portrait_timer += delta
			if _portrait_timer > 0.5:
				_portrait_timer = 0.0
				var ws := get_window().size
				if ws.y > ws.x:
					pause_requested.emit()


func _notification(what: int) -> void:
	# Sur le Web, la perte de focus (onglet masqué, retour à l'accueil iOS) est le seul signal fiable.
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST \
			or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if in_game and not cutscene_running:
			save_game()


# ---------------------------------------------------------------- Entrées

func _setup_input_map() -> void:
	# Touches physiques : WASD (QWERTY) = ZQSD (AZERTY) sans configuration.
	_add_action("move_forward", [KEY_W, KEY_UP])
	_add_action("move_back", [KEY_S, KEY_DOWN])
	_add_action("move_left", [KEY_A, KEY_LEFT])
	_add_action("move_right", [KEY_D, KEY_RIGHT])
	_add_action("jump", [KEY_SPACE])
	_add_action("run", [KEY_SHIFT])
	_add_action("interact", [KEY_E, KEY_F, KEY_ENTER])
	_add_action("power", [KEY_R])
	_add_action("pause", [KEY_ESCAPE, KEY_P])


func _add_action(action: StringName, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action, 0.2)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k as Key
		InputMap.action_add_event(action, ev)


func release_all_actions() -> void:
	for a in ["jump", "interact", "power", "run"]:
		if InputMap.has_action(a):   # peut être appelé avant _ready (scripts/tests)
			Input.action_release(a)
	touch_move = Vector2.ZERO
	touch_look = Vector2.ZERO


# ---------------------------------------------------------------- Interface

func toast(text: String) -> void:
	toast_requested.emit(text)


func set_prompt(text: String) -> void:
	if text == current_prompt:
		return
	current_prompt = text
	prompt_changed.emit(text)


# ---------------------------------------------------------------- Partie

func new_game() -> void:
	_reset_runtime()
	Quests.reset()
	Powers.reset()
	flags = {}
	play_time = 0.0
	has_saved_position = false
	loaded_world = {}
	in_game = true


func _reset_runtime() -> void:
	input_locked = false
	cutscene_running = false
	chapter_screen_open = false
	current_prompt = ""
	release_all_actions()


func ensure_started() -> void:
	if not in_game:
		new_game()


func start_world() -> void:
	get_tree().change_scene_to_file("res://scenes/world.tscn")


func go_to_menu() -> void:
	in_game = false
	get_tree().paused = false
	Powers.deactivate_all()
	_reset_runtime()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


# ---------------------------------------------------------------- Réglages / zones sûres

func set_touch_scale(v: float) -> void:
	touch_scale = clampf(snappedf(v, 0.1), 0.7, 1.5)
	_save_settings()
	touch_scale_changed.emit()


func set_shadows(on: bool) -> void:
	shadows_enabled = on
	_save_settings()
	quality_changed.emit()


func set_show_fps(on: bool) -> void:
	show_fps = on
	_save_settings()
	quality_changed.emit()


func _load_settings() -> void:
	if not FileAccess.file_exists(SETTINGS_PATH):
		return
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
	if f == null:
		return
	var json := JSON.new()
	var ok := json.parse(f.get_as_text()) == OK
	f.close()
	if ok and typeof(json.data) == TYPE_DICTIONARY:
		var d: Dictionary = json.data
		var v: Variant = d.get("touch_scale", 1.0)
		if _is_num(v):
			touch_scale = clampf(float(v), 0.7, 1.5)
		var sh: Variant = d.get("shadows", null)
		if typeof(sh) == TYPE_BOOL:
			shadows_enabled = sh
		var ff: Variant = d.get("show_fps", null)
		if typeof(ff) == TYPE_BOOL:
			show_fps = ff


func _save_settings() -> void:
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify({"touch_scale": touch_scale, "shadows": shadows_enabled, "show_fps": show_fps}))
	f.close()


## Marges (encoche, barre de gestes, coins arrondis) en unités du viewport.
## Nul sur ordinateur.
func get_safe_insets() -> Dictionary:
	var res := {"left": 0.0, "top": 0.0, "right": 0.0, "bottom": 0.0}
	if not OS.has_feature("mobile"):
		return res
	var win := Vector2(DisplayServer.window_get_size())
	var vp := get_viewport().get_visible_rect().size
	var safe := Rect2(DisplayServer.get_display_safe_area())
	if win.x <= 0.0 or win.y <= 0.0 or safe.size.x <= 0.0 or safe.size.y <= 0.0:
		return res
	var sx := vp.x / win.x
	var sy := vp.y / win.y
	res["left"] = clampf(maxf(0.0, safe.position.x) * sx, 0.0, 140.0)
	res["top"] = clampf(maxf(0.0, safe.position.y) * sy, 0.0, 140.0)
	res["right"] = clampf(maxf(0.0, win.x - (safe.position.x + safe.size.x)) * sx, 0.0, 140.0)
	res["bottom"] = clampf(maxf(0.0, win.y - (safe.position.y + safe.size.y)) * sy, 0.0, 140.0)
	return res


# ---------------------------------------------------------------- Sauvegarde
# Politique : la version est OBLIGATOIRE. v2 = format courant ; v1 = migrée (champ "world"
# absent, reconstruit depuis l'étape). Toute autre version, tout champ requis absent ou de
# mauvais type, toute valeur hors limites ou état incohérent => REFUS (rien n'est modifié).

func _is_num(v: Variant) -> bool:
	return typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT


func _is_int_value(v: Variant) -> bool:
	return typeof(v) == TYPE_INT or (typeof(v) == TYPE_FLOAT and v == floorf(v))


func has_save() -> bool:
	return FileAccess.file_exists(save_path)


func save_game() -> bool:
	last_save_error = ""
	if not in_game:
		last_save_error = "Aucune partie en cours."
		return false
	if cutscene_running:
		last_save_error = "Sauvegarde impossible pendant une scène."
		return false
	var world: Dictionary = {}
	if world_snapshot.is_valid():
		var w: Variant = world_snapshot.call()
		if typeof(w) == TYPE_DICTIONARY:
			world = w
	var data := {
		"version": SAVE_VERSION,
		"step": Quests.step_index,
		"powers": Powers.get_save_data(),
		"flags": flags,
		"play_time": play_time,
		"position": [player_position.x, player_position.y, player_position.z],
		"world": world,
	}
	# Écriture dans un fichier temporaire, relecture de contrôle, puis remplacement.
	# L'ancienne sauvegarde n'est JAMAIS supprimée avant le remplacement : en cas d'échec
	# à n'importe quelle étape, elle reste intacte.
	var tmp := save_path + ".tmp"
	var text := JSON.stringify(data)
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		last_save_error = "Écriture impossible (%s). L'ancienne sauvegarde est conservée." % error_string(FileAccess.get_open_error())
		return false
	f.store_string(text)
	var werr := f.get_error()
	f.close()
	if werr != OK:
		DirAccess.remove_absolute(tmp)
		last_save_error = "Erreur d'écriture (%s). L'ancienne sauvegarde est conservée." % error_string(werr)
		return false
	var check := FileAccess.open(tmp, FileAccess.READ)
	var readback := check.get_as_text() if check != null else ""
	if check != null:
		check.close()
	if readback != text:
		DirAccess.remove_absolute(tmp)
		last_save_error = "Relecture de contrôle différente. L'ancienne sauvegarde est conservée."
		return false
	var err := DirAccess.rename_absolute(tmp, save_path)
	if err != OK:
		DirAccess.remove_absolute(tmp)
		last_save_error = "Remplacement impossible (%s). L'ancienne sauvegarde est conservée." % error_string(err)
		return false
	return true


func _load_fail(msg: String) -> bool:
	last_load_error = msg
	return false


## Valide puis applique la sauvegarde. Ne modifie l'état du jeu que si TOUT est valide.
func load_game() -> bool:
	last_load_error = ""
	if not has_save():
		return _load_fail("Aucune sauvegarde.")
	var f := FileAccess.open(save_path, FileAccess.READ)
	if f == null:
		return _load_fail("Sauvegarde illisible.")
	var text := f.get_as_text()
	f.close()
	var json := JSON.new()
	if json.parse(text) != OK:
		return _load_fail("Sauvegarde corrompue (JSON invalide).")
	if typeof(json.data) != TYPE_DICTIONARY:
		return _load_fail("Sauvegarde corrompue (format inattendu).")
	var data: Dictionary = json.data

	# --- version obligatoire
	var vv: Variant = data.get("version", null)
	if not _is_int_value(vv):
		return _load_fail("Sauvegarde sans version valide.")
	var ver := int(vv)
	if ver != 1 and ver != SAVE_VERSION:
		return _load_fail("Version de sauvegarde non prise en charge (%d)." % ver)

	# --- étape
	var sv: Variant = data.get("step", null)
	if not _is_int_value(sv) or int(sv) < 0 or int(sv) > Quests.STEPS.size():
		return _load_fail("Sauvegarde corrompue (étape invalide).")
	var step := int(sv)

	# --- pouvoirs
	var pv: Variant = data.get("powers", null)
	if typeof(pv) != TYPE_DICTIONARY:
		return _load_fail("Sauvegarde corrompue (pouvoirs).")
	var pd: Dictionary = pv
	var ul: Variant = pd.get("unlocked", null)
	if typeof(ul) != TYPE_ARRAY:
		return _load_fail("Sauvegarde corrompue (pouvoirs débloqués).")
	var has_strength := false
	for id in ul:
		if typeof(id) != TYPE_STRING or Powers.get_power(id) == null:
			return _load_fail("Sauvegarde corrompue (pouvoir inconnu).")
		if id == "super_strength":
			has_strength = true
	# Cohérence : la super-force n'existe qu'une fois le chapitre terminé.
	if (step >= Quests.STEPS.size()) != has_strength:
		return _load_fail("Sauvegarde incohérente (pouvoir / étape).")

	# --- drapeaux, temps de jeu
	var fl: Variant = data.get("flags", null)
	if typeof(fl) != TYPE_DICTIONARY:
		return _load_fail("Sauvegarde corrompue (drapeaux).")
	var pt: Variant = data.get("play_time", null)
	if not _is_num(pt) or float(pt) < 0.0 or not is_finite(float(pt)):
		return _load_fail("Sauvegarde corrompue (temps de jeu).")

	# --- position
	var pos_v: Variant = data.get("position", null)
	if typeof(pos_v) != TYPE_ARRAY or (pos_v as Array).size() != 3:
		return _load_fail("Sauvegarde corrompue (position).")
	var pa: Array = pos_v
	if not (_is_num(pa[0]) and _is_num(pa[1]) and _is_num(pa[2])):
		return _load_fail("Sauvegarde corrompue (position).")
	var pos := Vector3(float(pa[0]), float(pa[1]), float(pa[2]))
	if not pos.is_finite() or absf(pos.x) > 70.0 or absf(pos.z) > 70.0 or pos.y <= -1.0 or pos.y >= 20.0:
		return _load_fail("Sauvegarde corrompue (position hors carte).")

	# --- monde (v2) ou migration (v1)
	var world: Dictionary
	if ver == 1:
		var crate_state := "delivered" if step >= 2 else "start"
		world = {"crate": {"state": crate_state, "pos": [0.0, 0.35, 0.0]}}
	else:
		var wv: Variant = data.get("world", null)
		if typeof(wv) != TYPE_DICTIONARY:
			return _load_fail("Sauvegarde corrompue (monde).")
		world = wv
		var cv: Variant = world.get("crate", null)
		if typeof(cv) != TYPE_DICTIONARY:
			return _load_fail("Sauvegarde corrompue (caisse).")
		var cd: Dictionary = cv
		var st: Variant = cd.get("state", null)
		if typeof(st) != TYPE_STRING or not CRATE_STATES.has(st):
			return _load_fail("Sauvegarde corrompue (état de la caisse).")
		var cpv: Variant = cd.get("pos", null)
		if typeof(cpv) != TYPE_ARRAY or (cpv as Array).size() != 3:
			return _load_fail("Sauvegarde corrompue (position de la caisse).")
		var cpa: Array = cpv
		if not (_is_num(cpa[0]) and _is_num(cpa[1]) and _is_num(cpa[2])):
			return _load_fail("Sauvegarde corrompue (position de la caisse).")
		var cp := Vector3(float(cpa[0]), float(cpa[1]), float(cpa[2]))
		if not cp.is_finite() or absf(cp.x) > 70.0 or absf(cp.z) > 70.0 or cp.y < -1.0 or cp.y > 10.0:
			return _load_fail("Sauvegarde corrompue (caisse hors carte).")
		# Cohérence caisse / étape.
		var okc := false
		if step >= 2:
			okc = st == "delivered"
		elif step == 1:
			okc = st == "start" or st == "carried" or st == "dropped"
		else:
			okc = st == "start"
		if not okc:
			return _load_fail("Sauvegarde incohérente (caisse / étape).")

	# --- tout est valide : on applique
	new_game()
	Quests.load_step(step)
	Powers.load_save_data(pd)
	flags = fl
	play_time = float(pt)
	player_position = pos
	has_saved_position = true
	loaded_world = world
	return true
