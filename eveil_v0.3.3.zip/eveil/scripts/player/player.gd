class_name Player
extends CharacterBody3D
## Aël : marche, course, saut, interaction, transport d'objets, pouvoirs.

const WALK_SPEED := 3.4
const RUN_SPEED := 6.2
const ACCEL := 22.0
const AIR_ACCEL := 8.0
const JUMP_VELOCITY := 7.2
const GRAVITY := 22.0
const COYOTE_TIME := 0.12
const JUMP_BUFFER := 0.12

var speed_multiplier: float = 1.0
var jump_multiplier: float = 1.0
var carrying: Node3D = null
var lift_pose: bool = false
var rig: CameraRig
var model: Node3D
var parts: Dictionary = {}
var carry_point: Node3D

var _sensor: Area3D
var _coyote: float = 0.0
var _jump_buffer: float = 0.0
var _anim_t: float = 0.0
var _current: Interactable = null
var _aura: CPUParticles3D
var _aura_light: OmniLight3D
var _last_safe: Vector3 = Vector3.ZERO
var _safe_timer: float = 0.0


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1 | 16
	floor_snap_length = 0.35
	_last_safe = global_position

	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.28
	cap.height = 1.3
	cs.shape = cap
	cs.position = Vector3(0, 0.65, 0)
	add_child(cs)

	parts = CharacterBuilder.build({
		"shirt": Color(0.12, 0.55, 0.62), "pants": Color(0.15, 0.18, 0.3),
		"hair": Color(0.17, 0.19, 0.36), "accent": Color(0.92, 0.42, 0.2),
		"scale": 1.0, "gem": true,
	})
	model = parts["root"]
	add_child(model)

	carry_point = Node3D.new()
	carry_point.position = Vector3(0, 0.95, -0.55)
	model.add_child(carry_point)

	_sensor = Area3D.new()
	_sensor.collision_layer = 0
	_sensor.collision_mask = 8
	_sensor.monitoring = true
	_sensor.monitorable = false
	var scs := CollisionShape3D.new()
	var ss := SphereShape3D.new()
	ss.radius = 1.9
	scs.shape = ss
	scs.position = Vector3(0, 0.8, 0)
	_sensor.add_child(scs)
	add_child(_sensor)

	_build_aura()

	rig = CameraRig.new()
	add_child(rig)
	rig.setup(self)
	set_aura(false)


func _build_aura() -> void:
	_aura = CPUParticles3D.new()
	_aura.emitting = false
	_aura.amount = 28
	_aura.lifetime = 0.9
	_aura.local_coords = false
	_aura.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	_aura.emission_sphere_radius = 0.45
	_aura.direction = Vector3.UP
	_aura.spread = 25.0
	_aura.gravity = Vector3(0, 1.2, 0)
	_aura.initial_velocity_min = 0.2
	_aura.initial_velocity_max = 0.8
	var sm := SphereMesh.new()
	sm.radius = 0.04
	sm.height = 0.08
	sm.radial_segments = 6
	sm.rings = 3
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(0.6, 0.9, 1.0)
	sm.material = m
	_aura.mesh = sm
	_aura.position = Vector3(0, 0.8, 0)
	model.add_child(_aura)

	_aura_light = OmniLight3D.new()
	_aura_light.light_color = Color(0.5, 0.8, 1.0)
	_aura_light.omni_range = 4.0
	_aura_light.light_energy = 0.0
	_aura_light.position = Vector3(0, 1.0, 0)
	model.add_child(_aura_light)


func set_aura(on: bool) -> void:
	_aura.emitting = on
	_aura_light.light_energy = 1.8 if on else 0.0
	if parts.has("gem_mat"):
		var gm: StandardMaterial3D = parts["gem_mat"]
		var base := 1.6 if Powers.is_unlocked("super_strength") else 0.8
		gm.emission_energy_multiplier = 5.0 if on else base


func face_toward(pos: Vector3) -> void:
	var d := pos - global_position
	d.y = 0.0
	if d.length() > 0.01:
		model.rotation.y = atan2(-d.x, -d.z)


# ---------------------------------------------------------------- Physique

func _physics_process(delta: float) -> void:
	Game.player_position = global_position
	var locked: bool = Dialogue.active or Game.input_locked

	var input_vec := Vector2.ZERO
	var from_touch := false
	if not locked:
		input_vec = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		if Game.touch_move.length() > input_vec.length():
			input_vec = Game.touch_move
			from_touch = true

	var mag := minf(input_vec.length(), 1.0)
	var running: bool = Input.is_action_pressed("run") if not from_touch else mag > 0.8
	var base_speed := RUN_SPEED if running else WALK_SPEED
	var speed := base_speed * mag * speed_multiplier
	if carrying != null and not Powers.is_active("super_strength"):
		speed *= 0.8

	var dir := Vector3(input_vec.x, 0.0, input_vec.y).rotated(Vector3.UP, rig.yaw)
	var target := Vector3.ZERO
	if dir.length() > 0.01:
		target = dir.normalized() * speed

	var acc := ACCEL if is_on_floor() else AIR_ACCEL
	velocity.x = move_toward(velocity.x, target.x, acc * delta)
	velocity.z = move_toward(velocity.z, target.z, acc * delta)

	if is_on_floor():
		_coyote = COYOTE_TIME
		if velocity.y < 0.0:
			velocity.y = 0.0
	else:
		velocity.y -= GRAVITY * delta
		_coyote = maxf(0.0, _coyote - delta)

	if not locked and Input.is_action_just_pressed("jump"):
		_jump_buffer = JUMP_BUFFER
	else:
		_jump_buffer = maxf(0.0, _jump_buffer - delta)
	if _jump_buffer > 0.0 and _coyote > 0.0:
		velocity.y = JUMP_VELOCITY * jump_multiplier
		_jump_buffer = 0.0
		_coyote = 0.0

	move_and_slide()

	if target.length() > 0.1:
		var yaw_t := atan2(-dir.x, -dir.z)
		model.rotation.y = lerp_angle(model.rotation.y, yaw_t, 1.0 - exp(-14.0 * delta))

	_update_interactable(locked)
	if not locked:
		if Input.is_action_just_pressed("interact") and Time.get_ticks_msec() - Dialogue.last_end_ms > 350:
			_do_interact()
		if Input.is_action_just_pressed("power"):
			Powers.try_use(self)

	_safe_timer += delta
	if is_on_floor() and _safe_timer > 0.5:
		_safe_timer = 0.0
		_last_safe = global_position
	if global_position.y < -15.0:
		global_position = _last_safe + Vector3(0, 0.5, 0)
		velocity = Vector3.ZERO

	_animate(delta)


func _update_interactable(locked: bool) -> void:
	var best: Interactable = null
	var best_d := INF
	for a in _sensor.get_overlapping_areas():
		var it := a as Interactable
		if it == null or not it.is_available():
			continue
		var d := global_position.distance_squared_to(it.global_position)
		if d < best_d:
			best_d = d
			best = it
	_current = best
	var text := ""
	if not locked:
		if best != null:
			text = best.prompt
		elif carrying != null:
			text = "Poser la caisse"
	Game.set_prompt(text)


func _do_interact() -> void:
	if _current != null and is_instance_valid(_current) and _current.is_available():
		_current.interact(self)
	elif carrying != null:
		drop_carried()


# ---------------------------------------------------------------- Transport

## Déplace un nœud vers un nouveau parent par remove_child/add_child (sans Node.reparent :
## les journaux CI v0.3.2 montraient « Parameter "m" is null » à la libération des mondes
## où une caisse avait été déposée via reparent ; hypothèse non prouvée, voir CHANGELOG).
func _move_item(item: Node3D, new_parent: Node) -> void:
	var old := item.get_parent()
	if old != null:
		old.remove_child(item)
	new_parent.add_child(item)


func pick_up(item: Node3D) -> void:
	if carrying != null:
		return
	carrying = item
	_move_item(item, carry_point)
	item.transform = Transform3D.IDENTITY
	if item.has_method("set_carried"):
		item.call("set_carried", true)


func drop_carried() -> Node3D:
	if carrying == null:
		return null
	var item := carrying
	carrying = null
	var world := get_parent()
	_move_item(item, world)
	var fwd := -model.global_transform.basis.z
	var pos := global_position + fwd * 1.1
	pos.y = (global_position.y if is_on_floor() else 0.0) + 0.35
	item.global_transform = Transform3D(Basis(Vector3.UP, model.global_rotation.y), pos)
	if item.has_method("set_carried"):
		item.call("set_carried", false)
	return item


# ---------------------------------------------------------------- Animation

func _animate(delta: float) -> void:
	var horiz := Vector2(velocity.x, velocity.z).length()
	_anim_t += delta * (4.0 + horiz * 1.7)
	var amp := clampf(horiz / RUN_SPEED, 0.0, 1.0) * 0.95
	var k := 1.0 - exp(-14.0 * delta)
	var leg_l: Node3D = parts["leg_l"]
	var leg_r: Node3D = parts["leg_r"]
	var arm_l: Node3D = parts["arm_l"]
	var arm_r: Node3D = parts["arm_r"]
	var sw := sin(_anim_t) * amp
	if is_on_floor():
		leg_l.rotation.x = lerpf(leg_l.rotation.x, sw, k)
		leg_r.rotation.x = lerpf(leg_r.rotation.x, -sw, k)
	else:
		leg_l.rotation.x = lerpf(leg_l.rotation.x, 0.5, k)
		leg_r.rotation.x = lerpf(leg_r.rotation.x, -0.3, k)

	var t_l := -sw
	var t_r := sw
	if lift_pose:
		t_l = 2.9
		t_r = 2.9
	elif carrying != null:
		t_l = 1.35
		t_r = 1.35
	elif not is_on_floor():
		t_l = 2.3
		t_r = 2.3
	arm_l.rotation.x = lerpf(arm_l.rotation.x, t_l, k)
	arm_r.rotation.x = lerpf(arm_r.rotation.x, t_r, k)
