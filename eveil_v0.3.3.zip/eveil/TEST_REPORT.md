# TEST_REPORT — ÉVEIL v0.3.3

## Preuves réelles (Godot 4.3.stable, GitHub Actions, v0.3.2)
Import OK, fumée OK, intégration 153/159 (6 échecs tactiles). Voir `docs/ANALYSE_JOURNAUX_V0.3.2.md` et `docs/ci_logs_v0.3.2/`.

## v0.3.3 — ce que j'ai pu exécuter ici (sans Godot)
Analyse statique `check_project.py` : RÉUSSI (code 0). Rien d'autre.

## NON EXÉCUTÉ
Import, fumée, intégration, export Web, Safari/iPhone. **Je ne peux pas affirmer que la v0.3.3 est verte.**

## Risques
1. Les « m is null » peuvent persister (cause non prouvée) et feront alors échouer l'étape, volontairement.
2. Le routage réel des événements tactiles n'est que diagnostiqué (`[DIAG]`), pas asserté.
3. Le test peut révéler de nouveaux défauts dans les segments encore non exercés.
