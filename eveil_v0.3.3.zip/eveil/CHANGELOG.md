# CHANGELOG

## 0.3.3 — suite à l'analyse des journaux CI v0.3.2 (aucune vérification retirée)
Détail : `docs/ANALYSE_JOURNAUX_V0.3.2.md`.
- `tests/integration_test.gd` : livraison déterministe des événements tactiles à `TouchControls` (`deliver`), souris visible pendant le test multitouch, sonde `test_dispatch_probe` et diagnostics `test_teardown_diag` (non comptés), marqueurs `[DIAG]` dans `free_world`.
- `scripts/player/player.gd` : `_move_item()` (remove_child/add_child) à la place de `Node.reparent` pour la caisse. **Mesure d'hypothèse** contre « Parameter "m" is null » ; non prouvée.
- `scripts/autoload/game.gd`, `export_presets.cfg` : version 0.3.3 / code 5. Journaux v0.3.2 archivés dans `docs/ci_logs_v0.3.2/`.
- Non modifié : missions, sauvegardes, pouvoirs, `touch_controls.gd`, `tools/run_tests.sh`.

## 0.3.2 — corrections issues des journaux Godot réels (CI v0.3.1) — aucune fonctionnalité retirée ni ajoutée
Détail et preuves : `docs/ANALYSE_JOURNAUX_V0.3.1.md`.
### Bug réel corrigé
- `web/head_include.html`, `tools/make_web_preset.py`, `export_presets.cfg` : le texte de l'écran de rotation utilisait `\u00e9` ; Godot le décodait en octet UTF-8 invalide
  (warnings `Unicode parsing error` à l'import, texte « t�l�phone »). Remplacé par des entités HTML ASCII ; le générateur refuse désormais non-ASCII et antislash.
### Gardes défensives (jeu)
- `scripts/autoload/game.gd` : `release_all_actions()` ignore les actions absentes de l'InputMap (appel avant `_ready`). Version 0.3.2.
- `scripts/ui/touch_controls.gd` : la géométrie des commandes se calcule depuis `get_viewport_rect()` (plus de dépendance à `Control.size`).
### Tests (aucune vérification retirée ; 6 ajoutées)
- `tests/integration_test.gd` : entrées simulées comme le moteur (`process_frame`), événements tactiles livrés avec `Input.flush_buffered_events()`, attente de `_ready` des autoloads,
  coordonnées tactiles relatives à l'écran, contexte affiché à chaque échec, diagnostics de taille (viewport, TouchControls, HUD).
- `tests/smoke_test.gd` : cycle sauvegarde/rechargement sur un état cohérent ; l'état incohérent (étape 1 + super-force) doit être REFUSÉ au chargement.
### Outillage
- `tools/run_tests.sh`, `tools/export_web.sh` : `Unicode parsing error` fait échouer l'étape. Auto-test du lanceur étendu (`docs/launcher_selftest.txt`).
- `export_presets.cfg` : version 0.3.2 / code 4. Journaux CI v0.3.1 archivés dans `docs/ci_logs_v0.3.1/`.

## 0.3.1-ci — compilation automatique (aucune fonctionnalité ajoutée, aucun code de jeu modifié)
- `.github/workflows/web-build.yml` (nouveau) : Godot 4.3.0 + modèles d'export, tests (import, démarrage, fumée, intégration), export Web sans multithreading,
  vérification, ZIP itch.io, artefacts + journaux, Release sur tag, déploiement GitHub Pages après build valide. Échoue si tests/export échouent ;
  option manuelle « exporter même si les tests échouent » (artefact NON VALIDÉ, run en échec).
- `GITHUB_ACTIONS_WEB.md` (nouveau) : instructions exactes. `TEST_REPORT_WEB.md` : mise à jour. Workflow JAMAIS exécuté.

## 0.3.1 — version Web HTML5 (iPhone/Safari, itch.io) — export NON produit
Base : v0.3 (qui inclut les correctifs de la v0.2).
- `export_presets.cfg` : preset **Web (iPhone/itch.io)**, `thread_support=false`, généré par `tools/make_web_preset.py` depuis `web/head_include.html`.
- `web/head_include.html` (nouveau) : meta viewport/iOS, fond noir, `touch-action:none`, blocage des gestes de zoom, écran « Tourne ton téléphone » en portrait, plafond du `devicePixelRatio` à 1,5.
- `tools/export_web.sh`, `tools/verify_web_export.py`, `tools/serve_web.py` (nouveaux) : export + vérification (refuse multithreading/fichiers manquants) + ZIP itch.io + serveur local.
- `scripts/autoload/game.gd` : version 0.3.1 ; détection tactile `web_ios`/`web_android` ; ombres par défaut désactivées sur Web/mobile (`shadows_enabled`, persistant) ; `show_fps` ; autosave à `NOTIFICATION_APPLICATION_FOCUS_OUT` ; pause automatique en portrait sur Web.
- `scripts/world/world.gd` : ombres du soleil pilotées par `Game.shadows_enabled`.
- `scripts/ui/hud.gd`, `scripts/ui/pause_menu.gd` : compteur FPS et boutons « Ombres » / « FPS ».
- `project.godot` : `rendering_method.web="gl_compatibility"`.
- Nouveaux documents : `PUBLICATION_ITCH.md`, `WEB_TEST_CHECKLIST.md`, `TEST_REPORT_WEB.md`.

## 0.3.0 — fiabilisation (issue de l'audit v0.2) — aucun test Godot exécuté
### P0 — Lanceur de tests (`tools/run_tests.sh`)
- Réécrit en sh POSIX : plus de `| tee` (qui masquait le code de Godot). Chaque commande écrit dans `build/logs/<nom>.log`,
  son vrai code est conservé, `summary.txt` généré, arrêt si version/import/démarrage échouent, 127 si Godot introuvable.
- Testé avec de faux exécutables (code 23, « SCRIPT ERROR » avec code 0, échec de l'intégration seule, succès, absent) :
  preuve dans `docs/launcher_selftest.txt`.
### P1 — Sauvegarde (`scripts/autoload/game.gd`)
- Remplacement sans suppression préalable de l'ancienne sauvegarde ; relecture de contrôle ; en cas d'échec : ancienne sauvegarde conservée + message.
- Chargement : version obligatoire (2 courant, 1 migrée, autre refusée) ; tous les champs requis vérifiés ; cohérences caisse/étape et pouvoir/étape ;
  refus sans modification de l'état. `save_path` rendu modifiable pour les tests.
### P2 — Divers
- `scripts/ui/main_menu.gd` : version affichée depuis `Game.VERSION` (0.3.0). `export_presets.cfg` : 0.3.0 / code 3.
### Tests et documents
- `tests/integration_test.gd` : parcours à pied (`walk_to`, sans téléportation), `test_save_policy()` (26 refus, 3 acceptations, échec d'écriture),
  pause tactile réutilisable, absence de fichier temporaire résiduel.
- Nouveaux : `docs/WALKTHROUGH_MANUEL.md`, `docs/launcher_selftest.txt`. Mis à jour : `TEST_REPORT.md`, `ACCEPTANCE_CHECKLIST.md`, `README.md`.
- Inchangé : rendu, modèles, contenu du chapitre 1 (pas de refonte graphique, pas de chapitre 2).

## 0.2.0 — passe « vérifiable » (aucun test Godot exécuté)
### Sauvegarde (point 4)
- `scripts/autoload/game.gd` : format v2 ; ajoute l'état du monde (caisse : départ / portée / posée / livrée) via `world_snapshot` ;
  validation stricte de chaque champ ; l'état du jeu n'est modifié que si la sauvegarde est entièrement valide ;
  écriture atomique (fichier temporaire + renommage) ; refus de sauvegarder pendant une scène (`cutscene_running`) ;
  messages d'erreur (`last_load_error`, `last_save_error`).
- `scripts/world/world.gd` : `_snapshot()`, `_apply_saved_state()` (la quête fait foi ; une caisse portée est rendue au joueur au chargement),
  `_read_pos()`, validation de la position de départ (hors carte → point de départ).
- `scripts/autoload/power_manager.gd` : `load_save_data` durci (types invalides ignorés).
- `scripts/ui/main_menu.gd` : affiche le motif d'un chargement impossible.

### Contrôles mobiles (point 3)
- `scripts/ui/touch_controls.gd` : positions calculées depuis les bords et les zones sûres ; tailles proportionnelles à `Game.touch_scale`.
- `scripts/autoload/game.gd` : `get_safe_insets()` (zone sûre → unités du viewport, mobile uniquement), réglage `touch_scale` persistant
  (`user://eveil_settings.json`).
- `scripts/ui/hud.gd` : HUD placé dans la zone sûre ; panneau de dialogue arrêté avant la zone des boutons ; flash plein écran conservé.
- `scripts/ui/pause_menu.gd` : réglage de la taille des commandes (− / +), message de sauvegarde détaillé.

### Tests et outillage (points 1, 2, 5)
- `tests/integration_test.gd` (nouveau) : parcours via les vraies interactions + sauvegardes + corruption + multitouch injecté.
- `tests/smoke_test.gd` : clairement étiqueté « état interne seulement ».
- `tools/run_tests.sh` (nouveau) : enchaîne import, démarrage, tests et journaux dans `build/logs/`.
- `tools/check_project.py` : liste de classes natives complétée.
- `export_presets.cfg` (nouveau) : modèle Android/iOS sans secret, NON VÉRIFIÉ.
- `docs/PLAN_PASSE_GRAPHIQUE.md` (nouveau) : plan séparé, non réalisé.
- `TEST_REPORT.md`, `ACCEPTANCE_CHECKLIST.md`, `README.md`, `.gitignore` mis à jour.

### Non modifié
Concept, chapitre 1 (3 étapes), rendu en primitives, absence de son : inchangés.
